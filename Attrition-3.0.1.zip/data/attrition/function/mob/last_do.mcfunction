execute store result score #h atr.tmp run data get entity @s Health
execute unless score #h atr.tmp matches 1..4 run return 0
execute unless predicate attrition:chance_15 run return 0
effect give @s minecraft:speed 4 1 true
effect give @s minecraft:strength 4 0 true
particle minecraft:angry_villager ~ ~1.6 ~ 0.2 0.2 0.2 0 3 normal
