# mobs that survive a fight with you get better at it
execute unless score REAP_ON atr.cfg matches 1 run return 0
execute as @e[tag=atr.done,tag=!atr.reaped,type=#attrition:targets,distance=..24,limit=4] run function attrition:mob/reap_do
