# a dying mob is at its most dangerous
execute as @e[tag=atr.done,type=#attrition:targets,distance=..20,limit=6] at @s run function attrition:mob/last_do
