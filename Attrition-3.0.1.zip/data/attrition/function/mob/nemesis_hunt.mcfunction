execute if entity @a[distance=..64,gamemode=!spectator,limit=1] run effect give @s minecraft:speed 4 0 true
execute unless entity @a[distance=..80,gamemode=!spectator,limit=1] if predicate attrition:chance_10 run tp @s @a[gamemode=!spectator,limit=1,sort=random]
execute as @a[distance=..24,gamemode=!spectator] run function attrition:mob/nemesis_near
