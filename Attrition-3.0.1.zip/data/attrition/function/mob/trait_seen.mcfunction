# grant the collector advancement once a player has met all ten mob traits
scoreboard players set #n atr.tmp 0
execute if entity @e[tag=atr.tr_leech,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 1
execute if entity @e[tag=atr.tr_thorn,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 2
execute if entity @e[tag=atr.tr_swift,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 4
execute if entity @e[tag=atr.tr_venom,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 8
execute if entity @e[tag=atr.tr_frost,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 16
execute if entity @e[tag=atr.tr_blind,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 32
execute if entity @e[tag=atr.tr_ward,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 64
execute if entity @e[tag=atr.tr_volatile,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 128
execute if entity @e[tag=atr.tr_hollow,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 256
execute if entity @e[tag=atr.tr_undying,distance=..40,limit=1] run scoreboard players set #bit atr.tmp 512
execute unless score #bit atr.tmp matches 1.. run return 0
scoreboard players operation #cur atr.tmp = @s atr.tseen
function attrition:player/bit_set
scoreboard players operation @s atr.tseen = #cur atr.tmp
scoreboard players set #bit atr.tmp 0
execute if score @s atr.tseen matches 1023 run advancement grant @s only attrition:trait_all
