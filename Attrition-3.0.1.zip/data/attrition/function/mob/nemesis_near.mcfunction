execute if predicate attrition:chance_05 run playsound minecraft:entity.warden_heartbeat master @s ~ ~ ~ 0.5 0.6
execute if predicate attrition:chance_05 run title @s actionbar {text:"It remembers you",color:"dark_red",italic:true}
execute if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_15 run scoreboard players remove @s atr.sanity 1
