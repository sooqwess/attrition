tag @s add atr.elite
effect give @s minecraft:fire_resistance infinite 0 true
execute if score @s atr.tier matches 4.. run effect give @s minecraft:resistance infinite 0 true
execute if score @s atr.tier matches 7.. run effect give @s minecraft:regeneration infinite 0 true
execute if score @s atr.tier matches 10.. run effect give @s minecraft:strength infinite 0 true
execute if score @s atr.tier matches 14.. run effect give @s minecraft:speed infinite 1 true
attribute @s minecraft:knockback_resistance modifier add attrition:elite_kb 0.5 add_value
data merge entity @s {Glowing:1b,PersistenceRequired:1b,CustomName:{translate:"attrition.entity.spawn_of_the_gloom",fallback:"Spawn of the Gloom",color:"dark_red",italic:false},CustomNameVisible:0b}
