# it does not lose the scent
execute unless entity @e[tag=atr.nemesis,limit=1] run return 0
execute as @e[tag=atr.nemesis] at @s run function attrition:mob/nemesis_hunt
