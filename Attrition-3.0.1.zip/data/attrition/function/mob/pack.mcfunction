# called on a scanned mob: count nearby hostiles, buff the group
execute store result score @s atr.packs if entity @e[type=#attrition:targets,distance=..8]
execute if score @s atr.packs matches 4.. run function attrition:mob/pack_buff
