# assign one trait per mob, based on tier - called once from mob/apply
scoreboard players set #t atr.tmp 0
execute store result score #t atr.tmp run random value 1..10
execute if score @s atr.tier matches 3.. if score #t atr.tmp matches 1 run function attrition:mob/trait/leech
execute if score @s atr.tier matches 3.. if score #t atr.tmp matches 2 run function attrition:mob/trait/thorned
execute if score @s atr.tier matches 4.. if score #t atr.tmp matches 3 run function attrition:mob/trait/swift
execute if score @s atr.tier matches 5.. if score #t atr.tmp matches 4 run function attrition:mob/trait/venom
execute if score @s atr.tier matches 6.. if score #t atr.tmp matches 5 run function attrition:mob/trait/frost
execute if score @s atr.tier matches 7.. if score #t atr.tmp matches 6 run function attrition:mob/trait/blinding
execute if score @s atr.tier matches 8.. if score #t atr.tmp matches 7 run function attrition:mob/trait/warded
execute if score @s atr.tier matches 9.. if score #t atr.tmp matches 8 run function attrition:mob/trait/volatile
execute if score @s atr.tier matches 10.. if score #t atr.tmp matches 9 run function attrition:mob/trait/hollow
execute if score @s atr.tier matches 12.. if score #t atr.tmp matches 10 run function attrition:mob/trait/undying
