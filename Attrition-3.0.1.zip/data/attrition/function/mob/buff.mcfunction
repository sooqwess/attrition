# compute multipliers into storage, then call the macro
scoreboard players operation #hp atr.tmp = @s atr.tier
scoreboard players operation #hp atr.tmp *= HP_PER atr.cfg
scoreboard players operation #dmg atr.tmp = @s atr.tier
scoreboard players operation #dmg atr.tmp *= DMG_PER atr.cfg
scoreboard players operation #spd atr.tmp = @s atr.tier
scoreboard players operation #spd atr.tmp *= SPD_PER atr.cfg
scoreboard players operation #kb atr.tmp = @s atr.tier
scoreboard players operation #kb atr.tmp *= KB_PER atr.cfg
scoreboard players operation #arm atr.tmp = @s atr.tier
scoreboard players operation #arm atr.tmp *= ARMOR_PER atr.cfg

execute store result storage attrition:calc buff.hp double 0.01 run scoreboard players get #hp atr.tmp
execute store result storage attrition:calc buff.dmg double 0.01 run scoreboard players get #dmg atr.tmp
execute store result storage attrition:calc buff.spd double 0.01 run scoreboard players get #spd atr.tmp
execute store result storage attrition:calc buff.kb double 0.01 run scoreboard players get #kb atr.tmp
execute store result storage attrition:calc buff.arm double 0.01 run scoreboard players get #arm atr.tmp
execute store result storage attrition:calc buff.range double 0.10 run scoreboard players get @s atr.tier

function attrition:mob/apply_attrs with storage attrition:calc buff
