# Elite chance scales with mob tier and world era
scoreboard players operation #ch atr.tmp = @s atr.tier
scoreboard players operation #ch atr.tmp *= ELITE_PER atr.cfg
scoreboard players operation #ch atr.tmp += ERA atr.world
execute store result score #roll atr.tmp run random value 1..100
execute if score #roll atr.tmp <= #ch atr.tmp run function attrition:mob/elite_make
