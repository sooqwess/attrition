execute if predicate attrition:chance_15 run data merge entity @s {powered:1b,ExplosionRadius:4b,Fuse:20s}
