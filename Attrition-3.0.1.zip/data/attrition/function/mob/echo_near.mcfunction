execute if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_25 run scoreboard players remove @s atr.sanity 1
execute if predicate attrition:chance_05 run playsound minecraft:entity.vex.ambient master @s ~ ~ ~ 0.4 0.5
