# killing it is worth something
scoreboard players add @s atr.nemesis 1
scoreboard players add @s atr.sanity 25
execute if score @s atr.sanity matches 100.. run scoreboard players set @s atr.sanity 100
scoreboard players remove @s atr.gloom 25
execute if score @s atr.gloom matches ..0 run scoreboard players set @s atr.gloom 0
advancement grant @s only attrition:nemesis_slain
