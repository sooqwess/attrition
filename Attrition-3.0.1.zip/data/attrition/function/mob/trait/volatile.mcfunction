tag @s add atr.trait
tag @s add atr.tr_volatile
data merge entity @s {CustomName:{translate:"attrition.entity.volatile",fallback:"Volatile",color:"red",italic:false},CustomNameVisible:0b}
