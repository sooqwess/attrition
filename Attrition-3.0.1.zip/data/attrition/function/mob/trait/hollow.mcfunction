tag @s add atr.trait
tag @s add atr.tr_hollow
data merge entity @s {CustomName:{translate:"attrition.entity.hollow",fallback:"Hollow",color:"dark_purple",italic:false},CustomNameVisible:0b}
