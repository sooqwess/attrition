advancement revoke @s only attrition:trigger/killed_volatile
# it explodes when it dies - at the player, because you were standing there
execute at @s run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 normal
execute at @s run playsound minecraft:entity.generic.explode master @a[distance=..24] ~ ~ ~ 1 1
damage @s 5 minecraft:explosion
execute if score BODY_ON atr.cfg matches 1 if predicate attrition:chance_50 run function attrition:body/bleed_add
