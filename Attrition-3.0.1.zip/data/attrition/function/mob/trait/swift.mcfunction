tag @s add atr.trait
tag @s add atr.tr_swift
effect give @s minecraft:speed infinite 1 true
data merge entity @s {CustomName:{translate:"attrition.entity.swift",fallback:"Swift",color:"aqua",italic:false},CustomNameVisible:0b}
