tag @s add atr.trait
tag @s add atr.tr_thorn
attribute @s minecraft:armor modifier add attrition:t_arm 6 add_value
data merge entity @s {CustomName:{translate:"attrition.entity.thorned",fallback:"Thorned",color:"gray",italic:false},CustomNameVisible:0b}
