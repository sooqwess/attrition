# short blink toward the nearest player
execute at @p[distance=6..16,gamemode=!creative,gamemode=!spectator] positioned ^ ^ ^-3 run tp @s ~ ~ ~
particle minecraft:portal ~ ~1 ~ 0.4 0.6 0.4 0.1 12 normal
playsound minecraft:entity.enderman.teleport hostile @a[distance=..16] ~ ~ ~ 0.6 0.8
