tag @s add atr.trait
tag @s add atr.tr_leech
effect give @s minecraft:regeneration infinite 0 true
data merge entity @s {CustomName:{translate:"attrition.entity.leeching",fallback:"Leeching",color:"dark_red",italic:false},CustomNameVisible:0b}
