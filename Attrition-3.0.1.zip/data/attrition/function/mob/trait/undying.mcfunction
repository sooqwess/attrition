tag @s add atr.trait
tag @s add atr.tr_undying
effect give @s minecraft:resistance infinite 0 true
data merge entity @s {CustomName:{translate:"attrition.entity.undying",fallback:"Undying",color:"white",italic:false},CustomNameVisible:0b}
