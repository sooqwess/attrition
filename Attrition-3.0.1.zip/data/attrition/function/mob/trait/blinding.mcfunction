tag @s add atr.trait
tag @s add atr.tr_blind
data merge entity @s {CustomName:{translate:"attrition.entity.blinding",fallback:"Blinding",color:"dark_gray",italic:false},CustomNameVisible:0b}
