tag @s add atr.trait
tag @s add atr.tr_venom
data merge entity @s {CustomName:{translate:"attrition.entity.venomous",fallback:"Venomous",color:"dark_green",italic:false},CustomNameVisible:0b}
