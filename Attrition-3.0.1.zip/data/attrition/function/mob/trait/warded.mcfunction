tag @s add atr.trait
tag @s add atr.tr_ward
effect give @s minecraft:resistance infinite 1 true
data merge entity @s {CustomName:{translate:"attrition.entity.warded",fallback:"Warded",color:"gold",italic:false},CustomNameVisible:0b}
