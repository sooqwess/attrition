tag @s add atr.trait
tag @s add atr.tr_frost
data merge entity @s {CustomName:{translate:"attrition.entity.frostbound",fallback:"Frostbound",color:"blue",italic:false},CustomNameVisible:0b}
