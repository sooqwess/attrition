tag @s add atr.wise
attribute @s minecraft:max_health modifier add attrition:species 0.15 add_multiplied_base
attribute @s minecraft:attack_damage modifier add attrition:species 0.15 add_multiplied_base
attribute @s minecraft:movement_speed modifier add attrition:species 0.05 add_multiplied_base
