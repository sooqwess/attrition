# at the death position: whatever stood closest inherits your defeat
execute unless score NEMESIS_ON atr.cfg matches 1 run return 0
execute if entity @e[tag=atr.nemesis,limit=1] run return 0
execute as @e[type=#attrition:targets,distance=..16,limit=1,sort=nearest] run function attrition:mob/nemesis_init
