tag @s add atr.elder
attribute @s minecraft:max_health modifier add attrition:species2 0.25 add_multiplied_base
attribute @s minecraft:attack_damage modifier add attrition:species2 0.25 add_multiplied_base
attribute @s minecraft:armor modifier add attrition:species2 4 add_value
attribute @s minecraft:knockback_resistance modifier add attrition:species2 0.3 add_value
effect give @s minecraft:fire_resistance 999999 0 true
