# read this player's kill tallies into temp so mobs can inherit the grudge
scoreboard players operation #sp_zom atr.tmp = @s atr.k_zom
scoreboard players operation #sp_ske atr.tmp = @s atr.k_ske
scoreboard players operation #sp_cre atr.tmp = @s atr.k_cre
scoreboard players operation #sp_spi atr.tmp = @s atr.k_spi
scoreboard players operation #sp_end atr.tmp = @s atr.k_end
