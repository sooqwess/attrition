item replace entity @s weapon.mainhand with minecraft:bow[minecraft:enchantments={"minecraft:power":3,"minecraft:punch":1,"minecraft:flame":1}]
