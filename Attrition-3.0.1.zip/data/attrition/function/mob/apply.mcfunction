tag @s add atr.done
scoreboard players operation @s atr.tier = #tier atr.tmp
execute if score @s atr.tier matches 1.. run function attrition:mob/buff
execute if score @s atr.tier matches 3.. run function attrition:mob/elite
execute if entity @s[type=minecraft:creeper] if score @s atr.tier matches 2.. run function attrition:mob/creeper
execute if entity @s[type=minecraft:zombie] if score @s atr.tier matches 4.. run data merge entity @s {CanBreakDoors:1b}
execute if entity @s[type=minecraft:skeleton] if score @s atr.tier matches 6.. run function attrition:mob/archer
execute if score BM atr.world matches 1 run effect give @s minecraft:speed 999999 0 true
execute if score BM atr.world matches 1 run effect give @s minecraft:fire_resistance 999999 0 true
execute if score @s atr.tier matches 3.. run function attrition:mob/traits
function attrition:mob/species_apply
