# as <player> at <player>: push the player tier onto nearby mobs
scoreboard players operation #tier atr.tmp = @s atr.tier
function attrition:mob/species_read
execute positioned ~ ~ ~ as @e[type=#attrition:targets,distance=..96,tag=!atr.done] run function attrition:mob/apply
execute as @e[type=#attrition:targets,distance=..40,tag=atr.done,limit=8,sort=random] at @s run function attrition:mob/pack
