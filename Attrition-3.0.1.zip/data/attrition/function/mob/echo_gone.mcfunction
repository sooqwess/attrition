scoreboard players set #seen_e atr.tmp 0
execute as @a[gamemode=!spectator] run scoreboard players add @s atr.echo 1
tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The Echo is gone. It was you, and now it is not.",color:"dark_purple",italic:true}]
