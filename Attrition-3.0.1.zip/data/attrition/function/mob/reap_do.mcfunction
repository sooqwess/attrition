execute unless predicate attrition:chance_05 run return 0
tag @s add atr.reaped
attribute @s minecraft:attack_damage modifier add attrition:reap 0.2 add_multiplied_base
attribute @s minecraft:movement_speed modifier add attrition:reap 0.08 add_multiplied_base
effect give @s minecraft:regeneration 20 0 true
