$attribute @s minecraft:max_health modifier add attrition:tier_hp $(hp) add_multiplied_base
$attribute @s minecraft:attack_damage modifier add attrition:tier_dmg $(dmg) add_multiplied_base
$attribute @s minecraft:movement_speed modifier add attrition:tier_spd $(spd) add_multiplied_base
$attribute @s minecraft:knockback_resistance modifier add attrition:tier_kb $(kb) add_value
$attribute @s minecraft:armor modifier add attrition:tier_arm $(arm) add_multiplied_base
$attribute @s minecraft:follow_range modifier add attrition:tier_range $(range) add_multiplied_base
execute store result score #max atr.tmp run attribute @s minecraft:max_health get
execute store result entity @s Health float 1 run scoreboard players get #max atr.tmp
