# four or more together: they coordinate
attribute @s minecraft:movement_speed modifier remove attrition:pack
attribute @s minecraft:movement_speed modifier add attrition:pack 0.08 add_multiplied_base
attribute @s minecraft:attack_damage modifier remove attrition:pack
attribute @s minecraft:attack_damage modifier add attrition:pack 0.12 add_multiplied_base
tag @s add atr.packed
