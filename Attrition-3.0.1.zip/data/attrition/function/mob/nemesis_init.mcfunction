tag @s add atr.nemesis
data merge entity @s {PersistenceRequired:1b,Glowing:1b}
data modify entity @s CustomNameVisible set value 1b
data modify entity @s CustomName set value {text:"Nemesis",color:"dark_red",italic:false}
attribute @s minecraft:max_health modifier add attrition:nemesis 1.5 add_multiplied_base
attribute @s minecraft:attack_damage modifier add attrition:nemesis 0.5 add_multiplied_base
attribute @s minecraft:movement_speed modifier add attrition:nemesis 0.15 add_multiplied_base
attribute @s minecraft:knockback_resistance modifier add attrition:nemesis 0.6 add_value
attribute @s minecraft:follow_range modifier add attrition:nemesis 3.0 add_multiplied_base
effect give @s minecraft:fire_resistance infinite 0 true
effect give @s minecraft:regeneration infinite 0 true
execute at @s run playsound minecraft:entity.wither.spawn master @a[distance=..40] ~ ~ ~ 0.6 1.6
