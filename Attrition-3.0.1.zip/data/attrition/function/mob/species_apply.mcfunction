# a species that has buried a hundred of its own learns something
execute unless score SPECIES_ON atr.cfg matches 1 run return 0
execute if entity @s[type=minecraft:zombie] if score #sp_zom atr.tmp matches 100.. run function attrition:mob/species_buff
execute if entity @s[type=minecraft:zombie] if score #sp_zom atr.tmp matches 400.. run function attrition:mob/species_buff2
execute if entity @s[type=minecraft:skeleton] if score #sp_ske atr.tmp matches 100.. run function attrition:mob/species_buff
execute if entity @s[type=minecraft:skeleton] if score #sp_ske atr.tmp matches 400.. run function attrition:mob/species_buff2
execute if entity @s[type=minecraft:creeper] if score #sp_cre atr.tmp matches 75.. run function attrition:mob/species_buff
execute if entity @s[type=minecraft:creeper] if score #sp_cre atr.tmp matches 300.. run function attrition:mob/species_buff2
execute if entity @s[type=minecraft:spider] if score #sp_spi atr.tmp matches 100.. run function attrition:mob/species_buff
execute if entity @s[type=minecraft:enderman] if score #sp_end atr.tmp matches 50.. run function attrition:mob/species_buff
execute if entity @s[type=minecraft:enderman] if score #sp_end atr.tmp matches 200.. run function attrition:mob/species_buff2
