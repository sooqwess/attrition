# runs for tagged trait mobs near players
execute as @e[tag=atr.tr_venom,distance=..6] at @s run effect give @a[distance=..3,gamemode=!creative,gamemode=!spectator] minecraft:poison 4 0 true
execute as @e[tag=atr.tr_frost,distance=..6] at @s run effect give @a[distance=..4,gamemode=!creative,gamemode=!spectator] minecraft:slowness 4 0 true
execute as @e[tag=atr.tr_blind,distance=..6] at @s if predicate attrition:chance_25 run effect give @a[distance=..4,gamemode=!creative,gamemode=!spectator] minecraft:blindness 3 0 true
execute as @e[tag=atr.tr_hollow,distance=..8] at @s if predicate attrition:chance_10 run function attrition:mob/trait/hollow_step
execute as @e[tag=atr.tr_frost,distance=..8] at @s if predicate attrition:chance_10 run particle minecraft:snowflake ~ ~1 ~ 0.4 0.4 0.4 0 6 normal
execute as @e[tag=atr.tr_venom,distance=..8] at @s if predicate attrition:chance_10 run particle minecraft:entity_effect{color:[0.2,0.6,0.2,1.0]} ~ ~1 ~ 0.4 0.4 0.4 0 4 normal
