# echo watchdog: notice the moment it stops existing
execute if entity @e[tag=atr.echo,limit=1] run scoreboard players set #seen_e atr.tmp 1
execute if score #seen_e atr.tmp matches 1 unless entity @e[tag=atr.echo,limit=1] run function attrition:mob/echo_gone
execute unless entity @e[tag=atr.echo,limit=1] run return 0
execute as @e[tag=atr.echo] at @s run function attrition:mob/echo_do
