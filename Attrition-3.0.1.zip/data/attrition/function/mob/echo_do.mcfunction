effect give @s minecraft:invisibility 6 0 true
execute as @a[distance=..16,gamemode=!spectator] run function attrition:mob/echo_near
execute if predicate attrition:chance_05 at @s run particle minecraft:soul ~ ~1 ~ 0.3 0.6 0.3 0.01 8 normal
