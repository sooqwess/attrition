execute if score @s atr.pact matches 0 run return 0
attribute @s minecraft:armor modifier remove attrition:pact_arm
attribute @s minecraft:max_health modifier remove attrition:pact_hp
attribute @s minecraft:attack_damage modifier remove attrition:pact_dmg
scoreboard players set @s atr.pact 0
scoreboard players set @s atr.toll 600
attribute @s minecraft:max_health modifier add attrition:death_toll -0.30 add_multiplied_base
tellraw @s {text:"  You broke your word. The world charges a fee.",color:"dark_red",italic:true}
playsound minecraft:entity.wither.hurt master @s ~ ~ ~ 1 0.5
advancement grant @s only attrition:pact_break
scoreboard players add @s atr.pactn 1
