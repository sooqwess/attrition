execute if score @s atr.pact matches 3 run return 0
scoreboard players set @s atr.pact 3
tellraw @s {text:"  Pact of Silence sealed. The Gloom loosens. Everything else notices.",color:"dark_purple",italic:true}
playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.7 0.5
function attrition:pact/seen
