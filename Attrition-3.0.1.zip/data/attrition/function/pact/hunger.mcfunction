execute if score @s atr.pact matches 2 run return 0
scoreboard players set @s atr.pact 2
attribute @s minecraft:attack_damage modifier add attrition:pact_dmg 0.20 add_multiplied_base
tellraw @s {text:"  Pact of Hunger sealed. You hit harder. You will never be full.",color:"gold",italic:true}
playsound minecraft:entity.generic.eat master @s ~ ~ ~ 0.8 0.6
function attrition:pact/seen
