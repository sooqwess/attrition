execute if score @s atr.pact matches 2 run effect give @s minecraft:hunger 3 0 true
execute if score @s atr.pact matches 3 if score @s atr.gloom matches 1.. if predicate attrition:chance_25 run scoreboard players remove @s atr.gloom 1
