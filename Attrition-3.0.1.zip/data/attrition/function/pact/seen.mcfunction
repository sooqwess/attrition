scoreboard players set #bit atr.tmp 1
execute if score @s atr.pact matches 2 run scoreboard players set #bit atr.tmp 2
execute if score @s atr.pact matches 3 run scoreboard players set #bit atr.tmp 4
scoreboard players operation #cur atr.tmp = @s atr.pseen
function attrition:player/bit_set
scoreboard players operation @s atr.pseen = #cur atr.tmp
execute if score @s atr.pseen matches 3.. run advancement grant @s only attrition:pact_two
execute if score @s atr.pseen matches 7 run advancement grant @s only attrition:pact_all
