execute if score @s atr.pact matches 1 run return 0
scoreboard players set @s atr.pact 1
attribute @s minecraft:armor modifier add attrition:pact_arm 2 add_value
attribute @s minecraft:max_health modifier add attrition:pact_hp -0.15 add_multiplied_base
tellraw @s {text:"  Pact of Iron sealed. Your skin is harder. There is less of you.",color:"gray",italic:true}
playsound minecraft:block.anvil_land master @s ~ ~ ~ 0.7 0.8
function attrition:pact/seen
