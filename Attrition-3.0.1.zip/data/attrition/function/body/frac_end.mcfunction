scoreboard players reset @s atr.frac
attribute @s minecraft:movement_speed modifier remove attrition:fracture
attribute @s minecraft:jump_strength modifier remove attrition:fracture
title @s actionbar {text:"The bone knit together",color:"gray",italic:true}
