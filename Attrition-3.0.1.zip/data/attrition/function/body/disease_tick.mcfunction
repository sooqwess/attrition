execute unless score @s atr.disease matches 1.. run return 0
scoreboard players remove @s atr.dtime 5
execute if score @s atr.dtime matches ..0 run function attrition:body/disease_end
execute if score @s atr.disease matches 1 if predicate attrition:chance_35 run effect give @s minecraft:hunger 8 0 true
execute if score @s atr.disease matches 1 if predicate attrition:chance_15 run scoreboard players add @s atr.infect 15
execute if score @s atr.disease matches 2 if predicate attrition:chance_25 run effect give @s minecraft:slowness 8 0 true
execute if score @s atr.disease matches 2 if predicate attrition:chance_15 run damage @s 1 attrition:infection
execute if score @s atr.disease matches 3 if predicate attrition:chance_25 run effect give @s minecraft:nausea 80 0 false
execute if score @s atr.disease matches 3 if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_35 run scoreboard players remove @s atr.sanity 2
execute if predicate attrition:chance_10 run playsound minecraft:entity.player.hurt master @s ~ ~ ~ 0.3 0.8
