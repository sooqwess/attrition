scoreboard players reset @s atr.bleed
title @s actionbar {text:"The bleeding stopped",color:"dark_gray",italic:true}
