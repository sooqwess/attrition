advancement revoke @s only attrition:trigger/slept
# sleep is rest, not a reset: it heals the body but feeds the Gloom
scoreboard players add @s atr.sanity 25
execute if score @s atr.bleed matches 1.. run scoreboard players remove @s atr.bleed 40
execute if score @s atr.frac matches 1.. run scoreboard players remove @s atr.frac 300
execute if score GLOOM_ON atr.cfg matches 1 run scoreboard players add @s atr.gloom 6
tellraw @s {text:"You slept. Something watched.",color:"dark_gray",italic:true}
scoreboard players set @s atr.stam 100
scoreboard players remove @s atr.grudge 10
execute if score @s atr.grudge matches ..0 run scoreboard players set @s atr.grudge 0
