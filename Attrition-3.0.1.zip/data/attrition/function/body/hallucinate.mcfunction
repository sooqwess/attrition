scoreboard players set #h atr.tmp 0
execute store result score #h atr.tmp run random value 1..6
execute if score #h atr.tmp matches 1 run playsound minecraft:entity.creeper.primed master @s ~ ~ ~ 0.7 1
execute if score #h atr.tmp matches 2 run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.7 0.7
execute if score #h atr.tmp matches 3 run playsound minecraft:entity.enderman.stare master @s ~ ~ ~ 0.6 1
execute if score #h atr.tmp matches 4 run playsound minecraft:block.portal.trigger master @s ~ ~ ~ 0.3 1.6
execute if score #h atr.tmp matches 5 run particle minecraft:smoke ^ ^1 ^4 0.4 0.9 0.4 0 40 normal @s
execute if score #h atr.tmp matches 6 run effect give @s minecraft:nausea 60 0 false
