execute unless score @s atr.disease matches 1.. run return 0
clear @s minecraft:golden_carrot 1
scoreboard players set @s atr.disease 0
scoreboard players set @s atr.dtime 0
effect give @s minecraft:regeneration 8 0 true
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The fever breaks.",color:"green"}]
advancement grant @s only attrition:cured
