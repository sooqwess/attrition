advancement revoke @s only attrition:trigger/ate_gapple
execute if score @s atr.infect matches 1.. run scoreboard players remove @s atr.infect 300
execute if score @s atr.infect matches ..0 run function attrition:body/infect_end
