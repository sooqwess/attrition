advancement revoke @s only attrition:trigger/ate_honey
execute if score @s atr.infect matches 1.. run scoreboard players remove @s atr.infect 150
execute if score @s atr.bleed matches 1.. run scoreboard players remove @s atr.bleed 20
execute if score @s atr.infect matches ..0 run function attrition:body/infect_end
