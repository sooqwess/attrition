execute store result score @s atr.load run clear @s #attrition:heavy 0
attribute @s minecraft:movement_speed modifier remove attrition:overload
execute if score @s atr.load matches 64..127 run attribute @s minecraft:movement_speed modifier add attrition:overload -0.06 add_multiplied_base
execute if score @s atr.load matches 128..255 run attribute @s minecraft:movement_speed modifier add attrition:overload -0.12 add_multiplied_base
execute if score @s atr.load matches 256..511 run attribute @s minecraft:movement_speed modifier add attrition:overload -0.20 add_multiplied_base
execute if score @s atr.load matches 512.. run attribute @s minecraft:movement_speed modifier add attrition:overload -0.30 add_multiplied_base
execute if score @s atr.load matches 512.. if predicate attrition:chance_10 run effect give @s minecraft:mining_fatigue 3 0 true
