# stamina: sprinting and jumping cost, standing still pays it back
execute unless score STAM_ON atr.cfg matches 1 run return 0
scoreboard players add @s atr.stam 0
execute unless score @s atr.stam matches -1.. run scoreboard players set @s atr.stam 100

# how far did we sprint in the last 5 s
scoreboard players operation #d atr.tmp = @s atr.sprint
scoreboard players operation #d atr.tmp -= @s atr.sprintp
scoreboard players operation @s atr.sprintp = @s atr.sprint
execute if score #d atr.tmp matches 200.. run scoreboard players remove @s atr.stam 8
execute if score #d atr.tmp matches 50..199 run scoreboard players remove @s atr.stam 4

# jumping is expensive when loaded
scoreboard players operation #j atr.tmp = @s atr.jump
scoreboard players operation #j atr.tmp -= @s atr.jumpp
scoreboard players operation @s atr.jumpp = @s atr.jump
execute if score #j atr.tmp matches 3.. run scoreboard players remove @s atr.stam 3
execute if score @s atr.load matches 256.. if score #j atr.tmp matches 1.. run scoreboard players remove @s atr.stam 2

# recovery
execute if score #d atr.tmp matches ..10 if score #j atr.tmp matches 0 run scoreboard players add @s atr.stam 9
execute if score @s atr.thirst matches ..25 run scoreboard players remove @s atr.stam 3
execute if score @s atr.temp matches 85.. run scoreboard players remove @s atr.stam 2
execute if score @s atr.bleed matches 100.. run scoreboard players remove @s atr.stam 2

execute if score @s atr.stam matches 100.. run scoreboard players set @s atr.stam 100
execute if score @s atr.stam matches ..0 run scoreboard players set @s atr.stam 0
function attrition:body/stamina_fx
