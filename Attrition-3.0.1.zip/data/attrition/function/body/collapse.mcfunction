# the body stops asking politely
damage @s 4 attrition:collapse
effect give @s minecraft:blindness 100 0 false
effect give @s minecraft:slowness 100 2 false
effect give @s minecraft:nausea 140 0 false
scoreboard players remove @s atr.stam 60
playsound minecraft:entity.player.big_fall master @s ~ ~ ~ 1 0.6
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Your body gives out. You have not slept in days.",color:"gray"}]
advancement grant @s only attrition:collapsed
