advancement revoke @s only attrition:trigger/drank_milk
# milk no longer clears everything - it only softens
execute if score @s atr.infect matches 1.. run scoreboard players remove @s atr.infect 100
execute if score @s atr.gloom matches 1.. run scoreboard players remove @s atr.gloom 5
