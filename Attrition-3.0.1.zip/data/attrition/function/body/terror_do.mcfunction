scoreboard players add @s atr.terror 1
scoreboard players remove @s atr.sanity 20
scoreboard players add @s atr.gloom 10
effect give @s minecraft:nausea 200 0 false
effect give @s minecraft:blindness 60 0 false
effect give @s minecraft:weakness 300 0 true
playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 1 0.5
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"You did not rest. Something sat on your chest and watched.",color:"dark_purple"}]
execute if predicate attrition:chance_35 run summon minecraft:phantom ~ ~6 ~ {Tags:["atr.terror","atr.done"],Size:2}
execute if score @s atr.terror matches 5.. run advancement grant @s only attrition:terror_five
