# eating raw flesh in a world this sick is a decision
execute unless score TAINT_ON atr.cfg matches 1 run return 0
scoreboard players operation #r atr.tmp = @s atr.raw
scoreboard players operation #r atr.tmp += @s atr.raw2
scoreboard players operation #r atr.tmp += @s atr.raw3
scoreboard players operation #r atr.tmp += @s atr.raw4
scoreboard players operation #dr atr.tmp = #r atr.tmp
scoreboard players operation #dr atr.tmp -= @s atr.rawp
scoreboard players operation @s atr.rawp = #r atr.tmp
execute unless score #dr atr.tmp matches 1.. run return 0
scoreboard players add @s atr.tainted 1
effect give @s minecraft:hunger 120 0 false
execute if predicate attrition:chance_35 run effect give @s minecraft:poison 60 0 false
execute if predicate attrition:chance_25 run scoreboard players add @s atr.infect 60
execute if score ERA atr.world matches 2.. if predicate attrition:chance_15 run function attrition:body/disease_roll
title @s actionbar {text:"That was raw. Your stomach objects.",color:"dark_green",italic:true}
