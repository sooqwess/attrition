# --- cold ---
execute if score @s atr.temp matches ..25 run effect give @s minecraft:slowness 3 0 true
execute if score @s atr.temp matches ..15 run effect give @s minecraft:mining_fatigue 3 0 true
execute if score @s atr.temp matches ..15 run title @s actionbar {text:"You are freezing",color:"aqua",italic:true}
execute if score @s atr.temp matches ..5 if predicate attrition:chance_25 run damage @s 1 attrition:exposure
# --- heat ---
execute if score @s atr.temp matches 75.. run effect give @s minecraft:hunger 3 0 true
execute if score @s atr.temp matches 85.. run effect give @s minecraft:weakness 3 0 true
execute if score @s atr.temp matches 85.. run title @s actionbar {text:"Heat is draining you",color:"gold",italic:true}
execute if score @s atr.temp matches 95.. if predicate attrition:chance_25 run damage @s 1 minecraft:hot_floor
