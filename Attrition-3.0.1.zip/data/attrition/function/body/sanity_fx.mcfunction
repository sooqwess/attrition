# phantom sounds and shapes - no real threat, pure dread
execute if predicate attrition:chance_25 run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.7 0.6
execute if predicate attrition:chance_25 run playsound minecraft:entity.creeper.primed master @s ~ ~ ~ 0.4 0.7
execute if predicate attrition:chance_25 run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.5 0.5
execute if predicate attrition:chance_25 run playsound minecraft:entity.enderman.stare master @s ~ ~ ~ 0.3 1.0
execute if predicate attrition:chance_50 positioned ^ ^1 ^6 run particle minecraft:smoke ~ ~ ~ 0.2 0.6 0.2 0 12 force @s
