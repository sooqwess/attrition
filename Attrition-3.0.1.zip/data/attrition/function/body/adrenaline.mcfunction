scoreboard players set @s atr.adren 100
effect give @s minecraft:speed 5 0 true
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 2.0
title @s actionbar {text:"Adrenaline",color:"red",italic:true}
