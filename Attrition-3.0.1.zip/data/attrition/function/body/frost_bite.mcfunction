effect give @s minecraft:slowness 8 1 true
effect give @s minecraft:mining_fatigue 8 0 true
damage @s 2 attrition:exposure
execute if score BODY_ON atr.cfg matches 1 if predicate attrition:chance_25 run function attrition:body/frac_add
title @s actionbar {text:"Your fingers stop answering",color:"aqua",italic:true}
playsound minecraft:block.powder_snow.step master @s ~ ~ ~ 0.7 0.6
advancement grant @s only attrition:frostbitten
