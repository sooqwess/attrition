clear @s #attrition:splint 2
scoreboard players remove @s atr.frac 400
playsound minecraft:block.bamboo.break master @s ~ ~ ~ 1 0.8
title @s actionbar {text:"Splinted",color:"gray",italic:true}
