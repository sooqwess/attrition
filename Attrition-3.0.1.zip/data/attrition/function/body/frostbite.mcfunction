execute unless score TEMP_ON atr.cfg matches 1 run return 0
execute if predicate attrition:in_powder_snow run scoreboard players remove @s atr.temp 5
execute if predicate attrition:biome_cold if score IS_NIGHT atr.world matches 1 run scoreboard players remove @s atr.temp 2
execute if predicate attrition:biome_hot run scoreboard players add @s atr.temp 2
execute if score @s atr.temp matches ..8 if predicate attrition:chance_35 run function attrition:body/frost_bite
