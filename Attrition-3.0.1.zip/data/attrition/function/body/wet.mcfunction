scoreboard players operation #sw atr.tmp = @s atr.swim
scoreboard players operation #sw atr.tmp -= @s atr.swimp
scoreboard players operation @s atr.swimp = @s atr.swim
execute if score #sw atr.tmp matches 1.. run scoreboard players set @s atr.wet 60
execute if predicate attrition:in_water run scoreboard players set @s atr.wet 60
execute if predicate attrition:is_raining if predicate attrition:sees_sky run scoreboard players add @s atr.wet 10
execute if predicate attrition:on_fire run scoreboard players set @s atr.wet 0
execute if score @s atr.respite matches 3.. run scoreboard players remove @s atr.wet 12
execute if dimension minecraft:the_nether run scoreboard players remove @s atr.wet 20
scoreboard players remove @s atr.wet 4
execute if score @s atr.wet matches ..0 run scoreboard players set @s atr.wet 0
execute if score @s atr.wet matches 60.. run scoreboard players set @s atr.wet 60
execute if score @s atr.wet matches 30.. if score IS_NIGHT atr.world matches 1 run scoreboard players remove @s atr.temp 2
execute if score @s atr.wet matches 40.. if predicate attrition:chance_15 run title @s actionbar {text:"You are soaked through",color:"aqua",italic:true}
