scoreboard players add @s atr.bleed 40
execute if score @s atr.bleed matches 161.. run scoreboard players set @s atr.bleed 160
title @s actionbar {text:"You are bleeding",color:"red",italic:true}
playsound minecraft:entity.player.hurt master @s ~ ~ ~ 0.5 0.6
