execute if score @s atr.infect matches 1.. run return 0
scoreboard players set @s atr.infect 600
title @s actionbar {text:"Something got into the wound",color:"dark_green",italic:true}
playsound minecraft:entity.zombie_villager.converted master @s ~ ~ ~ 0.4 0.4
