scoreboard players remove @s atr.stam 12
scoreboard players remove @s atr.temp 2
execute if predicate attrition:chance_35 run effect give @s minecraft:weakness 10 0 true
execute if predicate attrition:chance_25 run effect give @s minecraft:mining_fatigue 10 0 true
execute if score SANITY_ON atr.cfg matches 1 run scoreboard players remove @s atr.sanity 2
execute if predicate attrition:chance_10 run title @s actionbar {text:"Your body is eating itself",color:"dark_red",italic:true}
