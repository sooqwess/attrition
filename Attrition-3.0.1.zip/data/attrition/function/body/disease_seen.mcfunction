scoreboard players set #bit atr.tmp 1
execute if score @s atr.disease matches 2 run scoreboard players set #bit atr.tmp 2
execute if score @s atr.disease matches 3 run scoreboard players set #bit atr.tmp 4
scoreboard players operation #cur atr.tmp = @s atr.dseen
function attrition:player/bit_set
scoreboard players operation @s atr.dseen = #cur atr.tmp
scoreboard players add @s atr.disn 1
execute if score @s atr.dseen matches 7 run advancement grant @s only attrition:disease_all
