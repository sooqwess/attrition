# thirst drains on a 5 s cycle; water is no longer scenery
execute unless score THIRST_ON atr.cfg matches 1 run return 0
scoreboard players remove @s atr.thirst 1
execute if predicate attrition:chance_50 if dimension minecraft:the_nether run scoreboard players remove @s atr.thirst 1
execute if score @s atr.temp matches 75.. run scoreboard players remove @s atr.thirst 1
execute if score @s atr.load matches 256.. if predicate attrition:chance_50 run scoreboard players remove @s atr.thirst 1
execute if predicate attrition:is_sprinting if predicate attrition:chance_50 run scoreboard players remove @s atr.thirst 1
execute if score @s atr.thirst matches ..0 run scoreboard players set @s atr.thirst 0
execute if score @s atr.thirst matches 100.. run scoreboard players set @s atr.thirst 100
function attrition:body/thirst_fx
