# hunger no longer just drains hearts; it takes the body apart
execute if predicate attrition:food/le_1 run function attrition:body/starve_hard
execute if predicate attrition:food/le_6 run scoreboard players remove @s atr.stam 5
execute if predicate attrition:food/le_6 if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_25 run scoreboard players remove @s atr.sanity 1
