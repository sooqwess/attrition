# 0 = freezing, 50 = neutral, 100 = heatstroke
scoreboard players add @s atr.temp 0
execute unless score @s atr.temp matches -1.. run scoreboard players set @s atr.temp 50

# drift back to neutral
execute if score @s atr.temp matches 51.. run scoreboard players remove @s atr.temp 1
execute if score @s atr.temp matches ..49 run scoreboard players add @s atr.temp 1

# cold sources
execute if predicate attrition:biome_cold run scoreboard players remove @s atr.temp 2
execute if score @s atr.wet matches 1.. run scoreboard players remove @s atr.temp 2
execute if score IS_NIGHT atr.world matches 1 if predicate attrition:sees_sky run scoreboard players remove @s atr.temp 1
execute if predicate attrition:is_raining if predicate attrition:sees_sky run scoreboard players remove @s atr.temp 1
execute if predicate attrition:in_powder_snow run scoreboard players remove @s atr.temp 4

# heat sources
execute if dimension minecraft:the_nether run scoreboard players add @s atr.temp 3
execute positioned ~ ~ ~ if block ~ ~-1 ~ #minecraft:campfires run scoreboard players add @s atr.temp 4
execute positioned ~ ~ ~ if block ~ ~ ~ #minecraft:fire run scoreboard players add @s atr.temp 6
execute if predicate attrition:on_fire run scoreboard players add @s atr.temp 5

# clamp
execute if score @s atr.temp matches 101.. run scoreboard players set @s atr.temp 100
execute if score @s atr.temp matches ..0 run scoreboard players set @s atr.temp 0

# v2.1 heat and cold sources that actually fire
execute if predicate attrition:is_sprinting run scoreboard players add @s atr.temp 1
execute if score @s atr.load matches 256.. run scoreboard players add @s atr.temp 1
execute if score @s atr.stam matches ..10 run scoreboard players add @s atr.temp 1
execute if dimension minecraft:the_end if predicate attrition:sees_sky run scoreboard players remove @s atr.temp 1

# clamp again after the new sources
execute if score @s atr.temp matches 101.. run scoreboard players set @s atr.temp 100
execute if score @s atr.temp matches ..0 run scoreboard players set @s atr.temp 0

function attrition:body/temp_effects
