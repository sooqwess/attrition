execute if score BODY_ON atr.cfg matches 0 run return 0
execute if score BLEED_ON atr.cfg matches 1 if score @s atr.bleed matches 1.. run function attrition:body/bleed
execute if score INFECT_ON atr.cfg matches 1 if score @s atr.infect matches 1.. run function attrition:body/infect
execute if score @s atr.frac matches 1.. run function attrition:body/fracture
execute if score TEMP_ON atr.cfg matches 1 run function attrition:body/temperature
execute if score LOAD_ON atr.cfg matches 1 run function attrition:body/load
execute if score SANITY_ON atr.cfg matches 1 run function attrition:body/sanity
execute if score @s atr.adren matches 1.. run scoreboard players remove @s atr.adren 1
