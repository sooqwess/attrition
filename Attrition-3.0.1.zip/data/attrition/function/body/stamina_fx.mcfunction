execute if score @s atr.stam matches ..40 if predicate attrition:chance_25 run title @s actionbar {text:"Your legs are burning",color:"gray",italic:true}
execute if score @s atr.stam matches ..25 run effect give @s minecraft:slowness 6 0 true
execute if score @s atr.stam matches ..15 run effect give @s minecraft:mining_fatigue 6 0 true
execute if score @s atr.stam matches ..5 run effect give @s minecraft:slowness 6 1 true
execute if score @s atr.stam matches ..5 if predicate attrition:chance_35 run effect give @s minecraft:nausea 40 0 false
execute if score @s atr.stam matches ..0 if predicate attrition:chance_25 run damage @s 1 minecraft:starve
execute if score @s atr.stam matches 90.. if score @s atr.thirst matches 70.. run effect give @s minecraft:speed 6 0 true
