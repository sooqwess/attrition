advancement revoke @s only attrition:trigger/hurt_any
scoreboard players set @s atr.combat 12
execute if score @s atr.adren matches 0 if predicate attrition:chance_10 run function attrition:body/adrenaline
