advancement revoke @s only attrition:trigger/hurt_bite
execute if score INFECT_ON atr.cfg matches 0 run return 0
execute if predicate attrition:chance_15 run function attrition:body/infect_add
