scoreboard players remove @s atr.frac 1
execute if predicate attrition:chance_10 run effect give @s minecraft:slowness 2 0 true
execute if score @s atr.frac matches 1.. if predicate attrition:hold/splint if predicate attrition:is_sneaking run function attrition:body/splint
execute if score @s atr.frac matches 0 run function attrition:body/frac_end
