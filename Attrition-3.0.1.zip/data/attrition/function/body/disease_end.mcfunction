scoreboard players set @s atr.disease 0
scoreboard players set @s atr.dtime 0
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The sickness passes.",color:"gray"}]
