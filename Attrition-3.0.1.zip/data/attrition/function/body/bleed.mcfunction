scoreboard players remove @s atr.bleed 1
# damage over time, faster while sprinting
execute if score @s atr.bleed matches 1.. positioned ~ ~ ~ run particle minecraft:dust{color:[0.55,0.05,0.05],scale:1.0} ~ ~1 ~ 0.25 0.4 0.25 0 3 force @s
execute if score @s atr.bleed matches 1.. run scoreboard players add @s atr.tmp 0
execute if score @s atr.bleed matches 60.. run effect give @s minecraft:weakness 3 0 true
execute if score @s atr.bleed matches 100.. run effect give @s minecraft:mining_fatigue 3 0 true
execute if predicate attrition:chance_25 run damage @s 1 attrition:bleeding
execute if score @s atr.bleed matches 1.. if predicate attrition:hold/bandage if predicate attrition:is_sneaking run function attrition:body/bandage
execute if score @s atr.bleed matches 0 run function attrition:body/bleed_stop
