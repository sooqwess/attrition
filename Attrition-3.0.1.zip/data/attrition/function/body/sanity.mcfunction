scoreboard players add @s atr.sanity 0
execute unless score @s atr.sanity matches -1.. run scoreboard players set @s atr.sanity 100

# drains
execute if predicate attrition:in_darkness run scoreboard players remove @s atr.sanity 1
execute if score @s atr.gloom matches 50.. run scoreboard players remove @s atr.sanity 1
execute if score BM atr.world matches 1 run scoreboard players remove @s atr.sanity 1
execute if dimension minecraft:the_end run scoreboard players remove @s atr.sanity 1
# recovery
execute if predicate attrition:in_light if predicate attrition:sees_sky run scoreboard players add @s atr.sanity 2
execute positioned ~ ~ ~ if block ~ ~-1 ~ #minecraft:campfires run scoreboard players add @s atr.sanity 3
execute if entity @a[distance=..12,limit=1,gamemode=!spectator,tag=!atr.self] run scoreboard players add @s atr.sanity 1

execute if score @s atr.sanity matches 101.. run scoreboard players set @s atr.sanity 100
execute if score @s atr.sanity matches ..0 run scoreboard players set @s atr.sanity 0

execute if score @s atr.sanity matches ..40 if predicate attrition:chance_05 run function attrition:body/sanity_fx
execute if score @s atr.sanity matches ..20 run effect give @s minecraft:darkness 3 0 true
execute if score @s atr.sanity matches ..10 if predicate attrition:chance_10 run effect give @s minecraft:nausea 8 0 true
