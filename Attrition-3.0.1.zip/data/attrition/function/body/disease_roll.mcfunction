execute unless score DISEASE_ON atr.cfg matches 1 run return 0
execute if score @s atr.disease matches 1.. run return 0
scoreboard players set #r atr.tmp 0
execute store result score #r atr.tmp run random value 1..3
scoreboard players operation @s atr.disease = #r atr.tmp
scoreboard players set @s atr.dtime 9000
function attrition:body/disease_msg
function attrition:body/disease_seen
