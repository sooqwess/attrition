# swim in fresh water and crouch to drink; salt of the sea is not offered
execute unless predicate attrition:in_water run return 0
execute unless predicate attrition:is_sneaking run return 0
scoreboard players add @s atr.thirst 12
execute if score @s atr.thirst matches 100.. run scoreboard players set @s atr.thirst 100
execute if predicate attrition:chance_25 if score DISEASE_ON atr.cfg matches 1 run scoreboard players add @s atr.infect 40
playsound minecraft:entity.generic.drink master @s ~ ~ ~ 0.6 1.0
title @s actionbar {text:"You drink deep. It tastes of the ground.",color:"aqua",italic:true}
