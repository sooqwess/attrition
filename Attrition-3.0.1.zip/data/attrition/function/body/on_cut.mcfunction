advancement revoke @s only attrition:trigger/hurt_cut
execute if score BLEED_ON atr.cfg matches 0 run return 0
execute if predicate attrition:chance_35 run function attrition:body/bleed_add
