# one place where every bounded stat is kept inside its range
execute if score @s atr.sanity matches 101.. run scoreboard players set @s atr.sanity 100
execute if score @s atr.sanity matches ..-1 run scoreboard players set @s atr.sanity 0
execute if score @s atr.temp matches 101.. run scoreboard players set @s atr.temp 100
execute if score @s atr.temp matches ..-1 run scoreboard players set @s atr.temp 0
execute if score @s atr.thirst matches 101.. run scoreboard players set @s atr.thirst 100
execute if score @s atr.thirst matches ..-1 run scoreboard players set @s atr.thirst 0
execute if score @s atr.stam matches 101.. run scoreboard players set @s atr.stam 100
execute if score @s atr.stam matches ..-1 run scoreboard players set @s atr.stam 0
execute if score @s atr.noise matches 61.. run scoreboard players set @s atr.noise 60
execute if score @s atr.noise matches ..-1 run scoreboard players set @s atr.noise 0
execute if score @s atr.rage matches 101.. run scoreboard players set @s atr.rage 100
execute if score @s atr.rage matches ..-1 run scoreboard players set @s atr.rage 0
execute if score @s atr.grudge matches ..-1 run scoreboard players set @s atr.grudge 0
execute if score @s atr.gloom matches ..-1 run scoreboard players set @s atr.gloom 0
execute if score @s atr.bleed matches ..-1 run scoreboard players set @s atr.bleed 0
execute if score @s atr.wet matches ..-1 run scoreboard players set @s atr.wet 0
