advancement revoke @s only attrition:trigger/hurt_blast
execute if score BODY_ON atr.cfg matches 0 run return 0
execute if predicate attrition:chance_50 run function attrition:body/bleed_add
execute if predicate attrition:chance_25 run function attrition:body/frac_add
effect give @s minecraft:nausea 6 0 true
playsound minecraft:entity.player.hurt master @s ~ ~ ~ 0.8 0.5
