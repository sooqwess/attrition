scoreboard players remove @s atr.infect 1
effect give @s minecraft:hunger 3 0 true
execute if score @s atr.infect matches 300.. run effect give @s minecraft:weakness 3 0 true
execute if score @s atr.infect matches 450.. run effect give @s minecraft:nausea 4 0 true
execute if score @s atr.infect matches 550.. run damage @s 1 attrition:infection
execute if score @s atr.infect matches 1.. if predicate attrition:chance_05 positioned ~ ~ ~ run particle minecraft:entity_effect{color:[0.2,0.5,0.15,1.0]} ~ ~1.2 ~ 0.3 0.3 0.3 0 2 force @s
execute if score @s atr.infect matches 0 run function attrition:body/infect_end
