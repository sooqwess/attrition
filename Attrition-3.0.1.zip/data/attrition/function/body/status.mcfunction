tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"CONDITION",color:"red"}]
tellraw @s {text:"  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",color:"dark_gray"}
tellraw @s [{text:"  Bleeding    ",color:"dark_gray"},{score:{name:"@s",objective:"atr.bleed"},color:"red"}]
tellraw @s [{text:"  Infection   ",color:"dark_gray"},{score:{name:"@s",objective:"atr.infect"},color:"green"}]
tellraw @s [{text:"  Fracture    ",color:"dark_gray"},{score:{name:"@s",objective:"atr.frac"},color:"white"}]
tellraw @s [{text:"  Temperature ",color:"dark_gray"},{score:{name:"@s",objective:"atr.temp"},color:"aqua"},{text:"  / 100",color:"dark_gray"}]
tellraw @s [{text:"  Sanity      ",color:"dark_gray"},{score:{name:"@s",objective:"atr.sanity"},color:"light_purple"},{text:"  / 100",color:"dark_gray"}]
tellraw @s [{text:"  Load        ",color:"dark_gray"},{score:{name:"@s",objective:"atr.load"},color:"gold"}]
tellraw @s [{text:"  Gloom       ",color:"dark_gray"},{score:{name:"@s",objective:"atr.gloom"},color:"light_purple"}]
tellraw @s [{text:"  Scars       ",color:"dark_gray"},{score:{name:"@s",objective:"atr.scar"},color:"dark_red"},{text:"   permanent",color:"dark_gray",italic:true}]
tellraw @s [{text:"  Boss marks  ",color:"dark_gray"},{score:{name:"@s",objective:"atr.marks"},color:"gold"}]
tellraw @s ""
