scoreboard players reset @s atr.infect
title @s actionbar {text:"The fever broke",color:"gray",italic:true}
