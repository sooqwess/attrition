execute if score @s atr.frac matches 1.. run return 0
scoreboard players set @s atr.frac 900
attribute @s minecraft:movement_speed modifier add attrition:fracture -0.20 add_multiplied_base
attribute @s minecraft:jump_strength modifier add attrition:fracture -0.40 add_multiplied_base
title @s actionbar {text:"Your leg is broken",color:"gold",italic:true}
playsound minecraft:entity.player.attack.sweep master @s ~ ~ ~ 1 0.5
