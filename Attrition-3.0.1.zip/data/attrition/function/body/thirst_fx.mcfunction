execute if score @s atr.thirst matches ..40 if predicate attrition:chance_25 run title @s actionbar {text:"Your throat is dry",color:"gray",italic:true}
execute if score @s atr.thirst matches ..30 run effect give @s minecraft:slowness 6 0 true
execute if score @s atr.thirst matches ..20 run effect give @s minecraft:mining_fatigue 6 0 true
execute if score @s atr.thirst matches ..20 if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_25 run scoreboard players remove @s atr.sanity 1
execute if score @s atr.thirst matches ..10 run effect give @s minecraft:weakness 6 0 true
execute if score @s atr.thirst matches ..10 if predicate attrition:chance_25 run effect give @s minecraft:nausea 60 0 false
execute if score @s atr.thirst matches ..0 if predicate attrition:chance_35 run damage @s 2 minecraft:starve
