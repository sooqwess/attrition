# sleeping deep in the Gloom is not rest
execute unless score TERROR_ON atr.cfg matches 1 run return 0
scoreboard players operation #s atr.tmp = @s atr.sleep
scoreboard players operation #s atr.tmp -= @s atr.sleepp
scoreboard players operation @s atr.sleepp = @s atr.sleep
execute unless score #s atr.tmp matches 1.. run return 0
execute if score @s atr.gloom matches 70.. run function attrition:body/terror_do
execute if score @s atr.curse matches 1.. if predicate attrition:chance_50 run function attrition:body/terror_do
