# the game counts ticks since your last sleep; we count the consequences
execute unless score INSOM_ON atr.cfg matches 1 run return 0
scoreboard players operation @s atr.awake2 = @s atr.rest2
execute if score @s atr.awake2 matches 24000..47999 if predicate attrition:chance_15 run title @s actionbar {text:"You need to sleep",color:"dark_gray",italic:true}
execute if score @s atr.awake2 matches 48000.. run effect give @s minecraft:mining_fatigue 6 0 true
execute if score @s atr.awake2 matches 48000.. if score SANITY_ON atr.cfg matches 1 run scoreboard players remove @s atr.sanity 1
execute if score @s atr.awake2 matches 72000.. run effect give @s minecraft:weakness 6 0 true
execute if score @s atr.awake2 matches 72000.. if predicate attrition:chance_15 run function attrition:body/hallucinate
execute if score @s atr.awake2 matches 96000.. run effect give @s minecraft:slowness 6 0 true
execute if score @s atr.awake2 matches 96000.. if predicate attrition:chance_25 run effect give @s minecraft:blindness 40 0 false
execute if score @s atr.awake2 matches 120000.. if predicate attrition:chance_10 run function attrition:body/collapse
