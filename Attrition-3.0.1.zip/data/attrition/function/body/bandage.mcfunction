clear @s #attrition:bandage 1
scoreboard players remove @s atr.bleed 50
execute if score @s atr.bleed matches ..0 run scoreboard players set @s atr.bleed 0
effect give @s minecraft:regeneration 3 0 true
playsound minecraft:item.armor.equip_leather master @s ~ ~ ~ 0.8 1.2
title @s actionbar {text:"Wound bound",color:"gray",italic:true}
