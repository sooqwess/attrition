scoreboard players set #bit atr.tmp 1
execute if score @s atr.boon matches 2 run scoreboard players set #bit atr.tmp 2
execute if score @s atr.boon matches 3 run scoreboard players set #bit atr.tmp 4
execute if score @s atr.boon matches 4 run scoreboard players set #bit atr.tmp 8
execute if score @s atr.boon matches 5 run scoreboard players set #bit atr.tmp 16
execute if score @s atr.boon matches 6 run scoreboard players set #bit atr.tmp 32
scoreboard players operation #cur atr.tmp = @s atr.bseen
function attrition:player/bit_set
scoreboard players operation @s atr.bseen = #cur atr.tmp
scoreboard players add @s atr.boonn 1
execute if score @s atr.bseen matches 63 run advancement grant @s only attrition:boon_all
