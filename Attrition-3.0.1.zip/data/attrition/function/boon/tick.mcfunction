execute unless score @s atr.boon matches 1.. run return 0
scoreboard players remove @s atr.btime 5
execute if score @s atr.btime matches ..0 run function attrition:boon/clear
execute if score @s atr.boon matches 1 run scoreboard players add @s atr.temp 1
execute if score @s atr.boon matches 3 if predicate attrition:chance_50 run scoreboard players add @s atr.sanity 1
execute if score @s atr.boon matches 4 if score @s atr.bleed matches 1.. run scoreboard players remove @s atr.bleed 8
execute if score @s atr.boon matches 6 if score @s atr.thirst matches 1.. if predicate attrition:chance_50 run scoreboard players add @s atr.thirst 1
