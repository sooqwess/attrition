execute if score @s atr.boon matches 1.. run function attrition:boon/clear
scoreboard players set #r atr.tmp 0
execute store result score #r atr.tmp run random value 1..6
scoreboard players operation @s atr.boon = #r atr.tmp
scoreboard players set @s atr.btime 24000
function attrition:boon/announce
playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.9 1.2
particle minecraft:end_rod ~ ~1 ~ 0.4 0.8 0.4 0.02 40 normal
function attrition:boon/seen
scoreboard players add @s atr.shrinen 1
