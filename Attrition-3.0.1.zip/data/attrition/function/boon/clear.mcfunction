scoreboard players set @s atr.boon 0
scoreboard players set @s atr.btime 0
