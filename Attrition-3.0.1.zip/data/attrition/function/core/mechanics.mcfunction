tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"WHAT IS HAPPENING TO YOU",color:"red"}]
tellraw @s {text:"  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",color:"dark_gray"}
tellraw @s [{text:"  Threat      ",color:"dark_gray"},{text:"mobs get stronger the further you walk from spawn",color:"gray"}]
tellraw @s [{text:"  Eras        ",color:"dark_gray"},{text:"the world hardens on a schedule you cannot stop",color:"gray"}]
tellraw @s [{text:"  Body        ",color:"dark_gray"},{text:"bleeding, infection, fractures, cold, heat, load, sanity",color:"gray"}]
tellraw @s [{text:"  Gloom       ",color:"dark_gray"},{text:"dying stains you; the stain attracts things",color:"gray"}]
tellraw @s [{text:"  Traits      ",color:"dark_gray"},{text:"high tier mobs roll a trait: leech, thorned, volatile...",color:"gray"}]
tellraw @s [{text:"  Bosses      ",color:"dark_gray"},{text:"Wither, Dragon, Warden, Guardian, Ravager, Evoker rebuilt",color:"gray"}]
tellraw @s [{text:"  Events      ",color:"dark_gray"},{text:"ashfall, silence, swarm, coldsnap, hollow, harvest",color:"gray"}]
tellraw @s [{text:"  Depth       ",color:"dark_gray"},{text:"the deeper you dig, the heavier the world presses",color:"gray"}]
tellraw @s [{text:"  Packs       ",color:"dark_gray"},{text:"mobs that hunt together fight better",color:"gray"}]
tellraw @s [{text:"  Scars       ",color:"dark_gray"},{text:"every death leaves one; they never heal on their own",color:"gray"}]
tellraw @s [{text:"  Pacts       ",color:"dark_gray"},{text:"permanent trades - power now, price forever",color:"gray"}]
tellraw @s [{text:"  Full list   ",color:"dark_gray"},{text:"MECHANICS.md, shipped with the pack",color:"gray",italic:true}]
tellraw @s ""
