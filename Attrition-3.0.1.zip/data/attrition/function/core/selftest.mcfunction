# Self-test: proves the pack actually loaded and every subsystem is alive.
# Usage: /function attrition:core/selftest
tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"ATTRITION SELF-TEST",color:"red"}]
tellraw @s ""

# --- 1. core loaded? INIT is set at the very end of core/load ---
execute if score INIT atr.cfg matches 1 run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"core/load finished (INIT=1)",color:"gray"}]
execute unless score INIT atr.cfg matches 1 run tellraw @s [{text:"  [FAIL] ",color:"red"},{text:"core/load did NOT finish - the menu will not work",color:"red"}]

# --- 2. preset applied? ---
execute if score SCALE_PER atr.cfg matches 1.. run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"preset loaded, threat step = ",color:"gray"},{score:{name:"SCALE_PER",objective:"atr.cfg"},color:"yellow"},{text:" blocks",color:"gray"}]
execute unless score SCALE_PER atr.cfg matches 1.. run tellraw @s [{text:"  [FAIL] ",color:"red"},{text:"no preset - run  /trigger atr.act set 1",color:"red"}]

# --- 3. the ticking loop ---
execute if score DAY atr.world matches 0.. run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"tick loop alive, day ",color:"gray"},{score:{name:"DAY",objective:"atr.world"},color:"yellow"},{text:"  era ",color:"gray"},{score:{name:"ERA",objective:"atr.world"},color:"yellow"}]

# --- 4. player stats initialised ---
execute if score @s atr.thirst matches 0.. run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"body system: thirst ",color:"gray"},{score:{name:"@s",objective:"atr.thirst"},color:"aqua"},{text:"  temp ",color:"gray"},{score:{name:"@s",objective:"atr.temp"},color:"aqua"},{text:"  stamina ",color:"gray"},{score:{name:"@s",objective:"atr.stam"},color:"aqua"}]
execute unless score @s atr.thirst matches 0.. run tellraw @s [{text:"  [FAIL] ",color:"red"},{text:"body system not initialised for you",color:"red"}]

# --- 5. threat tier ---
execute if score @s atr.tier matches 0.. run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"threat tier here = ",color:"gray"},{score:{name:"@s",objective:"atr.tier"},color:"red"},{text:"  (distance ",color:"gray"},{score:{name:"@s",objective:"atr.dist"},color:"yellow"},{text:" blocks)",color:"gray"}]

# --- 6. predicates that the log complained about ---
execute if predicate attrition:biome_cold run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"biome_cold predicate works - you are in a COLD biome",color:"gray"}]
execute if predicate attrition:biome_hot run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"biome_hot predicate works - you are in a HOT biome",color:"gray"}]
execute unless predicate attrition:biome_cold unless predicate attrition:biome_hot run tellraw @s [{text:"  [OK]   ",color:"green"},{text:"biome predicates load (temperate biome here)",color:"gray"}]

# --- 7. triggers ---
scoreboard players enable @s atr.menu
scoreboard players enable @s atr.act
tellraw @s [{text:"  [OK]   ",color:"green"},{text:"triggers re-enabled: ",color:"gray"},{text:"/trigger atr.menu",color:"yellow"}]

# --- 8. counters ---
tellraw @s [{text:"  [i]    ",color:"aqua"},{text:"mobs tracked nearby: ",color:"gray"},{text:"see below",color:"dark_gray"}]
execute store result score #cnt atr.tmp if entity @e[type=#attrition:targets,distance=..64]
tellraw @s [{text:"  [i]    ",color:"aqua"},{text:"hostiles within 64 blocks: ",color:"gray"},{score:{name:"#cnt",objective:"atr.tmp"},color:"yellow"}]
execute store result score #cnt atr.tmp if entity @e[type=#attrition:targets,distance=..64,tag=atr.done]
tellraw @s [{text:"  [i]    ",color:"aqua"},{text:"of them already scaled: ",color:"gray"},{score:{name:"#cnt",objective:"atr.tmp"},color:"yellow"}]

tellraw @s ""
tellraw @s [{text:"  If every line says [OK], the pack is fully working.",color:"dark_gray",italic:true}]
tellraw @s [{text:"  ",color:"dark_gray"},{text:"[ Open menu ]",color:"yellow",click_event:{action:"run_command",command:"trigger atr.menu"},hover_event:{action:"show_text",value:{text:"Open the pack menu",color:"gray"}}}]
tellraw @s ""
