scoreboard players set CLK10 atr.tmp 0
function attrition:boss/cleanup
execute if score BOSS_ON atr.cfg matches 1 run function attrition:boss/watch
execute if score EVENT_ON atr.cfg matches 1 run function attrition:world/hazard
function attrition:world/blight_prune
function attrition:world/trader_roll
function attrition:world/trader_tick
function attrition:world/cairn_ward
