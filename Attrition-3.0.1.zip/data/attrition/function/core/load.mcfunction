# ============================================================
#  ATTRITION  by Sooqwess   -   v3.0  "Everything It Takes"
#  Minecraft Java 1.21.11+
# ============================================================

# ---- core objectives ----
scoreboard objectives add atr.cfg dummy
scoreboard objectives add atr.tmp dummy
scoreboard objectives add atr.world dummy
scoreboard objectives add atr.tier dummy {text:"Threat",color:"dark_red"}
scoreboard objectives add atr.gloom dummy {text:"Gloom",color:"dark_purple"}
scoreboard objectives add atr.deaths deathCount {text:"Deaths",color:"red"}
scoreboard objectives add atr.dist dummy
scoreboard objectives add atr.prog dummy
scoreboard objectives add atr.toll dummy
scoreboard objectives add atr.menu trigger
scoreboard objectives add atr.act trigger
scoreboard objectives add atr.floor dummy
scoreboard objectives add atr.ritual dummy
scoreboard objectives add atr.totem dummy
scoreboard objectives add atr.dtotal dummy
scoreboard objectives add atr.dday dummy
scoreboard objectives add atr.clk5 dummy
scoreboard objectives add atr.night dummy
scoreboard objectives add atr.gmax dummy
scoreboard objectives add atr.hunt dummy
scoreboard objectives add atr.starve dummy
scoreboard objectives add atr.elitek dummy
scoreboard objectives add atr.bmcnt dummy

# ---- v2.0: body state ----
scoreboard objectives add atr.food dummy
scoreboard objectives add atr.bleed dummy
scoreboard objectives add atr.infect dummy
scoreboard objectives add atr.frac dummy
scoreboard objectives add atr.temp dummy
scoreboard objectives add atr.wet dummy
scoreboard objectives add atr.awake dummy
scoreboard objectives add atr.load dummy
scoreboard objectives add atr.combat dummy
scoreboard objectives add atr.sanity dummy
scoreboard objectives add atr.adren dummy
scoreboard objectives add atr.rest dummy

# ---- v2.0: events, bosses, economy ----
scoreboard objectives add atr.boss dummy
scoreboard objectives add atr.phase dummy
scoreboard objectives add atr.bhp dummy
scoreboard objectives add atr.mark dummy
scoreboard objectives add atr.shard dummy
scoreboard objectives add atr.event dummy
scoreboard objectives add atr.pact dummy
scoreboard objectives add atr.streak dummy
scoreboard objectives add atr.kills dummy
scoreboard objectives add atr.scar dummy
scoreboard objectives add atr.depth dummy
scoreboard objectives add atr.packs dummy
scoreboard objectives add atr.marks dummy
scoreboard objectives add atr.rite dummy
scoreboard objectives add atr.watch dummy
scoreboard objectives add atr.thirst dummy
scoreboard objectives add atr.curse dummy
scoreboard objectives add atr.ctime dummy
scoreboard objectives add atr.boon dummy
scoreboard objectives add atr.btime dummy
scoreboard objectives add atr.disease dummy
scoreboard objectives add atr.dtime dummy
scoreboard objectives add atr.contract dummy
scoreboard objectives add atr.cprog dummy
scoreboard objectives add atr.rust dummy
scoreboard objectives add atr.nemesis dummy
scoreboard objectives add atr.echo dummy
scoreboard objectives add atr.storm dummy
scoreboard objectives add atr.shrine dummy
scoreboard objectives add atr.blight dummy
scoreboard objectives add atr.drink dummy
scoreboard objectives add atr.crafts dummy
scoreboard objectives add atr.stam dummy
scoreboard objectives add atr.awake2 dummy
scoreboard objectives add atr.noise dummy
scoreboard objectives add atr.dim dummy
scoreboard objectives add atr.dshock dummy
scoreboard objectives add atr.grave dummy
scoreboard objectives add atr.grudge dummy
scoreboard objectives add atr.score dummy
scoreboard objectives add atr.tainted dummy
scoreboard objectives add atr.spawnp dummy
scoreboard objectives add atr.sprintp dummy
scoreboard objectives add atr.minedp dummy
scoreboard objectives add atr.jumpp dummy
scoreboard objectives add atr.diap dummy
scoreboard objectives add atr.dbrisp dummy
scoreboard objectives add atr.rawp dummy
scoreboard objectives add atr.dmgp dummy
scoreboard objectives add atr.contracts dummy
scoreboard objectives add atr.events dummy
scoreboard objectives add atr.tally dummy
scoreboard objectives add atr.sprint minecraft.custom:minecraft.sprint_one_cm
scoreboard objectives add atr.walked minecraft.custom:minecraft.walk_one_cm
scoreboard objectives add atr.rest2 minecraft.custom:minecraft.time_since_rest
scoreboard objectives add atr.dia minecraft.mined:minecraft.diamond_ore
scoreboard objectives add atr.dbris minecraft.mined:minecraft.ancient_debris
scoreboard objectives add atr.raw minecraft.used:minecraft.beef
scoreboard objectives add atr.raw2 minecraft.used:minecraft.porkchop
scoreboard objectives add atr.raw3 minecraft.used:minecraft.chicken
scoreboard objectives add atr.raw4 minecraft.used:minecraft.cod
scoreboard objectives add atr.k_zom minecraft.killed:minecraft.zombie
scoreboard objectives add atr.k_ske minecraft.killed:minecraft.skeleton
scoreboard objectives add atr.k_cre minecraft.killed:minecraft.creeper
scoreboard objectives add atr.k_spi minecraft.killed:minecraft.spider
scoreboard objectives add atr.k_end minecraft.killed:minecraft.enderman
scoreboard objectives add atr.mined minecraft.mined:minecraft.stone
scoreboard objectives add atr.jump minecraft.custom:minecraft.jump
scoreboard objectives add atr.dmgtaken minecraft.custom:minecraft.damage_taken
scoreboard objectives add atr.sleep minecraft.custom:minecraft.sleep_in_bed

scoreboard objectives add atr.respite dummy
scoreboard objectives add atr.attune dummy
scoreboard objectives add atr.terror dummy
scoreboard objectives add atr.price dummy
scoreboard objectives add atr.trader dummy
scoreboard objectives add atr.reckon dummy
scoreboard objectives add atr.king dummy
scoreboard objectives add atr.kphase dummy
scoreboard objectives add atr.tradep dummy
scoreboard objectives add atr.enchp dummy
scoreboard objectives add atr.anvilp dummy
scoreboard objectives add atr.sleepp dummy
scoreboard objectives add atr.title dummy
scoreboard objectives add atr.swimp dummy
scoreboard objectives add atr.trade minecraft.custom:minecraft.traded_with_villager
scoreboard objectives add atr.ench minecraft.custom:minecraft.enchant_item
scoreboard objectives add atr.anvil minecraft.custom:minecraft.interact_with_anvil
scoreboard objectives add atr.swim minecraft.custom:minecraft.swim_one_cm
scoreboard objectives add atr.since_death minecraft.custom:minecraft.time_since_death

scoreboard objectives add atr.hp dummy
scoreboard objectives add atr.parry dummy
scoreboard objectives add atr.riposte dummy
scoreboard objectives add atr.streak2 dummy
scoreboard objectives add atr.blockp dummy
scoreboard objectives add atr.gear dummy
scoreboard objectives add atr.warn dummy
scoreboard objectives add atr.burn dummy
scoreboard objectives add atr.altitude dummy
scoreboard objectives add atr.suffoc dummy
scoreboard objectives add atr.endp dummy
scoreboard objectives add atr.nethert dummy
scoreboard objectives add atr.lastdmg dummy
scoreboard objectives add atr.rage dummy
scoreboard objectives add atr.focus dummy
scoreboard objectives add atr.block minecraft.custom:minecraft.damage_blocked_by_shield
scoreboard objectives add atr.dmgdealt minecraft.custom:minecraft.damage_dealt
scoreboard objectives add atr.dmgabs minecraft.custom:minecraft.damage_absorbed
scoreboard objectives add atr.fly minecraft.custom:minecraft.aviate_one_cm
scoreboard objectives add atr.climb minecraft.custom:minecraft.climb_one_cm
scoreboard objectives add atr.fall minecraft.custom:minecraft.fall_one_cm
scoreboard objectives add atr.boat minecraft.custom:minecraft.boat_one_cm
scoreboard objectives add atr.crouchp dummy
scoreboard objectives add atr.crouch minecraft.custom:minecraft.crouch_one_cm

scoreboard objectives add atr.cairn dummy
scoreboard objectives add atr.cairnt dummy
scoreboard objectives add atr.lantern dummy
scoreboard objectives add atr.still dummy
scoreboard objectives add atr.charm dummy
scoreboard objectives add atr.cloak dummy

scoreboard objectives add atr.cseen dummy
scoreboard objectives add atr.bseen dummy
scoreboard objectives add atr.dseen dummy
scoreboard objectives add atr.eseen dummy
scoreboard objectives add atr.tseen dummy
scoreboard objectives add atr.pseen dummy
scoreboard objectives add atr.sseen dummy
scoreboard objectives add atr.bosseen dummy
scoreboard objectives add atr.cursen dummy
scoreboard objectives add atr.boonn dummy
scoreboard objectives add atr.disn dummy
scoreboard objectives add atr.evn dummy
scoreboard objectives add atr.trn dummy
scoreboard objectives add atr.pactn dummy
scoreboard objectives add atr.shockn dummy
scoreboard objectives add atr.bossn dummy
scoreboard objectives add atr.fracn dummy
scoreboard objectives add atr.shrinen dummy
scoreboard objectives add atr.packn dummy
scoreboard objectives add atr.stormt dummy
scoreboard objectives add atr.blightn dummy
scoreboard objectives add atr.echon dummy
scoreboard objectives add atr.mendn dummy
scoreboard objectives add atr.dryrun dummy
scoreboard objectives add atr.playt dummy
scoreboard objectives add atr.quiett dummy
scoreboard objectives add atr.nofire dummy
scoreboard objectives add atr.bought dummy
scoreboard objectives add atr.hotcold dummy
scoreboard objectives add atr.deepn dummy

# ---- constants ----
scoreboard players set #-1 atr.cfg -1
scoreboard players set #2 atr.cfg 2
scoreboard players set #10 atr.cfg 10
scoreboard players set #100 atr.cfg 100

# ---- first install: apply default preset ----
execute unless score INIT atr.cfg matches 1 run function attrition:preset/attrition
scoreboard players set INIT atr.cfg 1

# ---- world state ----
scoreboard players add ERA atr.world 0
scoreboard players add DAY atr.world 0
scoreboard players add BM atr.world 0
scoreboard players add BMDAY atr.world 0
scoreboard players add BMCLK atr.world 0
scoreboard players add EVENT atr.world 0
scoreboard players add EVCLK atr.world 0

# ---- rules are re-applied on every load, not only on first install ----
function attrition:core/rules
function attrition:core/tick
scoreboard players set #two atr.tmp 2
