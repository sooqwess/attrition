tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"HOW TO NOT DIE IMMEDIATELY",color:"red"}]
tellraw @s {text:"  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",color:"dark_gray"}
tellraw @s {text:"  1  Craft a bandage on day one. You will bleed on day one.",color:"gray"}
tellraw @s {text:"  2  Crouch in water to drink. Thirst kills quieter than mobs.",color:"gray"}
tellraw @s {text:"  3  Sit by a campfire when hurt. Nothing else heals you for free.",color:"gray"}
tellraw @s {text:"  4  Distance from spawn is difficulty. Do not sprint east on day two.",color:"gray"}
tellraw @s {text:"  5  Sleep. Insomnia is worse than the phantoms it replaces.",color:"gray"}
tellraw @s {text:"  6  Carry less. Weight costs stamina, speed and thirst.",color:"gray"}
tellraw @s {text:"  7  Enchanting feeds the Gloom. Enchant on purpose, not on impulse.",color:"gray"}
tellraw @s {text:"  8  A shrine gives a boon. Build one before you need it.",color:"gray"}
tellraw @s {text:"  9  Go back for your grave. The health you lost is sitting in it.",color:"gray"}
tellraw @s {text:"  10 If it is too much, open the menu and take Tempered. No shame.",color:"gray"}
tellraw @s ""
