# Self-sustaining loop, 20 ticks (1 s)
schedule function attrition:core/tick 20t replace

# world state: eras, blood moon, events
function attrition:world/tick

# greet new players
execute as @a[tag=!atr.seen] run function attrition:core/first_install

# deaths (only for players who already respawned)
execute as @a[scores={atr.deaths=1..},nbt=!{Health:0.0f}] at @s run function attrition:player/on_death

# per-second player logic
execute as @a[gamemode=!spectator] at @s run function attrition:player/tick

# bosses
execute if score BOSS_ON atr.cfg matches 1 run function attrition:boss/tick

# mobs: scan every 2 s
scoreboard players add CLK atr.tmp 1
execute if score CLK atr.tmp matches 2.. run scoreboard players set CLK atr.tmp 0
execute if score CLK atr.tmp matches 0 as @a[gamemode=!spectator] at @s run function attrition:mob/scan

# housekeeping every 10 s
scoreboard players add CLK10 atr.tmp 1
execute if score CLK10 atr.tmp matches 10.. run function attrition:core/slow
