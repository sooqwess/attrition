# Toggle. Two plain 1->0 / 0->1 lines in a row always produced 1, hence the temp.
scoreboard players set #hud atr.tmp 0
execute if score HUD atr.cfg matches 1 run scoreboard players set #hud atr.tmp 1
execute if score #hud atr.tmp matches 1 run scoreboard players set HUD atr.cfg 0
execute if score #hud atr.tmp matches 0 run scoreboard players set HUD atr.cfg 1
execute if score HUD atr.cfg matches 0 run title @a actionbar ""
execute if score HUD atr.cfg matches 1 run tellraw @s [{text:"HUD ",color:"gray"},{text:"on",color:"green"}]
execute if score HUD atr.cfg matches 0 run tellraw @s [{text:"HUD ",color:"gray"},{text:"off",color:"red"}]
