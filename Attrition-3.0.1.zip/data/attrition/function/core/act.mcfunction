# dispatch for menu buttons - any player may /trigger, no op level needed
execute if score @s atr.act matches 1 run function attrition:preset/tempered
execute if score @s atr.act matches 2 run function attrition:preset/harsh
execute if score @s atr.act matches 3 run function attrition:preset/attrition
execute if score @s atr.act matches 4 run function attrition:core/hud_toggle
execute if score @s atr.act matches 5 run function attrition:core/reset
execute if score @s atr.act matches 6 run function attrition:core/status
execute if score @s atr.act matches 7 run function attrition:core/help
execute if score @s atr.act matches 8 run function attrition:pact/menu
execute if score @s atr.act matches 9 run function attrition:core/mechanics
execute if score @s atr.act matches 10 run function attrition:pact/iron
execute if score @s atr.act matches 11 run function attrition:pact/hunger
execute if score @s atr.act matches 12 run function attrition:pact/silence
execute if score @s atr.act matches 13 run function attrition:pact/break
execute if score @s atr.act matches 14 run function attrition:body/status
execute if score @s atr.act matches 15 run function attrition:core/mechanics2
execute if score @s atr.act matches 16 run function attrition:core/tips
execute if score @s atr.act matches 17 run function attrition:core/credits
scoreboard players set @s atr.act 0
