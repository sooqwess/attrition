tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"SYSTEMS, PART TWO",color:"red"}]
tellraw @s {text:"  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",color:"dark_gray"}
tellraw @s [{text:"  Stamina  ",color:"gray"},{text:"sprinting and jumping cost it; standing still gives it back",color:"dark_gray"}]
tellraw @s [{text:"  Thirst   ",color:"gray"},{text:"crouch in water to drink; the Nether drinks from you",color:"dark_gray"}]
tellraw @s [{text:"  Noise    ",color:"gray"},{text:"running, mining and fighting draw mobs from further away",color:"dark_gray"}]
tellraw @s [{text:"  Rage     ",color:"gray"},{text:"dealing damage adds power and strips armour",color:"dark_gray"}]
tellraw @s [{text:"  Focus    ",color:"gray"},{text:"crouch-walking out of combat makes you quiet and sharp",color:"dark_gray"}]
tellraw @s [{text:"  Parry    ",color:"gray"},{text:"block during combat for a riposte window; block late and pay",color:"dark_gray"}]
tellraw @s [{text:"  Respite  ",color:"gray"},{text:"a lit campfire is the only free mercy in this pack",color:"dark_gray"}]
tellraw @s [{text:"  Cairns   ",color:"gray"},{text:"place one; it wards mobs and calms the mind nearby",color:"dark_gray"}]
tellraw @s [{text:"  Grudge   ",color:"gray"},{text:"kill enough of one kind and that kind starts hunting you",color:"dark_gray"}]
tellraw @s [{text:"  Graves   ",color:"gray"},{text:"you lose max health until you return to where you died",color:"dark_gray"}]
tellraw @s [{text:"  The Price ",color:"gray"},{text:"enchanting, trading and anvils all feed the Gloom",color:"dark_gray"}]
tellraw @s [{text:"  Reckoning ",color:"gray"},{text:"era IV opens the last door. Something is behind it.",color:"dark_gray"}]
tellraw @s ""
