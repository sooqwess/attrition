tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"ATTRITION",color:"red"},{text:"  v3.0",color:"dark_gray"}]
tellraw @s {text:"  A survival hardcore overhaul for Minecraft Java 1.21.11.",color:"gray"}
tellraw @s ""
tellraw @s [{text:"  Author   ",color:"dark_gray"},{text:"Sooqwess",color:"white"}]
tellraw @s [{text:"  Built on ",color:"dark_gray"},{text:"Ascent + Wolfsbane",color:"gray"}]
tellraw @s [{text:"  Pack     ",color:"dark_gray"},{text:"datapack + resource pack, 69 languages",color:"gray"}]
tellraw @s ""
tellraw @s {text:"  Everything in this pack is a system, not a punishment. Mostly.",color:"dark_gray",italic:true}
tellraw @s ""
