execute if score @s atr.menu matches 1.. run function attrition:core/menu_show
scoreboard players enable @s atr.menu
execute if score @s atr.act matches 1.. run function attrition:core/act
scoreboard players enable @s atr.act
