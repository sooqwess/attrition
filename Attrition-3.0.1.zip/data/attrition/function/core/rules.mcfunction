execute if score RULES atr.cfg matches 0 run return 0
gamerule minecraft:players_sleeping_percentage 101
gamerule minecraft:natural_health_regeneration false
gamerule minecraft:spawn_phantoms true
difficulty hard
