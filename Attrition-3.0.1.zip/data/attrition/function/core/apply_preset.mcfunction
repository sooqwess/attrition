# Re-apply the new preset to every loaded mob, then announce it.
execute as @e[type=#attrition:targets] run attribute @s minecraft:max_health modifier remove attrition:tier_hp
execute as @e[type=#attrition:targets] run attribute @s minecraft:attack_damage modifier remove attrition:tier_dmg
execute as @e[type=#attrition:targets] run attribute @s minecraft:movement_speed modifier remove attrition:tier_spd
execute as @e[type=#attrition:targets] run attribute @s minecraft:knockback_resistance modifier remove attrition:tier_kb
execute as @e[type=#attrition:targets] run attribute @s minecraft:armor modifier remove attrition:tier_arm
execute as @e[type=#attrition:targets] run attribute @s minecraft:follow_range modifier remove attrition:tier_range
tag @e[tag=atr.done] remove atr.done
scoreboard players reset * atr.tier

execute if score GLOOM_ON atr.cfg matches 0 run scoreboard players set @a atr.gloom 0
execute if score GLOOM_ON atr.cfg matches 0 run scoreboard players set @a atr.floor 0

execute if score PRESET atr.cfg matches 3 run tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Preset applied: ",color:"gray"},{text:"ATTRITION",color:"dark_red"}]
execute if score PRESET atr.cfg matches 2 run tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Preset applied: ",color:"gray"},{text:"HARSH",color:"gold"}]
execute if score PRESET atr.cfg matches 1 run tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Preset applied: ",color:"gray"},{text:"TEMPERED",color:"green"}]
playsound minecraft:block.beacon.activate master @a ~ ~ ~ 0.6 0.8
