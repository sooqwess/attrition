tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"CONFIG KEYS",color:"red"},{text:"   /scoreboard players set <KEY> atr.cfg <N>",color:"dark_gray"}]
tellraw @s {text:"  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",color:"dark_gray"}
tellraw @s [{text:"  SCALE_PER MAX_TIER",color:"yellow"},{text:"  threat step in blocks, tier cap",color:"gray"}]
tellraw @s [{text:"  HP_PER DMG_PER SPD_PER KB_PER ARMOR_PER",color:"yellow"},{text:"  mob gain % per tier",color:"gray"}]
tellraw @s [{text:"  DEEP_BONUS NIGHT_BONUS",color:"yellow"},{text:"  depth and night surcharge",color:"gray"}]
tellraw @s [{text:"  HC_SPAWN SPAWN_BASE SPAWN_TIER",color:"yellow"},{text:"  scattered respawn",color:"gray"}]
tellraw @s [{text:"  GLOOM_ON GLOOM_RATE GLOOM_DECAY FLOOR_ON FLOOR_VAL",color:"yellow"},{text:"  the Gloom",color:"gray"}]
tellraw @s [{text:"  HUNGER_ON REGEN_MIN",color:"yellow"},{text:"  hunger and regeneration gate",color:"gray"}]
tellraw @s [{text:"  ERA_ON ERA1_DAY ERA2_DAY ERA3_DAY",color:"yellow"},{text:"  world eras",color:"gray"}]
tellraw @s [{text:"  BM_ON BM_PCT BM_CAP",color:"yellow"},{text:"  Blood Moon",color:"gray"}]
tellraw @s [{text:"  TOTEM_PEN DEATH_DEBUF WEAR_ON WEAR_MIN",color:"yellow"},{text:"  penalties and gear wear",color:"gray"}]
tellraw @s [{text:"  BODY_ON BLEED_ON INFECT_ON TEMP_ON LOAD_ON SANITY_ON",color:"yellow"},{text:"  v2.0 body systems",color:"gray"}]
tellraw @s [{text:"  BOSS_ON BOSS_PWR",color:"yellow"},{text:"  boss overhaul and its strength %",color:"gray"}]
tellraw @s [{text:"  EVENT_ON EVENT_PCT",color:"yellow"},{text:"  world events",color:"gray"}]
tellraw @s [{text:"  RULES ELITE_PER RITUAL_ON CREEPER_PCT HUD",color:"yellow"},{text:"  misc",color:"gray"}]
tellraw @s ""
