execute as @e[type=#attrition:targets] run attribute @s minecraft:max_health modifier remove attrition:tier_hp
execute as @e[type=#attrition:targets] run attribute @s minecraft:attack_damage modifier remove attrition:tier_dmg
execute as @e[type=#attrition:targets] run attribute @s minecraft:movement_speed modifier remove attrition:tier_spd
execute as @e[type=#attrition:targets] run attribute @s minecraft:knockback_resistance modifier remove attrition:tier_kb
execute as @e[type=#attrition:targets] run attribute @s minecraft:armor modifier remove attrition:tier_arm
execute as @e[type=#attrition:targets] run attribute @s minecraft:follow_range modifier remove attrition:tier_range
tag @e[tag=atr.done] remove atr.done
tellraw @s {text:"Mob modifiers cleared - they will be recalculated.",color:"gray"}
