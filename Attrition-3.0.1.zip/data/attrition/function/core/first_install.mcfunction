tag @s add atr.seen
scoreboard players add DAY atr.world 0
scoreboard players operation @s atr.dday = DAY atr.world
scoreboard players set @s atr.dtotal 0
tellraw @s ""
tellraw @s [{text:"  \u2588 ",color:"dark_red"},{text:"ATTRITION",color:"red"},{text:"  by Sooqwess",color:"dark_gray"}]
tellraw @s {text:"  The world was not made for you. It tolerates you - for now.",color:"gray",italic:true}
tellraw @s ""
tellraw @s [{text:"  Preset  ",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"  \u00b7  maximum cruelty",color:"dark_gray"}]
tellraw @s [{text:"  ",color:"dark_gray"},{text:"[ Settings ]",color:"yellow",click_event:{action:"run_command",command:"trigger atr.menu"},hover_event:{action:"show_text",value:{text:"Open the pack menu",color:"gray"}}},{text:"  "},{text:"[ Guide ]",color:"aqua",click_event:{action:"run_command",command:"trigger atr.act set 7"},hover_event:{action:"show_text",value:{text:"Config keys",color:"gray"}}}]
tellraw @s ""
scoreboard players set @s atr.thirst 100
scoreboard players set @s atr.stam 100
scoreboard players set @s atr.dim 0
scoreboard players set @s atr.temp 50
scoreboard players set @s atr.sanity 100
scoreboard players set @s atr.respite 0
scoreboard players enable @a atr.menu
scoreboard players enable @a atr.act
