advancement revoke @s only attrition:craft/surgery_kit
clear @s minecraft:shears[minecraft:custom_data~{attrition:{craft:"surgery_kit"}}]
give @s minecraft:shears[minecraft:item_model="attrition:surgery_kit",minecraft:item_name={translate:"attrition.item.field_surgery_kit",fallback:"Field Surgery Kit",color:"white",italic:false},minecraft:lore=[{translate:"attrition.lore.bring_something_to_bite_on",fallback:"Bring something to bite on.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"surgery_kit"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
advancement grant @s only attrition:craft_kit
