advancement revoke @s only attrition:craft/salt_ration
clear @s minecraft:dried_kelp[minecraft:custom_data~{attrition:{craft:"salt_ration"}}]
give @s minecraft:dried_kelp[minecraft:item_model="attrition:salt_ration",minecraft:item_name={translate:"attrition.item.salt_ration",fallback:"Salt Ration",color:"yellow",italic:false},minecraft:lore=[{translate:"attrition.lore.keeps_barely_food",fallback:"Keeps. Barely food.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"salt_ration"}}] 3
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
