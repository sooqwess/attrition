advancement revoke @s only attrition:craft/pact_token
clear @s minecraft:gold_ingot[minecraft:custom_data~{attrition:{craft:"pact_token"}}]
give @s minecraft:gold_ingot[minecraft:item_model="attrition:pact_token",minecraft:item_name={translate:"attrition.item.pact_token",fallback:"Pact Token",color:"gold",italic:false},minecraft:lore=[{translate:"attrition.lore.the_currency_of_bad_decisions",fallback:"The currency of bad decisions.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"pact_token"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
