advancement revoke @s only attrition:craft/everburning_torch
clear @s minecraft:torch[minecraft:custom_data~{attrition:{craft:"everburning_torch"}}]
give @s minecraft:torch[minecraft:item_model="attrition:everburning_torch",minecraft:item_name={translate:"attrition.item.everburning_torch",fallback:"Everburning Torch",color:"gold",italic:false},minecraft:lore=[{translate:"attrition.lore.the_dark_hates_it",fallback:"The dark hates it.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"everburning_torch"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
advancement grant @s only attrition:craft_torch
