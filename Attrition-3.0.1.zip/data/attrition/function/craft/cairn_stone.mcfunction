advancement revoke @s only attrition:craft/cairn_stone
clear @s minecraft:cobblestone[minecraft:custom_data~{attrition:{craft:"cairn_stone"}}]
give @s minecraft:cobblestone[minecraft:item_model="attrition:cairn_stone",minecraft:item_name={translate:"attrition.item.cairn_stone",fallback:"Cairn Stone",color:"gray",italic:false},minecraft:lore=[{translate:"attrition.lore.place_it_come_back_to_it",fallback:"Place it. Come back to it.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"cairn_stone"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
