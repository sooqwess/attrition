advancement revoke @s only attrition:craft/ward_charm
clear @s minecraft:amethyst_shard[minecraft:custom_data~{attrition:{craft:"ward_charm"}}]
give @s minecraft:amethyst_shard[minecraft:item_model="attrition:ward_charm",minecraft:item_name={translate:"attrition.item.ward_charm",fallback:"Ward Charm",color:"dark_aqua",italic:false},minecraft:lore=[{translate:"attrition.lore.it_listens_back",fallback:"It listens back.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"ward_charm"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
advancement grant @s only attrition:craft_ward
