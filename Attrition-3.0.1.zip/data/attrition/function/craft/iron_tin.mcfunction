advancement revoke @s only attrition:craft/iron_tin
clear @s minecraft:iron_ingot[minecraft:custom_data~{attrition:{craft:"iron_tin"}}]
give @s minecraft:iron_ingot[minecraft:item_model="attrition:iron_tin",minecraft:item_name={translate:"attrition.item.ration_tin",fallback:"Ration Tin",color:"gray",italic:false},minecraft:lore=[{translate:"attrition.lore.heavy_worth_carrying",fallback:"Heavy. Worth carrying.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"iron_tin"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
