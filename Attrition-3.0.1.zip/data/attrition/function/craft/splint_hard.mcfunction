advancement revoke @s only attrition:craft/splint_hard
clear @s minecraft:stick[minecraft:custom_data~{attrition:{craft:"splint_hard"}}]
give @s minecraft:stick[minecraft:item_model="attrition:splint_hard",minecraft:item_name={translate:"attrition.item.iron_splint",fallback:"Iron Splint",color:"gray",italic:false},minecraft:lore=[{translate:"attrition.lore.straightens_what_should_not_bend",fallback:"Straightens what should not bend.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"splint_hard"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
