advancement revoke @s only attrition:craft/gloom_lantern
clear @s minecraft:soul_lantern[minecraft:custom_data~{attrition:{craft:"gloom_lantern"}}]
give @s minecraft:soul_lantern[minecraft:item_model="attrition:gloom_lantern",minecraft:item_name={translate:"attrition.item.gloom_lantern",fallback:"Gloom Lantern",color:"light_purple",italic:false},minecraft:lore=[{translate:"attrition.lore.it_burns_what_is_in_you",fallback:"It burns what is in you.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"gloom_lantern"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
