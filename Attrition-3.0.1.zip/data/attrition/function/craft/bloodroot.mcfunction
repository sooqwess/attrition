advancement revoke @s only attrition:craft/bloodroot
clear @s minecraft:potion[minecraft:custom_data~{attrition:{craft:"bloodroot"}}]
give @s minecraft:potion[minecraft:item_model="attrition:bloodroot",minecraft:item_name={translate:"attrition.item.bloodroot_draught",fallback:"Bloodroot Draught",color:"dark_red",italic:false},minecraft:lore=[{translate:"attrition.lore.it_hurts_more_than_the_wound",fallback:"It hurts more than the wound.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"bloodroot"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
