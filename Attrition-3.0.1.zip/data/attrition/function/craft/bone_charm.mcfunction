advancement revoke @s only attrition:craft/bone_charm
clear @s minecraft:bone[minecraft:custom_data~{attrition:{craft:"bone_charm"}}]
give @s minecraft:bone[minecraft:item_model="attrition:bone_charm",minecraft:item_name={translate:"attrition.item.bone_charm",fallback:"Bone Charm",color:"white",italic:false},minecraft:lore=[{translate:"attrition.lore.someone_else_broke_first",fallback:"Someone else broke first.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"bone_charm"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
