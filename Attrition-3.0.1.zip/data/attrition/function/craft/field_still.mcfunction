advancement revoke @s only attrition:craft/field_still
clear @s minecraft:cauldron[minecraft:custom_data~{attrition:{craft:"field_still"}}]
give @s minecraft:cauldron[minecraft:item_model="attrition:field_still",minecraft:item_name={translate:"attrition.item.field_still",fallback:"Field Still",color:"aqua",italic:false},minecraft:lore=[{translate:"attrition.lore.boil_it_and_pray",fallback:"Boil it and pray.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"field_still"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
