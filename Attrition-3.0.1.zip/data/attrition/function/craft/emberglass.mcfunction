advancement revoke @s only attrition:craft/emberglass
clear @s minecraft:glass_bottle[minecraft:custom_data~{attrition:{craft:"emberglass"}}]
give @s minecraft:glass_bottle[minecraft:item_model="attrition:emberglass",minecraft:item_name={translate:"attrition.item.emberglass",fallback:"Emberglass",color:"gold",italic:false},minecraft:lore=[{translate:"attrition.lore.warmth_bottled_and_unwilling",fallback:"Warmth, bottled and unwilling.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"emberglass"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
