advancement revoke @s only attrition:craft/purified_water
clear @s minecraft:potion[minecraft:custom_data~{attrition:{craft:"purified_water"}}]
give @s minecraft:potion[minecraft:item_model="attrition:purified_water",minecraft:item_name={translate:"attrition.item.purified_water",fallback:"Purified Water",color:"aqua",italic:false},minecraft:lore=[{translate:"attrition.lore.safe_probably",fallback:"Safe. Probably.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"purified_water"}},minecraft:potion_contents={potion:"minecraft:water"}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
