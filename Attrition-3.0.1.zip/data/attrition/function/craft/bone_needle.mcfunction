advancement revoke @s only attrition:craft/bone_needle
clear @s minecraft:bone[minecraft:custom_data~{attrition:{craft:"bone_needle"}}]
give @s minecraft:bone[minecraft:item_model="attrition:bone_needle",minecraft:item_name={translate:"attrition.item.bone_needle",fallback:"Bone Needle",color:"white",italic:false},minecraft:lore=[{translate:"attrition.lore.for_wounds_that_will_not_close",fallback:"For wounds that will not close.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"bone_needle"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
