advancement revoke @s only attrition:craft/ashen_bandage
clear @s minecraft:paper[minecraft:custom_data~{attrition:{craft:"ashen_bandage"}}]
give @s minecraft:paper[minecraft:item_model="attrition:ashen_bandage",minecraft:item_name={translate:"attrition.item.ashen_bandage",fallback:"Ashen Bandage",color:"gray",italic:false},minecraft:lore=[{translate:"attrition.lore.it_has_seen_worse_than_you",fallback:"It has seen worse than you.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"ashen_bandage"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
