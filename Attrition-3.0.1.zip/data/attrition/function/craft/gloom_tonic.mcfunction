advancement revoke @s only attrition:craft/gloom_tonic
clear @s minecraft:honey_bottle[minecraft:custom_data~{attrition:{craft:"gloom_tonic"}}]
give @s minecraft:honey_bottle[minecraft:item_model="attrition:gloom_tonic",minecraft:item_name={translate:"attrition.item.gloom_tonic",fallback:"Gloom Tonic",color:"light_purple",italic:false},minecraft:lore=[{translate:"attrition.lore.tastes_like_forgetting",fallback:"Tastes like forgetting.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"gloom_tonic"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
advancement grant @s only attrition:craft_tonic
