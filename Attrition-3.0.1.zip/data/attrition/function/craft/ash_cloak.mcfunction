advancement revoke @s only attrition:craft/ash_cloak
clear @s minecraft:leather_chestplate[minecraft:custom_data~{attrition:{craft:"ash_cloak"}}]
give @s minecraft:leather_chestplate[minecraft:item_model="attrition:ash_cloak",minecraft:item_name={translate:"attrition.item.ash_cloak",fallback:"Ash Cloak",color:"dark_gray",italic:false},minecraft:lore=[{translate:"attrition.lore.the_dark_passes_over_you",fallback:"The dark passes over you.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"ash_cloak"}}] 1
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
