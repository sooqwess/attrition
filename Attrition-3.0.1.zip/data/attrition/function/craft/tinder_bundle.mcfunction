advancement revoke @s only attrition:craft/tinder_bundle
clear @s minecraft:dried_kelp[minecraft:custom_data~{attrition:{craft:"tinder_bundle"}}]
give @s minecraft:dried_kelp[minecraft:item_model="attrition:tinder_bundle",minecraft:item_name={translate:"attrition.item.tinder_bundle",fallback:"Tinder Bundle",color:"gold",italic:false},minecraft:lore=[{translate:"attrition.lore.fire_in_a_pocket_once",fallback:"Fire in a pocket, once.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"tinder_bundle"}}] 2
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
