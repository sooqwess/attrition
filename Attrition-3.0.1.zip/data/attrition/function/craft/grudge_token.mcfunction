advancement revoke @s only attrition:craft/grudge_token
clear @s minecraft:copper_ingot[minecraft:custom_data~{attrition:{craft:"grudge_token"}}]
give @s minecraft:copper_ingot[minecraft:item_model="attrition:grudge_token",minecraft:item_name={translate:"attrition.item.grudge_token",fallback:"Grudge Token",color:"red",italic:false},minecraft:lore=[{translate:"attrition.lore.pay_it_before_it_collects",fallback:"Pay it before it collects.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"grudge_token"}}] 4
scoreboard players add @s atr.crafts 1
advancement grant @s only attrition:craft_first
playsound minecraft:block.anvil_use master @s ~ ~ ~ 0.6 1.4
