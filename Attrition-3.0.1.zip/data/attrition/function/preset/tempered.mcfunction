# === TEMPERED - threat gradient only, no survival layer ===
scoreboard players set PRESET atr.cfg 1
scoreboard players set RULES atr.cfg 0
scoreboard players set SCALE_PER atr.cfg 2200
scoreboard players set MAX_TIER atr.cfg 8
scoreboard players set DEEP_BONUS atr.cfg 2
scoreboard players set NIGHT_BONUS atr.cfg 0
scoreboard players set HP_PER atr.cfg 12
scoreboard players set DMG_PER atr.cfg 8
scoreboard players set SPD_PER atr.cfg 2
scoreboard players set KB_PER atr.cfg 3
scoreboard players set ARMOR_PER atr.cfg 4
scoreboard players set HC_SPAWN atr.cfg 0
scoreboard players set SPAWN_BASE atr.cfg 300
scoreboard players set SPAWN_TIER atr.cfg 300
scoreboard players set DEATH_DEBUF atr.cfg 0
scoreboard players set GLOOM_ON atr.cfg 0
scoreboard players set GLOOM_RATE atr.cfg 1
scoreboard players set GLOOM_MAX atr.cfg 100
scoreboard players set GLOOM_DECAY atr.cfg 4
scoreboard players set HUNGER_ON atr.cfg 0
scoreboard players set REGEN_MIN atr.cfg 16
scoreboard players set CREEPER_PCT atr.cfg 6
scoreboard players set HUD atr.cfg 1

# --- v1.1 ---
scoreboard players set ERA_ON atr.cfg 1
scoreboard players set ERA1_DAY atr.cfg 12
scoreboard players set ERA2_DAY atr.cfg 30
scoreboard players set ERA3_DAY atr.cfg 60
scoreboard players set BM_ON atr.cfg 0
scoreboard players set BM_PCT atr.cfg 0
scoreboard players set BM_CAP atr.cfg 8
scoreboard players set TOTEM_PEN atr.cfg 0
scoreboard players set WEAR_ON atr.cfg 0
scoreboard players set WEAR_MIN atr.cfg 101
scoreboard players set FLOOR_ON atr.cfg 0
scoreboard players set FLOOR_VAL atr.cfg 0
scoreboard players set RITUAL_ON atr.cfg 1
scoreboard players set ELITE_PER atr.cfg 1

# --- v2.0: body ---
scoreboard players set BODY_ON atr.cfg 1
scoreboard players set BLEED_ON atr.cfg 1
scoreboard players set INFECT_ON atr.cfg 0
scoreboard players set TEMP_ON atr.cfg 0
scoreboard players set LOAD_ON atr.cfg 0
scoreboard players set SANITY_ON atr.cfg 0
# --- v2.0: bosses and events ---
scoreboard players set BOSS_ON atr.cfg 1
scoreboard players set BOSS_PWR atr.cfg 35
scoreboard players set EVENT_ON atr.cfg 0
scoreboard players set EVENT_PCT atr.cfg 0

# --- apply now ---
# --- v2.1: survival systems ---
scoreboard players set THIRST_ON atr.cfg 0
scoreboard players set NEMESIS_ON atr.cfg 0
scoreboard players set BLIGHT_ON atr.cfg 0
scoreboard players set CURSE_ON atr.cfg 0
scoreboard players set SHRINE_ON atr.cfg 1
scoreboard players set STORM_ON atr.cfg 0
scoreboard players set DISEASE_ON atr.cfg 0
scoreboard players set CONTRACT_ON atr.cfg 1
scoreboard players set RUST_ON atr.cfg 0
scoreboard players set ECHO_ON atr.cfg 0
scoreboard players set SCARCITY_ON atr.cfg 0


# --- v3.0: pressure systems ---
scoreboard players set STAM_ON atr.cfg 0
scoreboard players set INSOM_ON atr.cfg 0
scoreboard players set NOISE_ON atr.cfg 0
scoreboard players set DSHOCK_ON atr.cfg 0
scoreboard players set SPECIES_ON atr.cfg 0
scoreboard players set GRAVE_ON atr.cfg 1
scoreboard players set TAINT_ON atr.cfg 0
scoreboard players set BACKLASH_ON atr.cfg 0
scoreboard players set GRUDGE_ON atr.cfg 0


# --- v3.0: mercy, price and endgame ---
scoreboard players set RESPITE_ON atr.cfg 1
scoreboard players set ATTUNE_ON atr.cfg 1
scoreboard players set TERROR_ON atr.cfg 0
scoreboard players set PRICE_ON atr.cfg 0
scoreboard players set TRADER_ON atr.cfg 1
scoreboard players set RECKON_ON atr.cfg 1


# --- v3.0: combat and environment ---
scoreboard players set PARRY_ON atr.cfg 1
scoreboard players set RAGE_ON atr.cfg 1
scoreboard players set ALTITUDE_ON atr.cfg 0
scoreboard players set CAVEIN_ON atr.cfg 0
scoreboard players set REAP_ON atr.cfg 0

function attrition:core/rules
function attrition:core/apply_preset
