scoreboard players add @s atr.gloom 2
scoreboard players add @s atr.price 1
execute if score ERA atr.world matches 3.. run scoreboard players add @s atr.gloom 2
execute if predicate attrition:chance_15 run title @s actionbar {text:"Coin buys less every day",color:"dark_gray",italic:true}
scoreboard players add @s atr.bought 1
