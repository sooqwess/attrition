# phase A - gear, progress, advancement bookkeeping
execute if score @s atr.gloom >= WEAR_MIN atr.cfg run function attrition:player/wear
function attrition:player/counters
function attrition:player/ach_check
function attrition:player/rust
function attrition:player/tally
function attrition:player/titles
function attrition:pact/tick
function attrition:player/gate
function attrition:player/mark_cost
function attrition:player/counters2
