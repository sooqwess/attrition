function attrition:world/grudge_add
