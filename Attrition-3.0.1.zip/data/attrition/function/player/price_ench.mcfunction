scoreboard players add @s atr.gloom 12
scoreboard players remove @s atr.sanity 8
scoreboard players add @s atr.price 3
effect give @s minecraft:nausea 80 0 false
playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.5 1.4
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The enchantment takes something from you as well.",color:"dark_purple"}]
execute if score ERA atr.world matches 3.. if predicate attrition:chance_25 if score CURSE_ON atr.cfg matches 1 run function attrition:curse/apply
