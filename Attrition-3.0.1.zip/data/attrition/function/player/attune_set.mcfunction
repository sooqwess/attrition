attribute @s minecraft:armor_toughness modifier remove attrition:attune
attribute @s minecraft:knockback_resistance modifier remove attrition:attune
attribute @s minecraft:movement_speed modifier remove attrition:attune
execute if score #a atr.tmp matches 2 run attribute @s minecraft:knockback_resistance modifier add attrition:attune 0.1 add_value
execute if score #a atr.tmp matches 3 run attribute @s minecraft:armor_toughness modifier add attrition:attune 1 add_value
execute if score #a atr.tmp matches 5 run attribute @s minecraft:armor_toughness modifier add attrition:attune 2 add_value
execute if score #a atr.tmp matches 6 run attribute @s minecraft:knockback_resistance modifier add attrition:attune 0.2 add_value
execute if score #a atr.tmp matches 1 run attribute @s minecraft:movement_speed modifier add attrition:attune 0.04 add_multiplied_base
execute if score #a atr.tmp matches 1.. run title @s actionbar {text:"The set sits right on you",color:"gray",italic:true}
execute if score #a atr.tmp matches 1.. run advancement grant @s only attrition:attuned
