# radius = SPAWN_BASE + SPAWN_TIER * progress
scoreboard players operation #r atr.tmp = @s atr.prog
scoreboard players operation #r atr.tmp *= SPAWN_TIER atr.cfg
scoreboard players operation #r atr.tmp += SPAWN_BASE atr.cfg
execute store result storage attrition:calc spawn.r double 1 run scoreboard players get #r atr.tmp
execute in minecraft:overworld run function attrition:player/do_scatter with storage attrition:calc spawn
