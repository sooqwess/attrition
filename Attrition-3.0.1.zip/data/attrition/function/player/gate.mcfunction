# the deeper the era, the more the world resists your tools
execute if score ERA atr.world matches 2.. if predicate attrition:chance_05 run effect give @s minecraft:mining_fatigue 4 0 true
execute if score ERA atr.world matches 3.. if dimension minecraft:the_nether run effect give @s minecraft:weakness 4 0 true
execute if score ERA atr.world matches 4 if dimension minecraft:the_end run effect give @s minecraft:mining_fatigue 6 1 true
