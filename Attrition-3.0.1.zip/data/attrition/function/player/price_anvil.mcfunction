scoreboard players add @s atr.gloom 4
scoreboard players add @s atr.price 1
execute if predicate attrition:chance_25 run scoreboard players add @s atr.noise 4
scoreboard players add @s atr.mendn 1
