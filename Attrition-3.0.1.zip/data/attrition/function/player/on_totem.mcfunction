# Advancement reward: as <player>. Revoke the criterion or it fires only once.
advancement revoke @s only attrition:hidden/totem
execute if score TOTEM_PEN atr.cfg matches 0 run return 0

scoreboard players add @s atr.totem 1
# Debt penalty: twice as long as a normal death
scoreboard players set @s atr.toll 900
attribute @s minecraft:max_health modifier remove attrition:death_toll
attribute @s minecraft:max_health modifier add attrition:death_toll -0.40 add_multiplied_base
scoreboard players set @s atr.gloom 100

effect give @s minecraft:weakness 300 1 true
effect give @s minecraft:slowness 200 0 true
effect give @s minecraft:mining_fatigue 200 1 true
effect give @s minecraft:darkness 160 0 true
effect give @s minecraft:hunger 200 1 true

playsound minecraft:entity.wither.hurt master @s ~ ~ ~ 1 0.4
title @s times 5 50 15
title @s title {translate:"attrition.totem.title",fallback:"DEATH REMEMBERS",color:"dark_red"}
title @s subtitle {translate:"attrition.totem.sub",fallback:"It has a long memory",color:"gray"}
tellraw @s {translate:"attrition.totem.msg",fallback:"You stole your death from the world. The world takes interest.",color:"dark_red",italic:true}
function attrition:player/ach_totem
