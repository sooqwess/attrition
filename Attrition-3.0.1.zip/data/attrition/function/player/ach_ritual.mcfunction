advancement grant @s only attrition:gloom/ritual
