# phase B - held items and player-built structures
function attrition:item/use_scan
function attrition:item/use_crown
function attrition:body/drink
function attrition:gloom/ritual_scan
function attrition:player/rite_scan
function attrition:world/shrine_scan
function attrition:world/respite
function attrition:world/cairn_tick
function attrition:player/attune
function attrition:body/terror
function attrition:player/price
