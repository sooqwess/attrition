# Mortal attrition: -22% max HP for 6 minutes
scoreboard players set @s atr.toll 360
attribute @s minecraft:max_health modifier add attrition:death_toll -0.22 add_multiplied_base
effect give @s minecraft:weakness 240 0 true
effect give @s minecraft:slowness 240 0 true
effect give @s minecraft:mining_fatigue 180 0 true
effect give @s minecraft:hunger 60 0 true
execute if score SANITY_ON atr.cfg matches 1 run scoreboard players remove @s atr.sanity 30
execute if score BODY_ON atr.cfg matches 1 run scoreboard players set @s atr.frac 600
execute if score BODY_ON atr.cfg matches 1 run attribute @s minecraft:movement_speed modifier add attrition:fracture -0.20 add_multiplied_base
execute if score BODY_ON atr.cfg matches 1 run attribute @s minecraft:jump_strength modifier add attrition:fracture -0.40 add_multiplied_base
tellraw @s {text:"Death took a piece of you. It comes back slowly.",color:"dark_red",italic:true}
function attrition:player/scar_add
