# tier = distance/SCALE_PER  (+DEEP_BONUS if Y<=0, more if Y<=-40)
# (+NIGHT_BONUS at night in the overworld), clamped to 0..MAX_TIER

# 1) |x| and |z|
execute store result score #x atr.tmp run data get entity @s Pos[0]
execute store result score #z atr.tmp run data get entity @s Pos[2]
execute if score #x atr.tmp matches ..-1 run scoreboard players operation #x atr.tmp *= #-1 atr.cfg
execute if score #z atr.tmp matches ..-1 run scoreboard players operation #z atr.tmp *= #-1 atr.cfg

# 2) chebyshev distance
scoreboard players operation #d atr.tmp = #x atr.tmp
execute if score #z atr.tmp > #d atr.tmp run scoreboard players operation #d atr.tmp = #z atr.tmp
scoreboard players operation @s atr.dist = #d atr.tmp

# 3) base tier
scoreboard players operation #t atr.tmp = #d atr.tmp
scoreboard players operation #t atr.tmp /= SCALE_PER atr.cfg

# 4) depth
execute store result score #y atr.tmp run data get entity @s Pos[1]
execute if score #y atr.tmp matches ..0 run scoreboard players operation #t atr.tmp += DEEP_BONUS atr.cfg
execute if score #y atr.tmp matches ..-40 run scoreboard players operation #t atr.tmp += DEEP_BONUS atr.cfg

# 5) dimensions
execute if dimension minecraft:the_nether run scoreboard players add #t atr.tmp 3
execute if dimension minecraft:the_end run scoreboard players add #t atr.tmp 5

# 6) night in the overworld
execute if dimension minecraft:overworld if predicate attrition:is_night run scoreboard players operation #t atr.tmp += NIGHT_BONUS atr.cfg

# 7) player progress raises the bar on its own
scoreboard players operation #p atr.tmp = @s atr.prog
scoreboard players operation #p atr.tmp /= #2 atr.cfg
scoreboard players operation #t atr.tmp += #p atr.tmp

# 7b) world era and blood moon
scoreboard players operation #t atr.tmp += ERA atr.world
execute if score BM atr.world matches 1 run scoreboard players add #t atr.tmp 2

# 8) clamp
execute if score #t atr.tmp matches ..-1 run scoreboard players set #t atr.tmp 0
execute if score #t atr.tmp > MAX_TIER atr.cfg run scoreboard players operation #t atr.tmp = MAX_TIER atr.cfg
scoreboard players operation @s atr.tier = #t atr.tmp
