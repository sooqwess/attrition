# rite of mending - performed on gold over soul fire, costs a pact token
execute unless score @s atr.scar matches 1.. run return 0
execute unless score @s atr.rite matches 0 run return 0
execute unless block ~ ~-1 ~ minecraft:gold_block run return 0
execute unless block ~ ~-2 ~ minecraft:soul_fire run return 0
execute unless predicate attrition:hold/pact_token run return 0
execute unless predicate attrition:is_sneaking run return 0
scoreboard players set @s atr.rite 1200
clear @s minecraft:gold_ingot 1
function attrition:player/scar_heal
particle minecraft:soul ~ ~1 ~ 0.6 1 0.6 0.05 60 normal
