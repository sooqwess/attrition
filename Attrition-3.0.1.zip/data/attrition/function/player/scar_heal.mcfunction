# the rite of mending: one scar removed, at a real cost
execute unless score @s atr.scar matches 1.. run return 0
scoreboard players remove @s atr.scar 1
function attrition:player/scar_reapply
scoreboard players set @s atr.sanity 10
effect give @s minecraft:weakness 600 1 true
effect give @s minecraft:slowness 600 0 true
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"A scar closes. Something else opens.",color:"gray",italic:true}]
playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.8 0.6
advancement grant @s only attrition:mended
