# leather: warmth. chain: quiet. iron: carry. gold: the Gloom likes you. diamond: stone. netherite: fire.
execute if score @s atr.attune matches 1 if score @s atr.temp matches ..45 run scoreboard players add @s atr.temp 2
execute if score @s atr.attune matches 2 run scoreboard players remove @s atr.noise 2
execute if score @s atr.attune matches 3 if score @s atr.load matches 1.. run scoreboard players remove @s atr.load 32
execute if score @s atr.attune matches 4 if score @s atr.gloom matches 1.. run scoreboard players remove @s atr.gloom 1
execute if score @s atr.attune matches 4 if predicate attrition:chance_15 run scoreboard players add @s atr.grudge 1
execute if score @s atr.attune matches 5 if score @s atr.bleed matches 1.. run scoreboard players remove @s atr.bleed 4
execute if score @s atr.attune matches 6 if score @s atr.temp matches 80.. run scoreboard players remove @s atr.temp 4
execute if score @s atr.attune matches 10.. if score @s atr.thirst matches ..99 run scoreboard players add @s atr.thirst 1
