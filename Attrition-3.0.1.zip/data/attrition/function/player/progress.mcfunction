scoreboard players set @s atr.prog 0
execute if entity @s[advancements={minecraft:story/smelt_iron=true}] run scoreboard players add @s atr.prog 1
execute if entity @s[advancements={minecraft:story/obtain_armor=true}] run scoreboard players add @s atr.prog 1
execute if entity @s[advancements={minecraft:story/mine_diamond=true}] run scoreboard players add @s atr.prog 1
execute if entity @s[advancements={minecraft:story/enter_the_nether=true}] run scoreboard players add @s atr.prog 1
execute if entity @s[advancements={minecraft:nether/obtain_blaze_rod=true}] run scoreboard players add @s atr.prog 1
execute if entity @s[advancements={minecraft:story/enter_the_end=true}] run scoreboard players add @s atr.prog 1
execute if entity @s[advancements={minecraft:end/kill_dragon=true}] run scoreboard players add @s atr.prog 2
execute if entity @s[advancements={minecraft:nether/summon_wither=true}] run scoreboard players add @s atr.prog 2
