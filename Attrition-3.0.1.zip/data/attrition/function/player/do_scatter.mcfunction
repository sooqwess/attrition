$spreadplayers 0 0 200 $(r) false @s
tellraw @s ""
tellraw @s {translate:"attrition.scatter.1",fallback:"The world will not give your place back.",color:"dark_red",italic:true}
tellraw @s {translate:"attrition.scatter.2",fallback:"You woke up somewhere else.",color:"gray",italic:true}
tellraw @s ""
advancement grant @s only attrition:price/scatter
