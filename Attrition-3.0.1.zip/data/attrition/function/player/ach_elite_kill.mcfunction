advancement revoke @s only attrition:hidden/elite_kill
scoreboard players add @s atr.elitek 1
