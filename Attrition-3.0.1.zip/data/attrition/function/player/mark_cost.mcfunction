# the debt: marked players are hunted harder
execute if score @s atr.marks matches 1.. run scoreboard players add @s atr.gloom 1
execute if score @s atr.marks matches 2.. if predicate attrition:chance_05 run function attrition:gloom/hunt
execute if score @s atr.marks matches 3.. if score IS_NIGHT atr.world matches 1 if predicate attrition:chance_10 run effect give @s minecraft:glowing 40 0 true
