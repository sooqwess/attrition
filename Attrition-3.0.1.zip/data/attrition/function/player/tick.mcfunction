# as <player> at <player>, once per second
function attrition:player/hp_read
function attrition:player/threat_tier
execute if score GLOOM_ON atr.cfg matches 1 run function attrition:gloom/tick
execute if score HUNGER_ON atr.cfg matches 1 run function attrition:player/hunger
function attrition:player/progress
function attrition:body/tick

# death toll timer
execute if score @s atr.toll matches 1.. run scoreboard players remove @s atr.toll 1
execute if score @s atr.toll matches 0 run function attrition:player/clear_death_toll
execute if score @s atr.toll matches 0 run scoreboard players reset @s atr.toll

# ritual cooldown
execute if score @s atr.ritual matches 1.. run scoreboard players remove @s atr.ritual 1
# combat timer
execute if score @s atr.combat matches 1.. run scoreboard players remove @s atr.combat 1

# heavy logic every 5 s
scoreboard players add @s atr.clk5 1
execute if score @s atr.clk5 matches 5.. run function attrition:player/slow_tick

function attrition:body/clamp
function attrition:player/hud
function attrition:core/menu
function attrition:combat/riposte_tick
function attrition:combat/parry
