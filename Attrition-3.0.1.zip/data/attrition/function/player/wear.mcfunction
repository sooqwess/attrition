# as <player>. Called every 5 s while atr.gloom >= WEAR_MIN.
execute if score WEAR_ON atr.cfg matches 0 run return 0
execute if items entity @s armor.head *[minecraft:damage] run item modify entity @s armor.head attrition:wear
execute if items entity @s armor.chest *[minecraft:damage] run item modify entity @s armor.chest attrition:wear
execute if items entity @s armor.legs *[minecraft:damage] run item modify entity @s armor.legs attrition:wear
execute if items entity @s armor.feet *[minecraft:damage] run item modify entity @s armor.feet attrition:wear
execute if score @s atr.gloom matches 95.. run function attrition:player/wear_more
