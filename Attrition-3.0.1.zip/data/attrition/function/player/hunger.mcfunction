# Hunger. IMPORTANT: player foodLevel is unreadable via /data (MC-226615),
# so the food level is read through entity_properties predicates.
scoreboard players set @s atr.food 20
execute if predicate attrition:food/le_10 run scoreboard players set @s atr.food 10
execute if predicate attrition:food/le_6 run scoreboard players set @s atr.food 6
execute if predicate attrition:food/le_4 run scoreboard players set @s atr.food 4
execute if predicate attrition:food/le_3 run scoreboard players set @s atr.food 3
execute if predicate attrition:food/le_1 run scoreboard players set @s atr.food 1

# --- exhaustion ---
execute if predicate attrition:food/le_6 run effect give @s minecraft:weakness 3 0 true
execute if predicate attrition:food/le_4 run effect give @s minecraft:mining_fatigue 3 1 true
execute if predicate attrition:food/le_3 run effect give @s minecraft:slowness 3 0 true
execute if predicate attrition:food/le_1 run effect give @s minecraft:blindness 3 0 true

# --- starvation counter (feeds an advancement) ---
execute if predicate attrition:food/le_3 run scoreboard players add @s atr.starve 1
execute unless predicate attrition:food/le_3 run scoreboard players set @s atr.starve 0

# --- regeneration only on a full stomach (threshold = REGEN_MIN) ---
execute if score REGEN_MIN atr.cfg matches 20 if predicate attrition:food/full run effect give @s minecraft:regeneration 2 0 true
execute if score REGEN_MIN atr.cfg matches 19 if predicate attrition:food/ge_19 run effect give @s minecraft:regeneration 2 0 true
execute if score REGEN_MIN atr.cfg matches 17..18 if predicate attrition:food/ge_18 run effect give @s minecraft:regeneration 2 0 true
execute if score REGEN_MIN atr.cfg matches ..16 if predicate attrition:food/ge_16 run effect give @s minecraft:regeneration 2 0 true
