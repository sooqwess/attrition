# a live copy of health on the scoreboard, so predicates and logic can read it
execute store result score @s atr.hp run data get entity @s Health
