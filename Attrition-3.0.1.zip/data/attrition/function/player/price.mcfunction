# every convenience of civilisation is taxed by the Gloom
execute unless score PRICE_ON atr.cfg matches 1 run return 0
scoreboard players operation #t atr.tmp = @s atr.trade
scoreboard players operation #t atr.tmp -= @s atr.tradep
scoreboard players operation @s atr.tradep = @s atr.trade
execute if score #t atr.tmp matches 1.. run function attrition:player/price_trade

scoreboard players operation #e atr.tmp = @s atr.ench
scoreboard players operation #e atr.tmp -= @s atr.enchp
scoreboard players operation @s atr.enchp = @s atr.ench
execute if score #e atr.tmp matches 1.. run function attrition:player/price_ench

scoreboard players operation #v atr.tmp = @s atr.anvil
scoreboard players operation #v atr.tmp -= @s atr.anvilp
scoreboard players operation @s atr.anvilp = @s atr.anvil
execute if score #v atr.tmp matches 1.. run function attrition:player/price_anvil
