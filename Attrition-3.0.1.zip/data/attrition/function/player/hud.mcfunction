execute if score HUD atr.cfg matches 0 run return 0
# tidy single-line actionbar: BLOOD MOON / Threat / Gloom / Era / status marks
scoreboard players set #hud atr.tmp 0
execute if score @s atr.bleed matches 1.. run scoreboard players add #hud atr.tmp 1
execute if score @s atr.infect matches 1.. run scoreboard players add #hud atr.tmp 2
execute if score @s atr.frac matches 1.. run scoreboard players add #hud atr.tmp 4
execute if score @s atr.toll matches 1.. run scoreboard players add #hud atr.tmp 8

execute if score BM atr.world matches 1 run function attrition:player/hud_bm
execute if score BM atr.world matches 0 run function attrition:player/hud_std
