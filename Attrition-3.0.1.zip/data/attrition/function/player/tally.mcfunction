# one number that says how much of you the world has taken
scoreboard players set @s atr.tally 0
scoreboard players operation @s atr.tally += @s atr.dtotal
scoreboard players operation @s atr.tally += @s atr.scar
scoreboard players operation @s atr.tally += @s atr.marks
scoreboard players operation #x atr.tmp = @s atr.gloom
scoreboard players operation #x atr.tmp /= #10 atr.cfg
scoreboard players operation @s atr.tally += #x atr.tmp
scoreboard players operation @s atr.score = @s atr.elitek
scoreboard players operation @s atr.score += @s atr.contracts
scoreboard players operation @s atr.score += @s atr.crafts
scoreboard players operation #e atr.tmp = ERA atr.world
scoreboard players operation #e atr.tmp *= #10 atr.cfg
scoreboard players operation @s atr.score += #e atr.tmp
