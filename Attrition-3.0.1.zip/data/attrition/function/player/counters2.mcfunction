# --- everything that is simply "how many times" ---
execute if score @s atr.frac matches 1.. unless entity @s[tag=atr.fraccount] run function attrition:player/frac_count
execute if score @s atr.frac matches 0 run tag @s remove atr.fraccount

# storm survival: only counts outdoors, only counts unbroken
execute if predicate attrition:is_thundering if predicate attrition:sees_sky run scoreboard players add @s atr.stormt 5
execute unless predicate attrition:is_thundering run scoreboard players set @s atr.stormt 0
execute if score @s atr.stormt matches 300.. run advancement grant @s only attrition:storm_ride

# a quiet run: low noise for a long time
execute if score @s atr.noise matches ..5 run scoreboard players add @s atr.quiett 5
execute if score @s atr.noise matches 20.. run scoreboard players set @s atr.quiett 0
execute if score @s atr.quiett matches 600.. run advancement grant @s only attrition:noise_quiet

# a night with no light source in hand and no fire nearby
execute if score IS_NIGHT atr.world matches 1 unless entity @s[predicate=attrition:near_fire] run scoreboard players add @s atr.nofire 5
execute if score IS_NIGHT atr.world matches 0 run scoreboard players set @s atr.nofire 0
execute if score @s atr.nofire matches 400.. run advancement grant @s only attrition:no_fire_night

# total time played under Attrition
scoreboard players add @s atr.playt 5
execute if score @s atr.playt matches 3600.. run advancement grant @s only attrition:survive_hour

# thirst never bottomed out
execute if score @s atr.thirst matches ..0 run scoreboard players set @s atr.dryrun 1
execute if score ERA atr.world matches 3.. if score @s atr.dryrun matches 0 run advancement grant @s only attrition:thirst_never

# both ends of the thermometer in one life
execute if score @s atr.temp matches 95.. run scoreboard players add @s atr.hotcold 1
execute if score @s atr.temp matches ..5 run scoreboard players add @s atr.hotcold 1
execute if score @s atr.hotcold matches 2.. run advancement grant @s only attrition:temp_extreme

# standing in your own blight
execute if entity @e[type=minecraft:marker,tag=atr.blight,distance=..6,limit=1] run advancement grant @s only attrition:blight_walk
execute if score @s atr.blightn matches 5.. run advancement grant @s only attrition:blight_five
execute if score @s atr.dtotal matches 5.. run scoreboard players set @s atr.blightn 5

# echoes
execute if entity @e[tag=atr.echo,distance=..24,limit=1] run advancement grant @s only attrition:echo_meet
execute if score @s atr.echo matches 1.. run advancement grant @s only attrition:echo_kill

# shrines and contracts
execute if score @s atr.shrinen matches 3.. run advancement grant @s only attrition:shrine_three
execute if score @s atr.contracts matches 5.. run advancement grant @s only attrition:contract_five
execute if score @s atr.contracts matches 20.. run advancement grant @s only attrition:contract_twenty

# the deep
execute if score @s atr.depth matches ..-50 run advancement grant @s only attrition:depth_bottom
execute if score @s atr.depth matches ..-40 run scoreboard players add @s atr.deepn 5
execute if score @s atr.deepn matches 600.. run advancement grant @s only attrition:deep_pressure

# gear repair
execute if score @s atr.mendn matches 3.. run advancement grant @s only attrition:mend_three
execute if score @s atr.marks matches 6.. run advancement grant @s only attrition:marks_max
execute if score @s atr.packs matches 1.. run advancement grant @s only attrition:pack_break
execute if score @s atr.bought matches 1.. run advancement grant @s only attrition:trader_bought

# mob traits collection
function attrition:mob/trait_seen

# the completionist: every major system touched at least once
execute if score @s atr.cseen matches 1.. if score @s atr.bseen matches 1.. if score @s atr.dseen matches 1.. if score @s atr.eseen matches 1.. if score @s atr.pseen matches 1.. if score @s atr.crafts matches 1.. if score @s atr.contracts matches 1.. if score @s atr.marks matches 1.. run advancement grant @s only attrition:all_systems
