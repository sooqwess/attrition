# one scar per death, permanent max-health loss that stacks
scoreboard players add @s atr.scar 1
execute if score @s atr.scar matches 9.. run scoreboard players set @s atr.scar 9
attribute @s minecraft:max_health modifier remove attrition:scars
execute if score @s atr.scar matches 1 run attribute @s minecraft:max_health modifier add attrition:scars -0.06 add_multiplied_base
execute if score @s atr.scar matches 2 run attribute @s minecraft:max_health modifier add attrition:scars -0.12 add_multiplied_base
execute if score @s atr.scar matches 3 run attribute @s minecraft:max_health modifier add attrition:scars -0.18 add_multiplied_base
execute if score @s atr.scar matches 4 run attribute @s minecraft:max_health modifier add attrition:scars -0.24 add_multiplied_base
execute if score @s atr.scar matches 5 run attribute @s minecraft:max_health modifier add attrition:scars -0.30 add_multiplied_base
execute if score @s atr.scar matches 6 run attribute @s minecraft:max_health modifier add attrition:scars -0.36 add_multiplied_base
execute if score @s atr.scar matches 7 run attribute @s minecraft:max_health modifier add attrition:scars -0.42 add_multiplied_base
execute if score @s atr.scar matches 8 run attribute @s minecraft:max_health modifier add attrition:scars -0.48 add_multiplied_base
execute if score @s atr.scar matches 9 run attribute @s minecraft:max_health modifier add attrition:scars -0.54 add_multiplied_base
execute if score @s atr.scar matches 3.. run tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Your body remembers every death. ",color:"gray"},{score:{name:"@s",objective:"atr.scar"},color:"dark_red"},{text:" scars.",color:"gray"}]
