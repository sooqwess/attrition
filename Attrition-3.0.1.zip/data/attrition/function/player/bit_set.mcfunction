# #bit atr.tmp = bit value, #cur atr.tmp = current mask -> sets the bit in #cur
scoreboard players operation #q atr.tmp = #cur atr.tmp
scoreboard players operation #q atr.tmp /= #bit atr.tmp
scoreboard players operation #q atr.tmp %= #two atr.tmp
execute if score #q atr.tmp matches 0 run scoreboard players operation #cur atr.tmp += #bit atr.tmp
