# the world gives you a name based on what it has done to you
scoreboard players set #t atr.tmp 0
execute if score @s atr.score matches 20.. run scoreboard players set #t atr.tmp 1
execute if score @s atr.score matches 50.. run scoreboard players set #t atr.tmp 2
execute if score @s atr.score matches 100.. run scoreboard players set #t atr.tmp 3
execute if score @s atr.score matches 200.. run scoreboard players set #t atr.tmp 4
execute if score @s atr.tally matches 40.. if score #t atr.tmp matches 2.. run scoreboard players set #t atr.tmp 5
execute unless score @s atr.title = #t atr.tmp run function attrition:player/title_new
scoreboard players operation @s atr.title = #t atr.tmp
