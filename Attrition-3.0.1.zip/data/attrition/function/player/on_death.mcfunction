scoreboard players set @s atr.deaths 0
scoreboard players set @s atr.gloom 0
scoreboard players set @s atr.floor 0
scoreboard players add @s atr.dtotal 1
scoreboard players operation @s atr.dday = DAY atr.world
scoreboard players set @s atr.night 0
scoreboard players set @s atr.gmax 0
scoreboard players set @s atr.starve 0
execute if score HC_SPAWN atr.cfg matches 1 run function attrition:player/scatter
execute if score DEATH_DEBUF atr.cfg matches 1 run function attrition:player/death_debuff
execute at @s run function attrition:world/blight_seed
execute at @s run function attrition:mob/nemesis_make
execute at @s run function attrition:world/echo_spawn
execute if score CURSE_ON atr.cfg matches 1 if predicate attrition:chance_35 run function attrition:curse/apply
scoreboard players set @s atr.thirst 50
function attrition:world/grave_make
scoreboard players set @s atr.stam 40
scoreboard players set @s atr.noise 0
# --- v3.0: reset the volatile half of the body on death ---
scoreboard players set @s atr.rage 0
scoreboard players set @s atr.focus 0
scoreboard players set @s atr.stam 40
scoreboard players set @s atr.respite 0
scoreboard players set @s atr.riposte 0
scoreboard players set @s atr.wet 0
scoreboard players set @s atr.thirst 60
tag @s remove atr.cloaked
scoreboard players set @s atr.cloak 0
attribute @s minecraft:attack_damage modifier remove attrition:rage
attribute @s minecraft:armor modifier remove attrition:rage
