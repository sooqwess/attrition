# wearing one full set of anything is worth something
execute unless score ATTUNE_ON atr.cfg matches 1 run return 0
scoreboard players set #a atr.tmp 0
execute if items entity @s armor.head minecraft:leather_helmet if items entity @s armor.chest minecraft:leather_chestplate if items entity @s armor.legs minecraft:leather_leggings if items entity @s armor.feet minecraft:leather_boots run scoreboard players set #a atr.tmp 1
execute if items entity @s armor.head minecraft:chainmail_helmet if items entity @s armor.chest minecraft:chainmail_chestplate if items entity @s armor.legs minecraft:chainmail_leggings if items entity @s armor.feet minecraft:chainmail_boots run scoreboard players set #a atr.tmp 2
execute if items entity @s armor.head minecraft:iron_helmet if items entity @s armor.chest minecraft:iron_chestplate if items entity @s armor.legs minecraft:iron_leggings if items entity @s armor.feet minecraft:iron_boots run scoreboard players set #a atr.tmp 3
execute if items entity @s armor.head minecraft:golden_helmet if items entity @s armor.chest minecraft:golden_chestplate if items entity @s armor.legs minecraft:golden_leggings if items entity @s armor.feet minecraft:golden_boots run scoreboard players set #a atr.tmp 4
execute if items entity @s armor.head minecraft:diamond_helmet if items entity @s armor.chest minecraft:diamond_chestplate if items entity @s armor.legs minecraft:diamond_leggings if items entity @s armor.feet minecraft:diamond_boots run scoreboard players set #a atr.tmp 5
execute if items entity @s armor.head minecraft:netherite_helmet if items entity @s armor.chest minecraft:netherite_chestplate if items entity @s armor.legs minecraft:netherite_leggings if items entity @s armor.feet minecraft:netherite_boots run scoreboard players set #a atr.tmp 6
execute if items entity @s armor.head minecraft:turtle_helmet run scoreboard players add #a atr.tmp 10
execute unless score @s atr.attune = #a atr.tmp run function attrition:player/attune_set
scoreboard players operation @s atr.attune = #a atr.tmp
function attrition:player/attune_fx
