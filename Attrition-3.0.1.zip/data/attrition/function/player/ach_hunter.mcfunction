tag @s remove atr.hunted
advancement grant @s only attrition:gloom/hunter
