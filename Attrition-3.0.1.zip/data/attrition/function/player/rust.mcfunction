# metal remembers the rain
execute unless score RUST_ON atr.cfg matches 1 run return 0
execute unless score @s atr.wet matches 40.. run return 0
scoreboard players add @s atr.rust 1
execute if score @s atr.rust matches 12.. run function attrition:player/rust_bite
