execute if items entity @s armor.chest *[minecraft:damage] run item modify entity @s armor.chest attrition:wear_hard
execute if items entity @s weapon.mainhand *[minecraft:damage] run item modify entity @s weapon.mainhand attrition:wear_hard
