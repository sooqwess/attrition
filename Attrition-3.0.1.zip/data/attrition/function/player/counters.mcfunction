# as <player> at <player>. Counters that feed the advancements.

# night under open sky
execute if dimension minecraft:overworld if predicate attrition:is_night if predicate attrition:sees_sky run scoreboard players add @s atr.night 5
execute if predicate attrition:is_night unless predicate attrition:sees_sky run scoreboard players set @s atr.night 0

# time spent at the bottom of the Gloom
execute if score @s atr.gloom matches 100 run scoreboard players add @s atr.gmax 5
execute if score @s atr.gloom matches ..99 run scoreboard players set @s atr.gmax 0

# starvation
# hunger counters are handled in player/hunger via food predicates (MC-226615)

# survival timer after meeting the Hunter
execute if score @s atr.hunt matches 1.. run scoreboard players remove @s atr.hunt 5
execute if score @s atr.contract matches 1 run scoreboard players operation @s atr.cprog = @s atr.kills
execute if score @s atr.contract matches 2 run scoreboard players operation @s atr.cprog = @s atr.elitek
execute if score @s atr.contract matches 4 run scoreboard players operation @s atr.cprog = @s atr.mined
