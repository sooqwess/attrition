# as <player> at <player>, every 5 s. Cheap, per-player state only.
scoreboard players set @s atr.clk5 0
scoreboard players add @s atr.phase 1
execute if score @s atr.phase matches 3.. run scoreboard players set @s atr.phase 0

# --- body chemistry, every cycle ---
function attrition:body/thirst
function attrition:body/stamina
function attrition:body/wet
function attrition:body/starve
function attrition:body/frostbite
function attrition:curse/tick
function attrition:boon/tick
function attrition:body/disease_tick
function attrition:body/insomnia
function attrition:body/tainted
function attrition:combat/rage
function attrition:combat/focus

# --- timers, every cycle ---
function attrition:player/item_timers
execute if score @s atr.rite matches 1.. run scoreboard players remove @s atr.rite 5
execute if score @s atr.shrine matches 1.. run scoreboard players remove @s atr.shrine 5
execute if score @s atr.king matches 1.. run scoreboard players remove @s atr.king 5

# --- rotating heavy work ---
execute if score @s atr.phase matches 0 run function attrition:player/slow_a
execute if score @s atr.phase matches 1 run function attrition:player/slow_b
execute if score @s atr.phase matches 2 run function attrition:player/slow_c
