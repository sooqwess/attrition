execute if score @s atr.cairn matches 1.. run scoreboard players remove @s atr.cairn 5
execute if score @s atr.lantern matches 1.. run scoreboard players remove @s atr.lantern 5
execute if score @s atr.still matches 1.. run scoreboard players remove @s atr.still 5
execute if score @s atr.charm matches 1.. run scoreboard players remove @s atr.charm 5
execute if score @s atr.cloak matches 1.. run scoreboard players remove @s atr.cloak 5
execute if score @s atr.cloak matches ..0 run tag @s remove atr.cloaked
execute if entity @s[tag=atr.cloaked] run scoreboard players remove @s atr.noise 4
execute if entity @s[tag=atr.cloaked] if score @s atr.gloom matches 1.. if predicate attrition:chance_25 run scoreboard players remove @s atr.gloom 1
execute if score @s atr.lantern matches 1.. if score @s atr.gloom matches 1.. if predicate attrition:chance_50 run scoreboard players remove @s atr.gloom 1
execute if score @s atr.charm matches 1.. if score @s atr.frac matches 1.. run scoreboard players remove @s atr.frac 20
