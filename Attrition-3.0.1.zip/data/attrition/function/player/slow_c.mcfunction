# phase C - world pressure and the things that hunt you
function attrition:world/mining
function attrition:world/depth
function attrition:world/famine
function attrition:world/blight_tick
function attrition:world/contract_tick
function attrition:world/scarcity
function attrition:world/noise
function attrition:world/dim_watch
function attrition:world/backlash
function attrition:world/grudge
function attrition:world/grave_tick
function attrition:world/altitude
function attrition:world/nether_heat
function attrition:world/end_press
function attrition:world/lava_fear
function attrition:world/collapse_risk
function attrition:world/reckon_tick
execute if score BOSS_ON atr.cfg matches 1 run function attrition:mob/trait_tick
function attrition:mob/reap
function attrition:mob/last_stand
