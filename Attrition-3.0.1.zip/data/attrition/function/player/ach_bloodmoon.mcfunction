scoreboard players add @s atr.bmcnt 1
advancement grant @s only attrition:era/bloodmoon
