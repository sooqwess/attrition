advancement grant @s only attrition:price/totem
