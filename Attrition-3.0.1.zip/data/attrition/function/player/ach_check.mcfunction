# as <player>. Grant advancements from state. Re-granting is a no-op.

# --- root ---
advancement grant @s only attrition:root

# --- survival ---
execute if score @s atr.night matches 300.. run advancement grant @s only attrition:survive/first_night
scoreboard players operation #surv atr.tmp = DAY atr.world
scoreboard players operation #surv atr.tmp -= @s atr.dday
execute if score #surv atr.tmp matches 5.. if score @s atr.dtotal matches 0 run advancement grant @s only attrition:survive/day5
execute if score #surv atr.tmp matches 15.. if score @s atr.dtotal matches 0 run advancement grant @s only attrition:survive/day15
execute if score #surv atr.tmp matches 30.. if score @s atr.dtotal matches 0 run advancement grant @s only attrition:survive/day30
execute if score ERA atr.world matches 4.. if score @s atr.dtotal matches 0 run advancement grant @s only attrition:survive/no_death_era4

# --- gloom ---
execute if score @s atr.gloom matches 25.. run advancement grant @s only attrition:gloom/first
execute if score @s atr.gloom matches 50.. run advancement grant @s only attrition:gloom/half
execute if score @s atr.gmax matches 60.. run advancement grant @s only attrition:gloom/max
execute if score @s atr.hunt matches ..0 if entity @s[tag=atr.hunted] run function attrition:player/ach_hunter

# --- threat ---
execute if score @s atr.tier matches 5.. run advancement grant @s only attrition:threat/t5
execute if score @s atr.tier matches 10.. run advancement grant @s only attrition:threat/t10
execute if score @s atr.tier >= MAX_TIER atr.cfg run advancement grant @s only attrition:threat/t14
execute if score @s atr.elitek matches 1.. run advancement grant @s only attrition:threat/elite
execute if score @s atr.elitek matches 10.. run advancement grant @s only attrition:threat/elite10

# --- price ---
execute if score @s atr.dtotal matches 1.. run advancement grant @s only attrition:price/first_death
execute if score @s atr.totem matches 1.. run advancement grant @s only attrition:price/totem
execute if score @s atr.starve matches 180.. run advancement grant @s only attrition:price/starve

# --- journey ---
execute if entity @s[advancements={minecraft:story/smelt_iron=true}] run advancement grant @s only attrition:path/iron
execute if entity @s[advancements={minecraft:story/enter_the_nether=true}] run advancement grant @s only attrition:path/nether
execute if entity @s[advancements={minecraft:story/enter_the_end=true}] run advancement grant @s only attrition:path/end
execute if entity @s[advancements={minecraft:end/kill_dragon=true}] run advancement grant @s only attrition:path/dragon
execute if entity @s[advancements={minecraft:nether/summon_wither=true}] run advancement grant @s only attrition:path/wither
execute if score ERA atr.world matches 4 if entity @s[advancements={minecraft:end/kill_dragon=true,minecraft:nether/summon_wither=true}] run advancement grant @s only attrition:path/finish

# --- eras ---
execute if score ERA atr.world matches 1.. run advancement grant @s only attrition:era/e1
execute if score ERA atr.world matches 2.. run advancement grant @s only attrition:era/e2
execute if score ERA atr.world matches 3.. run advancement grant @s only attrition:era/e3
execute if score ERA atr.world matches 4.. run advancement grant @s only attrition:era/e4
execute if score @s atr.bmcnt matches 3.. run advancement grant @s only attrition:era/bloodmoon3
execute if score @s atr.scar matches 3.. run advancement grant @s only attrition:scarred
execute if score ERA atr.world matches 3.. if score @s atr.scar matches 0 run advancement grant @s only attrition:unmarred
execute if score @s atr.marks matches 3.. run advancement grant @s only attrition:marked_thrice
execute if score WATCH atr.world matches 6.. run advancement grant @s only attrition:night_six

# --- v2.1 ---
execute if score @s atr.drink matches 1.. run advancement grant @s only attrition:thirst_first
execute if score @s atr.thirst matches ..10 run advancement grant @s only attrition:thirst_low
execute if score @s atr.drink matches 100.. run advancement grant @s only attrition:drink_hundred
execute if score @s atr.curse matches 1.. run advancement grant @s only attrition:cursed_once
execute if score @s atr.boon matches 1.. run advancement grant @s only attrition:boon_first
execute if score @s atr.boon matches 1.. if score @s atr.curse matches 1.. run advancement grant @s only attrition:boon_stack
execute if score @s atr.nemesis matches 3.. run advancement grant @s only attrition:nemesis_three
execute if score @s atr.crafts matches 10.. run advancement grant @s only attrition:craft_all
execute if score @s atr.rust matches 1.. run advancement grant @s only attrition:rust_first
execute if score @s atr.scar matches 9 run advancement grant @s only attrition:scar_nine
execute if score @s atr.sanity matches ..0 run advancement grant @s only attrition:sanity_zero
execute if score @s atr.load matches 512.. run advancement grant @s only attrition:load_max
execute if score @s atr.bleed matches 160.. run advancement grant @s only attrition:bleed_max
execute if score @s atr.infect matches 550.. run advancement grant @s only attrition:infect_max
execute if score @s atr.elitek matches 10.. run advancement grant @s only attrition:elite_ten
execute if score @s atr.elitek matches 50.. run advancement grant @s only attrition:elite_fifty
execute if score @s atr.bmcnt matches 5.. run advancement grant @s only attrition:bloodmoon_five
execute if score ERA atr.world matches 4 run advancement grant @s only attrition:era_four
execute if score ERA atr.world matches 4 if score @s atr.scar matches 0 run advancement grant @s only attrition:scar_zero_era4
execute if score ERA atr.world matches 4 if score @s atr.dtotal matches 0 run advancement grant @s only attrition:no_death_era4
execute if score ERA atr.world matches 2.. if score @s atr.dtotal matches 0 run advancement grant @s only attrition:no_death_era2
execute if score ERA atr.world matches 3.. if score @s atr.curse matches 0 run advancement grant @s only attrition:no_curse_era3
execute if score WATCH atr.world matches 10.. run advancement grant @s only attrition:night_ten
execute if score DAY atr.world matches 30.. run advancement grant @s only attrition:survive_day30
execute if score @s atr.mined matches 1000.. run advancement grant @s only attrition:scarcity_deep

# --- v3.0 ---
execute if score @s atr.stam matches ..0 run advancement grant @s only attrition:stam_zero
execute if score @s atr.sprint matches 10000000.. run advancement grant @s only attrition:stam_marathon
execute if score @s atr.noise matches 60.. run advancement grant @s only attrition:noise_max
execute if score @s atr.tainted matches 10.. run advancement grant @s only attrition:tainted_ten
execute if score @s atr.grudge matches 60 run advancement grant @s only attrition:grudge_max
execute if score @s atr.grudge matches 0 if score @s atr.tainted matches 1.. run advancement grant @s only attrition:grudge_clear
execute if score @s atr.diap matches 1.. run advancement grant @s only attrition:backlash_first
execute if score @s atr.dbrisp matches 1.. run advancement grant @s only attrition:backlash_deep
execute if score @s atr.tally matches 50.. run advancement grant @s only attrition:tally_fifty
execute if score @s atr.score matches 100.. run advancement grant @s only attrition:score_hundred
execute if entity @e[tag=atr.wise,distance=..24,limit=1] run advancement grant @s only attrition:species_meet
execute if entity @e[tag=atr.elder,distance=..24,limit=1] run advancement grant @s only attrition:species_elder
execute if score EVTYPE atr.world matches 7 if score EVENT atr.world matches 1.. run advancement grant @s only attrition:event_heat
execute if score EVTYPE atr.world matches 8 if score EVENT atr.world matches 1.. run advancement grant @s only attrition:event_fog
execute if score EVTYPE atr.world matches 9 if score EVENT atr.world matches 1.. run advancement grant @s only attrition:event_meteor
execute if score EVTYPE atr.world matches 10 if score EVENT atr.world matches 1.. run advancement grant @s only attrition:event_quake
execute if score @s atr.price matches 3.. run advancement grant @s only attrition:price_paid
execute if score @s atr.title matches 1.. run advancement grant @s only attrition:title_survivor
execute if score @s atr.title matches 3 run advancement grant @s only attrition:title_unbroken
execute if score @s atr.title matches 4.. run advancement grant @s only attrition:title_attrition
execute if score @s atr.king matches 1.. run advancement grant @s only attrition:crown_used
execute if entity @e[tag=atr.trader,distance=..24,limit=1] run advancement grant @s only attrition:trader_met
execute if score @s atr.wet matches 40.. if predicate attrition:biome_cold if score IS_NIGHT atr.world matches 1 run advancement grant @s only attrition:wet_cold
execute if score @s atr.grave matches 0 if score @s atr.dtotal matches 5.. run advancement grant @s only attrition:grave_five
execute if score @s atr.parry matches 1.. run advancement grant @s only attrition:parry_first
execute if score @s atr.focus matches 60 run advancement grant @s only attrition:focus_full
execute if score @s atr.respite matches 24 run advancement grant @s only attrition:respite_long
execute if predicate attrition:food/le_1 run advancement grant @s only attrition:starving
execute if score @s atr.crafts matches 10.. run advancement grant @s only attrition:crafts_ten
execute if score @s atr.crafts matches 30.. run advancement grant @s only attrition:crafts_thirty
execute if entity @s[tag=atr.cloaked] if score IS_NIGHT atr.world matches 1 run advancement grant @s only attrition:cloak_night
execute if score @s atr.cursen matches 5.. run advancement grant @s only attrition:curse_five
execute if score @s atr.boonn matches 3.. run advancement grant @s only attrition:boon_three
execute if score @s atr.disn matches 3.. run advancement grant @s only attrition:sick_thrice
execute if score @s atr.evn matches 5.. run advancement grant @s only attrition:event_five
execute if score @s atr.shockn matches 10.. run advancement grant @s only attrition:shock_deep
execute if score @s atr.quiett matches 3600.. run advancement grant @s only attrition:quiet_hour
execute if score @s atr.playt matches 14400.. run advancement grant @s only attrition:play_four
execute if score @s atr.deepn matches 3000.. run advancement grant @s only attrition:deep_dweller
execute if score @s atr.stormt matches 600.. run advancement grant @s only attrition:storm_two
execute if score @s atr.bosseen matches 15 if score @s atr.crafts matches 20.. run advancement grant @s only attrition:collector
