tag @s add atr.fraccount
scoreboard players add @s atr.fracn 1
execute if score @s atr.fracn matches 3.. run advancement grant @s only attrition:frac_three
