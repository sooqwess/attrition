execute if score ERA atr.world matches 3 if score @s atr.gloom matches ..9 run advancement grant @s only attrition:gloom/clean_era3
