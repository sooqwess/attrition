scoreboard players set @s atr.rust 0
item modify entity @s armor.chest attrition:wear
item modify entity @s armor.legs attrition:wear
item modify entity @s weapon.mainhand attrition:wear
title @s actionbar {text:"Your gear is rusting",color:"dark_gray",italic:true}
