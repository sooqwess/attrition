scoreboard players add @s atr.marks 1
attribute @s minecraft:attack_damage modifier remove attrition:marks
execute if score @s atr.marks matches 1 run attribute @s minecraft:attack_damage modifier add attrition:marks 0.06 add_multiplied_base
execute if score @s atr.marks matches 2 run attribute @s minecraft:attack_damage modifier add attrition:marks 0.12 add_multiplied_base
execute if score @s atr.marks matches 3.. run attribute @s minecraft:attack_damage modifier add attrition:marks 0.20 add_multiplied_base
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"You are marked. The world notices marked things.",color:"gray",italic:true}]
