attribute @s minecraft:max_health modifier remove attrition:death_toll
tellraw @s {translate:"attrition.toll.clear",fallback:"You are whole again.",color:"gray",italic:true}
advancement grant @s only attrition:price/toll
