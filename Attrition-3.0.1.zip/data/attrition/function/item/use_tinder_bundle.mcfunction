clear @s minecraft:dried_kelp[minecraft:custom_data~{attrition:{item:"tinder_bundle"}}] 1
scoreboard players set @s atr.temp 62
scoreboard players set @s atr.wet 0
effect give @s minecraft:fire_resistance 20 0 true
particle minecraft:flame ~ ~0.4 ~ 0.4 0.2 0.4 0.02 40 normal
playsound minecraft:item.firecharge.use master @s ~ ~ ~ 0.8 1.0
title @s actionbar {text:"Warmth, briefly bought",color:"gold",italic:true}
advancement grant @s only attrition:craft_tinder
