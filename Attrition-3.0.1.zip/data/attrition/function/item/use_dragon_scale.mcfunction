clear @s minecraft:phantom_membrane[minecraft:custom_data~{attrition:{item:"dragon_scale"}}] 1
effect give @s minecraft:resistance 45 1 true
effect give @s minecraft:slow_falling 45 0 true
particle minecraft:dragon_breath ~ ~1 ~ 0.4 0.6 0.4 0.01 25 normal
playsound minecraft:entity.ender_dragon.flap master @s ~ ~ ~ 1 1.2
title @s actionbar {text:"Scaled against the world",color:"light_purple",italic:true}
