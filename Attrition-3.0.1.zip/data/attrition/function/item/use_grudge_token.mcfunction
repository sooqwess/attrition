execute unless score @s atr.grudge matches 1.. run return 0
clear @s minecraft:copper_ingot[minecraft:custom_data~{attrition:{item:"grudge_token"}}] 1
scoreboard players remove @s atr.grudge 25
execute if score @s atr.grudge matches ..0 run scoreboard players set @s atr.grudge 0
kill @e[tag=atr.hunter,distance=..48]
particle minecraft:flash{color:[1.0,0.85,0.2,1.0]} ~ ~1 ~ 0 0 0 1 1 normal
playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 1 0.8
title @s actionbar {text:"The debt shrinks",color:"red",italic:true}
advancement grant @s only attrition:craft_grudge
