clear @s minecraft:nether_star[minecraft:custom_data~{attrition:{item:"wither_sigil"}}] 1
scoreboard players set @s atr.toll 0
attribute @s minecraft:max_health modifier remove attrition:toll
effect clear @s minecraft:weakness
effect clear @s minecraft:mining_fatigue
particle minecraft:soul_fire_flame ~ ~1 ~ 0.4 0.6 0.4 0.02 30 normal
playsound minecraft:entity.wither_ambient master @s ~ ~ ~ 0.8 1.6
title @s actionbar {text:"The debt is paid for you",color:"dark_gray",italic:true}
