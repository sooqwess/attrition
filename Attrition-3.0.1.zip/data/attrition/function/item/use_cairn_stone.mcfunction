execute unless score @s atr.cairn matches ..0 run return 0
clear @s minecraft:cobblestone[minecraft:custom_data~{attrition:{item:"cairn_stone"}}] 1
kill @e[type=minecraft:marker,tag=atr.cairn,distance=..3]
summon minecraft:marker ~ ~ ~ {Tags:["atr.cairn"]}
scoreboard players set @s atr.cairn 200
particle minecraft:end_rod ~ ~1 ~ 0.3 1 0.3 0.02 40 normal
playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.7
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"A cairn stands here. The world respects it, a little.",color:"gray"}]
advancement grant @s only attrition:craft_cairn
