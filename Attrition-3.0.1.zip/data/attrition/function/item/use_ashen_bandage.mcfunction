clear @s minecraft:paper[minecraft:custom_data~{attrition:{item:"ashen_bandage"}}] 1
scoreboard players remove @s atr.bleed 160
execute if score @s atr.bleed matches ..0 run scoreboard players set @s atr.bleed 0
scoreboard players remove @s atr.infect 120
execute if score @s atr.infect matches ..0 run scoreboard players set @s atr.infect 0
effect give @s minecraft:regeneration 6 1 true
playsound minecraft:item.armor.equip_leather master @s ~ ~ ~ 0.9 1.4
title @s actionbar {text:"The bleeding stops completely",color:"gray",italic:true}
particle minecraft:composter ~ ~1 ~ 0.3 0.5 0.3 0 12 normal
