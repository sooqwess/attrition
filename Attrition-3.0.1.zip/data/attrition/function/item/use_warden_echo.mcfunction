clear @s minecraft:echo_shard[minecraft:custom_data~{attrition:{item:"warden_echo"}}] 1
effect give @s minecraft:invisibility 20 0 true
tag @s add atr.unseen
scoreboard players set @s atr.watch 400
particle minecraft:sculk_soul ~ ~1 ~ 0.4 0.6 0.4 0.02 30 normal
playsound minecraft:entity.warden_heartbeat master @s ~ ~ ~ 1 1.4
title @s actionbar {text:"Nothing can hear you",color:"dark_aqua",italic:true}
