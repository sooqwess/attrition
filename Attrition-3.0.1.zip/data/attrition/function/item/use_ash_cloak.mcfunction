clear @s minecraft:leather_chestplate[minecraft:custom_data~{attrition:{item:"ash_cloak"}}] 1
tag @s add atr.cloaked
scoreboard players set @s atr.cloak 2400
scoreboard players set @s atr.noise 0
particle minecraft:ash ~ ~1 ~ 0.5 1 0.5 0.02 60 normal
playsound minecraft:block.wool.place master @s ~ ~ ~ 0.8 0.7
title @s actionbar {text:"You go quiet",color:"dark_gray",italic:true}
advancement grant @s only attrition:craft_cloak
