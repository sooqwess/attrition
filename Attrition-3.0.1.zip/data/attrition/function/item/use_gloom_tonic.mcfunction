clear @s minecraft:honey_bottle[minecraft:custom_data~{attrition:{item:"gloom_tonic"}}] 1
give @s minecraft:glass_bottle 1
scoreboard players remove @s atr.gloom 45
execute if score @s atr.gloom matches ..0 run scoreboard players set @s atr.gloom 0
scoreboard players add @s atr.sanity 30
execute if score @s atr.sanity matches 100.. run scoreboard players set @s atr.sanity 100
effect give @s minecraft:regeneration 5 0 true
particle minecraft:witch ~ ~1 ~ 0.3 0.6 0.3 0.02 25 normal
playsound minecraft:entity.generic.drink master @s ~ ~ ~ 0.8 0.9
title @s actionbar {text:"The Gloom recedes",color:"light_purple",italic:true}
