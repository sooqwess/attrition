clear @s minecraft:bone[minecraft:custom_data~{attrition:{item:"bone_needle"}}] 1
scoreboard players set @s atr.frac 0
attribute @s minecraft:movement_speed modifier remove attrition:fracture
attribute @s minecraft:jump_strength modifier remove attrition:fracture
scoreboard players add @s atr.bleed 40
damage @s 4 attrition:bleeding
effect give @s minecraft:nausea 100 0 false
playsound minecraft:entity.player.hurt master @s ~ ~ ~ 1 0.7
title @s actionbar {text:"The bone is set. It was not gentle.",color:"gray",italic:true}
