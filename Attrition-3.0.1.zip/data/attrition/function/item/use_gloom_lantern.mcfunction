execute unless score @s atr.lantern matches ..0 run return 0
clear @s minecraft:soul_lantern[minecraft:custom_data~{attrition:{item:"gloom_lantern"}}] 1
scoreboard players set @s atr.lantern 6000
scoreboard players remove @s atr.gloom 30
execute if score @s atr.gloom matches ..0 run scoreboard players set @s atr.gloom 0
effect give @s minecraft:night_vision 300 0 true
particle minecraft:soul_fire_flame ~ ~1 ~ 0.4 0.8 0.4 0.02 50 normal
playsound minecraft:block.lantern.place master @s ~ ~ ~ 1 1.2
advancement grant @s only attrition:craft_lantern
