clear @s minecraft:stick[minecraft:custom_data~{attrition:{item:"splint_hard"}}] 1
scoreboard players set @s atr.frac 0
attribute @s minecraft:movement_speed modifier remove attrition:fracture
attribute @s minecraft:jump_strength modifier remove attrition:fracture
effect give @s minecraft:resistance 20 0 true
playsound minecraft:block.bone_block.place master @s ~ ~ ~ 0.8 0.9
title @s actionbar {text:"The bone is braced in iron",color:"gray",italic:true}
