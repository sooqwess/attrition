clear @s minecraft:amethyst_shard[minecraft:custom_data~{attrition:{item:"ward_charm"}}] 1
effect give @s minecraft:resistance 60 0 true
effect give @s minecraft:fire_resistance 60 0 true
tag @s add atr.warded
scoreboard players set @s atr.watch 600
particle minecraft:enchant ~ ~1 ~ 0.5 0.8 0.5 0.5 60 normal
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 0.8
title @s actionbar {text:"Something is standing between you and the world",color:"dark_aqua",italic:true}
