# sneak while holding a custom item to use it
execute unless predicate attrition:is_sneaking run return 0
execute if predicate attrition:hold/ashen_bandage run function attrition:item/use_ashen_bandage
execute if predicate attrition:hold/bone_needle if score @s atr.frac matches 1.. run function attrition:item/use_bone_needle
execute if predicate attrition:hold/emberglass if score @s atr.temp matches ..40 run function attrition:item/use_emberglass
execute if predicate attrition:hold/gloom_shard if score @s atr.gloom matches 10.. run function attrition:item/use_gloom_shard
execute if predicate attrition:hold/warden_echo run function attrition:item/use_warden_echo
execute if predicate attrition:hold/dragon_scale run function attrition:item/use_dragon_scale
execute if predicate attrition:hold/wither_sigil if score @s atr.toll matches 1.. run function attrition:item/use_wither_sigil
execute if predicate attrition:hold/gloom_tonic if score @s atr.gloom matches 20.. run function attrition:item/use_gloom_tonic
execute if predicate attrition:hold/ward_charm run function attrition:item/use_ward_charm
execute if predicate attrition:hold/surgery_kit if score @s atr.bleed matches 40.. run function attrition:item/use_surgery_kit
execute if predicate attrition:hold/splint_hard if score @s atr.frac matches 1.. run function attrition:item/use_splint_hard
execute if predicate attrition:hold/purified_water if score @s atr.thirst matches ..70 run function attrition:item/use_purified_water
execute if predicate attrition:hold/water_bottle if score @s atr.thirst matches ..70 run function attrition:item/use_bottle
execute if score @s atr.disease matches 1.. if predicate attrition:hold/golden_carrot run function attrition:body/cure_disease
execute if predicate attrition:hold/tinder_bundle run function attrition:item/use_tinder_bundle
execute if predicate attrition:hold/salt_ration run function attrition:item/use_salt_ration
execute if predicate attrition:hold/ash_cloak run function attrition:item/use_ash_cloak
execute if predicate attrition:hold/bloodroot if score @s atr.bleed matches 1.. run function attrition:item/use_bloodroot
execute if predicate attrition:hold/bone_charm run function attrition:item/use_bone_charm
execute if predicate attrition:hold/cairn_stone run function attrition:item/use_cairn_stone
execute if predicate attrition:hold/iron_tin run function attrition:item/use_iron_tin
execute if predicate attrition:hold/gloom_lantern run function attrition:item/use_gloom_lantern
execute if predicate attrition:hold/grudge_token run function attrition:item/use_grudge_token
execute if predicate attrition:hold/field_still run function attrition:item/use_field_still
