execute unless predicate attrition:hold/hollow_crown run return 0
execute unless score @s atr.king matches ..0 run return 0
scoreboard players set @s atr.king 1200
effect give @s minecraft:resistance 30 1 true
effect give @s minecraft:strength 30 0 true
effect give @s minecraft:regeneration 15 1 true
scoreboard players set @s atr.stam 100
scoreboard players set @s atr.thirst 100
scoreboard players set @s atr.bleed 0
particle minecraft:flash{color:[1.0,0.85,0.2,1.0]} ~ ~1 ~ 0 0 0 1 1 normal
playsound minecraft:item.totem.use master @s ~ ~ ~ 1 1.2
title @s actionbar {text:"The Crown answers",color:"gold",italic:true}
