clear @s minecraft:potion[minecraft:custom_data~{attrition:{item:"purified_water"}}] 1
give @s minecraft:glass_bottle 1
scoreboard players set @s atr.thirst 100
scoreboard players add @s atr.drink 1
execute if score @s atr.disease matches 1.. if predicate attrition:chance_35 run function attrition:body/disease_end
playsound minecraft:entity.generic.drink master @s ~ ~ ~ 0.9 1.3
title @s actionbar {text:"Clean, cold and safe",color:"aqua",italic:true}
