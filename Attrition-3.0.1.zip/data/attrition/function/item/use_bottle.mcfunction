# a water bottle is worth more than a bucket now
clear @s minecraft:potion[minecraft:potion_contents~["minecraft:water"]] 1
give @s minecraft:glass_bottle 1
scoreboard players add @s atr.thirst 45
execute if score @s atr.thirst matches 100.. run scoreboard players set @s atr.thirst 100
scoreboard players add @s atr.drink 1
playsound minecraft:entity.generic.drink master @s ~ ~ ~ 0.8 1.2
title @s actionbar {text:"Clean water",color:"aqua",italic:true}
