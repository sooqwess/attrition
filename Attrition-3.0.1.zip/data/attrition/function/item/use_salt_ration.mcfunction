clear @s minecraft:dried_kelp[minecraft:custom_data~{attrition:{item:"salt_ration"}}] 1
effect give @s minecraft:saturation 1 4 true
scoreboard players remove @s atr.thirst 20
scoreboard players add @s atr.stam 25
playsound minecraft:entity.generic.eat master @s ~ ~ ~ 0.8 1.0
title @s actionbar {text:"Dry, salted, enough",color:"yellow",italic:true}
advancement grant @s only attrition:craft_ration
