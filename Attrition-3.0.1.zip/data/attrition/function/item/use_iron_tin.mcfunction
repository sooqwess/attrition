clear @s minecraft:iron_ingot[minecraft:custom_data~{attrition:{item:"iron_tin"}}] 1
scoreboard players set @s atr.stam 100
effect give @s minecraft:saturation 1 6 true
scoreboard players add @s atr.thirst 10
playsound minecraft:entity.generic.eat master @s ~ ~ ~ 0.9 0.9
advancement grant @s only attrition:craft_tin
