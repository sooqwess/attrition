execute unless score @s atr.still matches ..0 run return 0
execute unless predicate attrition:in_water run return 0
scoreboard players set @s atr.still 1200
scoreboard players set @s atr.thirst 100
clear @s minecraft:glass_bottle 3
give @s minecraft:potion[minecraft:potion_contents={potion:"minecraft:water"},minecraft:item_name={translate:"attrition.item.purified_water",fallback:"Purified Water",color:"aqua",italic:false},minecraft:custom_data={attrition:{item:"purified_water"}}] 3
particle minecraft:cloud ~ ~1 ~ 0.4 0.5 0.4 0.05 40 normal
playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 1 1
title @s actionbar {text:"Clean water, at last",color:"aqua",italic:true}
advancement grant @s only attrition:craft_still
