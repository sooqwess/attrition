clear @s minecraft:amethyst_shard[minecraft:custom_data~{attrition:{item:"gloom_shard"}}] 1
scoreboard players remove @s atr.gloom 35
execute if score @s atr.gloom matches ..0 run scoreboard players set @s atr.gloom 0
scoreboard players add @s atr.sanity 15
execute if score @s atr.sanity matches 100.. run scoreboard players set @s atr.sanity 100
particle minecraft:soul ~ ~1 ~ 0.4 0.6 0.4 0.03 30 normal
playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1 0.8
title @s actionbar {text:"The stain fades a little",color:"light_purple",italic:true}
