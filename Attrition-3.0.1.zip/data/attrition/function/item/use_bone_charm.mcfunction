clear @s minecraft:bone[minecraft:custom_data~{attrition:{item:"bone_charm"}}] 1
scoreboard players set @s atr.frac 0
attribute @s minecraft:movement_speed modifier remove attrition:fracture
attribute @s minecraft:jump_strength modifier remove attrition:fracture
scoreboard players set @s atr.charm 3600
effect give @s minecraft:resistance 30 0 true
playsound minecraft:block.bone_block.place master @s ~ ~ ~ 0.9 1.3
title @s actionbar {text:"The bone holds",color:"white",italic:true}
advancement grant @s only attrition:craft_bonecharm
