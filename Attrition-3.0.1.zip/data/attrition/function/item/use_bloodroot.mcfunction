clear @s minecraft:potion[minecraft:custom_data~{attrition:{item:"bloodroot"}}] 1
scoreboard players set @s atr.bleed 0
scoreboard players remove @s atr.sanity 12
effect give @s minecraft:regeneration 8 1 true
effect give @s minecraft:nausea 100 0 false
particle minecraft:dust{color:[0.77,0.16,0.16],scale:1.2} ~ ~1 ~ 0.4 0.6 0.4 0 30 normal
playsound minecraft:entity.generic.drink master @s ~ ~ ~ 1 0.7
advancement grant @s only attrition:craft_bloodroot
