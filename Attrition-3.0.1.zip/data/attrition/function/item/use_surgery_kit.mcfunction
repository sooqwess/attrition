scoreboard players set @s atr.bleed 0
scoreboard players set @s atr.frac 0
scoreboard players remove @s atr.infect 300
execute if score @s atr.infect matches ..0 run scoreboard players set @s atr.infect 0
attribute @s minecraft:movement_speed modifier remove attrition:fracture
attribute @s minecraft:jump_strength modifier remove attrition:fracture
damage @s 3 attrition:bleeding
effect give @s minecraft:nausea 120 0 false
item modify entity @s weapon.mainhand attrition:wear_hard
playsound minecraft:entity.player.hurt master @s ~ ~ ~ 1 0.6
title @s actionbar {text:"Patched up. Barely.",color:"gray",italic:true}
