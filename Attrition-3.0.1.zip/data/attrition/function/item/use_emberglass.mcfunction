clear @s minecraft:glass_bottle[minecraft:custom_data~{attrition:{item:"emberglass"}}] 1
scoreboard players add @s atr.temp 35
execute if score @s atr.temp matches 100.. run scoreboard players set @s atr.temp 100
effect give @s minecraft:fire_resistance 30 0 true
particle minecraft:flame ~ ~1 ~ 0.3 0.5 0.3 0.01 20 normal
playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 0.7 1.4
title @s actionbar {text:"Warmth, spent",color:"gold",italic:true}
