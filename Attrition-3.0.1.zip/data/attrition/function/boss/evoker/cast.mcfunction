scoreboard players set @s atr.tmp 0
execute at @s if entity @a[distance=..24,gamemode=!creative,gamemode=!spectator] run summon minecraft:vex ^1 ^1 ^1 {Tags:["atr.bminion","atr.done"],PersistenceRequired:1b,LifeTicks:1200}
execute at @s if entity @a[distance=..24,gamemode=!creative,gamemode=!spectator] if predicate attrition:chance_35 run function attrition:boss/evoker/curse
