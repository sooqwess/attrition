execute as @a[distance=..24,gamemode=!creative,gamemode=!spectator] run effect give @s minecraft:unluck 20 0 true
execute as @a[distance=..24,gamemode=!creative,gamemode=!spectator] run effect give @s minecraft:weakness 10 0 true
playsound minecraft:entity.evoker.prepare_attack master @a[distance=..30] ~ ~ ~ 1 0.7
