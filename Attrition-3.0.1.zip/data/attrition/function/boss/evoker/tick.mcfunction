scoreboard players add @s atr.tmp 1
execute if score @s atr.tmp matches 10.. run function attrition:boss/evoker/cast
