tag @s add atr.boss
tag @s add atr.b_evoker
attribute @s minecraft:max_health modifier add attrition:boss_hp 0.80 add_multiplied_base
attribute @s minecraft:follow_range modifier add attrition:boss_range 0.80 add_multiplied_base
scoreboard players set @s atr.tmp 0
