tag @s add atr.boss
tag @s add atr.b_guard
attribute @s minecraft:max_health modifier add attrition:boss_hp 0.80 add_multiplied_base
attribute @s minecraft:armor modifier add attrition:boss_arm 8 add_value
scoreboard players set @s atr.tmp 0
