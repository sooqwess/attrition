scoreboard players set @s atr.tmp 0
execute at @s as @a[distance=..20,gamemode=!creative,gamemode=!spectator] run effect give @s minecraft:slowness 6 2 true
execute at @s as @a[distance=..20,gamemode=!creative,gamemode=!spectator] run effect give @s minecraft:blindness 4 0 true
execute at @s run summon minecraft:guardian ~ ~ ~ {Tags:["atr.bminion","atr.done"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}
