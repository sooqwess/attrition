scoreboard players add @s atr.tmp 1
execute at @s run effect give @a[distance=..24,gamemode=!creative,gamemode=!spectator] minecraft:mining_fatigue 8 2 true
execute if score @s atr.tmp matches 15.. run function attrition:boss/guardian/drown
