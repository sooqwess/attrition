execute if score BOSS_ON atr.cfg matches 0 run return 0
# claim new bosses
execute as @e[type=minecraft:wither,tag=!atr.boss] run function attrition:boss/wither/init
execute as @e[type=minecraft:ender_dragon,tag=!atr.boss] run function attrition:boss/dragon/init
execute as @e[type=minecraft:warden,tag=!atr.boss] run function attrition:boss/warden/init
execute as @e[type=minecraft:elder_guardian,tag=!atr.boss] run function attrition:boss/guardian/init
execute as @e[type=minecraft:ravager,tag=!atr.boss] run function attrition:boss/ravager/init
execute as @e[type=minecraft:evoker,tag=!atr.boss] run function attrition:boss/evoker/init

# run behaviour
execute as @e[tag=atr.b_wither] at @s run function attrition:boss/wither/tick
execute as @e[tag=atr.b_dragon] at @s run function attrition:boss/dragon/tick
execute as @e[tag=atr.b_warden] at @s run function attrition:boss/warden/tick
execute as @e[tag=atr.b_guard] at @s run function attrition:boss/guardian/tick
execute as @e[tag=atr.b_ravager] at @s run function attrition:boss/ravager/tick
execute as @e[tag=atr.b_evoker] at @s run function attrition:boss/evoker/tick
