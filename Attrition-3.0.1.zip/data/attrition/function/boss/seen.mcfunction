# #bit atr.tmp is set by the caller
scoreboard players operation #cur atr.tmp = @s atr.bosseen
function attrition:player/bit_set
scoreboard players operation @s atr.bosseen = #cur atr.tmp
scoreboard players add @s atr.bossn 1
execute if score @s atr.bosseen matches 15.. run advancement grant @s only attrition:boss_all
