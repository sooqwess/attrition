scoreboard players set @s atr.phase 3
effect give @s minecraft:strength infinite 1 true
effect give @s minecraft:fire_resistance infinite 0 true
execute at @s run playsound minecraft:entity.wither.ambient master @a[distance=..60] ~ ~ ~ 1 0.4
execute at @s run tellraw @a[distance=..60] {text:"  It stops standing still.",color:"dark_gray",italic:true}
