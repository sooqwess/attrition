tag @s add atr.boss
tag @s add atr.b_wither
scoreboard players set @s atr.phase 1
scoreboard players set @s atr.tmp 0
# scaling with era and preset power
attribute @s minecraft:max_health modifier add attrition:boss_hp 1.20 add_multiplied_base
attribute @s minecraft:armor modifier add attrition:boss_arm 12 add_value
attribute @s minecraft:follow_range modifier add attrition:boss_range 1.50 add_multiplied_base
attribute @s minecraft:knockback_resistance modifier add attrition:boss_kb 1 add_value
execute if score ERA atr.world matches 2 run attribute @s minecraft:max_health modifier add attrition:boss_era 0.25 add_multiplied_base
execute if score ERA atr.world matches 3 run attribute @s minecraft:max_health modifier add attrition:boss_era 0.50 add_multiplied_base
execute if score ERA atr.world matches 4.. run attribute @s minecraft:max_health modifier add attrition:boss_era 0.90 add_multiplied_base
data merge entity @s {Health:600.0f}
execute at @s run playsound minecraft:entity.wither.spawn master @a[distance=..80] ~ ~ ~ 1 0.6
execute at @s run tellraw @a[distance=..80] [{text:"  \u2588 ",color:"dark_red"},{text:"THE WITHER REMEMBERS",color:"red"},{text:"  it has done this before",color:"dark_gray",italic:true}]
