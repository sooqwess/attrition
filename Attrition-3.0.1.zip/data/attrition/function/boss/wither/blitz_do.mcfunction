# @s = player, position = player
summon minecraft:area_effect_cloud ~ ~4 ~ {Tags:["atr.bmark"],Duration:1,Radius:0.1f}
execute as @e[type=minecraft:wither,tag=atr.b_wither,limit=1,sort=nearest] run tp @s ~ ~ ~
effect give @s minecraft:blindness 4 0 true
effect give @s minecraft:levitation 2 1 true
playsound minecraft:entity.wither.shoot master @s ~ ~ ~ 1 0.6
kill @e[type=minecraft:area_effect_cloud,tag=atr.bmark]
