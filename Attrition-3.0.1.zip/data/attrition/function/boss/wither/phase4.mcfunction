scoreboard players set @s atr.phase 4
effect give @s minecraft:regeneration infinite 1 true
effect give @s minecraft:strength infinite 2 true
execute at @s run playsound minecraft:entity.wither.death master @a[distance=..80] ~ ~ ~ 1 0.3
execute at @s run tellraw @a[distance=..80] [{text:"  \u2588 ",color:"dark_red"},{text:"IT WILL NOT DIE QUIETLY",color:"red"}]
