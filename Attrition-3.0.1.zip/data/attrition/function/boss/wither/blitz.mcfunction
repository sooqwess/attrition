scoreboard players set @s atr.tmp 0
# jump onto the nearest player and knock them off their feet
execute at @s as @p[distance=3..48,gamemode=!creative,gamemode=!spectator] at @s run function attrition:boss/wither/blitz_do
