# phase rage: aimed skull volley + area pressure
execute at @s anchored eyes if predicate attrition:chance_25 positioned ^ ^ ^2 run summon minecraft:wither_skull ~ ~ ~ {Motion:[0.0,-0.35,0.0],acceleration_power:0.08,Tags:["atr.bskull"]}
execute at @s run effect give @a[distance=..20,gamemode=!creative,gamemode=!spectator] minecraft:mining_fatigue 3 1 true
execute at @s if predicate attrition:chance_10 run particle minecraft:explosion ~ ~1 ~ 2 2 2 0 6 normal
