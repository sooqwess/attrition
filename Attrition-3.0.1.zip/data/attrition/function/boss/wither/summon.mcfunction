scoreboard players set @s atr.tmp 0
execute at @s run summon minecraft:wither_skeleton ^2 ^ ^2 {Tags:["atr.bminion","atr.done"],PersistenceRequired:1b,CustomName:{translate:"attrition.entity.bone_of_the_wither",fallback:"Bone of the Wither",color:"dark_gray",italic:false},HandItems:[{id:"minecraft:stone_sword",count:1},{}],DeathLootTable:"minecraft:empty"}
execute at @s run summon minecraft:wither_skeleton ^-2 ^ ^2 {Tags:["atr.bminion","atr.done"],PersistenceRequired:1b,CustomName:{translate:"attrition.entity.bone_of_the_wither",fallback:"Bone of the Wither",color:"dark_gray",italic:false},HandItems:[{id:"minecraft:bow",count:1},{}],DeathLootTable:"minecraft:empty"}
execute at @s run particle minecraft:smoke ~ ~ ~ 1.5 1.5 1.5 0.02 40 normal
