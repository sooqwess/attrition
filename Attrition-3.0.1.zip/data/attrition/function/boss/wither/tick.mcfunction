scoreboard players add @s atr.tmp 1
execute store result score #hp atr.tmp run data get entity @s Health 1

# --- phases by health ---
execute if score #hp atr.tmp matches ..450 if score @s atr.phase matches 1 run function attrition:boss/wither/phase2
execute if score #hp atr.tmp matches ..250 if score @s atr.phase matches 2 run function attrition:boss/wither/phase3
execute if score #hp atr.tmp matches ..100 if score @s atr.phase matches 3 run function attrition:boss/wither/phase4

# --- constant: wither aura ---
execute at @s run effect give @a[distance=..12,gamemode=!creative,gamemode=!spectator] minecraft:wither 3 0 true

# --- phase 2+: summons ---
execute if score @s atr.phase matches 2.. if score @s atr.tmp matches 8.. run function attrition:boss/wither/summon
# --- phase 3+: teleport to target and blindness pulse ---
execute if score @s atr.phase matches 3.. if score @s atr.tmp matches 12.. run function attrition:boss/wither/blitz
# --- phase 4: regeneration denial aura and skull rain ---
execute if score @s atr.phase matches 4 run function attrition:boss/wither/rage
