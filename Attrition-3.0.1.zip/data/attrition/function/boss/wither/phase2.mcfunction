scoreboard players set @s atr.phase 2
effect give @s minecraft:speed infinite 1 true
effect give @s minecraft:resistance infinite 0 true
execute at @s run playsound minecraft:entity.wither.hurt master @a[distance=..60] ~ ~ ~ 1 0.5
execute at @s run tellraw @a[distance=..60] {text:"  The Wither calls its dead.",color:"dark_gray",italic:true}
