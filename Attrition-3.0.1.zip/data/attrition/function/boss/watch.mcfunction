# boss death watchdog: remembers a living boss, fires the drop when it vanishes
execute if entity @e[tag=atr.b_wither,limit=1] run scoreboard players set #seen_w atr.tmp 1
execute if entity @e[tag=atr.b_dragon,limit=1] run scoreboard players set #seen_d atr.tmp 1
execute if entity @e[tag=atr.b_warden,limit=1] run scoreboard players set #seen_k atr.tmp 1
execute if score #seen_w atr.tmp matches 1 unless entity @e[tag=atr.b_wither,limit=1] run function attrition:boss/slain_wither
execute if score #seen_d atr.tmp matches 1 unless entity @e[tag=atr.b_dragon,limit=1] run function attrition:boss/slain_dragon
execute if score #seen_k atr.tmp matches 1 unless entity @e[tag=atr.b_warden,limit=1] run function attrition:boss/slain_warden
