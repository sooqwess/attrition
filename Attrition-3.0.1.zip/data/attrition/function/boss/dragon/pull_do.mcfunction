effect give @s minecraft:levitation 1 2 true
effect give @s minecraft:nausea 5 0 true
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.5
