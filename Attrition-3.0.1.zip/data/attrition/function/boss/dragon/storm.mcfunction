# the sky falls: fireballs rain on every player in range
execute at @s as @a[distance=..60,gamemode=!creative,gamemode=!spectator] at @s if predicate attrition:chance_25 run summon minecraft:small_fireball ~ ~14 ~ {Motion:[0.0,-0.6,0.0],acceleration_power:0.02,Tags:["atr.bfire"]}
execute at @s if predicate attrition:chance_25 run particle minecraft:dragon_breath ~ ~ ~ 8 4 8 0.02 60 normal
