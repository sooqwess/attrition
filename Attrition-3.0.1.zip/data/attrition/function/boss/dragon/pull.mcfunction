execute at @s as @a[distance=..40,gamemode=!creative,gamemode=!spectator] run function attrition:boss/dragon/pull_do
