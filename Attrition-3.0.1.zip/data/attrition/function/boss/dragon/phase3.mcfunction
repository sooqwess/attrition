scoreboard players set @s atr.phase 3
effect give @s minecraft:strength infinite 1 true
effect give @s minecraft:regeneration infinite 0 true
execute at @s run tellraw @a[distance=..200] [{text:"  \u2588 ",color:"dark_purple"},{text:"IT STOPS PLAYING",color:"light_purple"}]
execute at @s run playsound minecraft:entity.ender_dragon.growl master @a[distance=..200] ~ ~ ~ 1 0.4
