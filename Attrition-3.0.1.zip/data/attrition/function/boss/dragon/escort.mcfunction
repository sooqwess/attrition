scoreboard players set @s atr.tmp 0
execute at @s if entity @a[distance=..90,gamemode=!creative,gamemode=!spectator] run summon minecraft:endermite ~ ~-2 ~ {Tags:["atr.bminion","atr.done"],PersistenceRequired:1b,Lifetime:-2400}
execute at @s if entity @a[distance=..90,gamemode=!creative,gamemode=!spectator] if predicate attrition:chance_50 run summon minecraft:phantom ~ ~-4 ~ {Tags:["atr.bminion","atr.done"],PersistenceRequired:1b,CustomName:{translate:"attrition.entity.shard_of_the_end",fallback:"Shard of the End",color:"dark_purple",italic:false},DeathLootTable:"minecraft:empty"}
