tag @s add atr.boss
tag @s add atr.b_dragon
scoreboard players set @s atr.phase 1
scoreboard players set @s atr.tmp 0
attribute @s minecraft:max_health modifier add attrition:boss_hp 1.00 add_multiplied_base
attribute @s minecraft:armor modifier add attrition:boss_arm 10 add_value
execute if score ERA atr.world matches 3 run attribute @s minecraft:max_health modifier add attrition:boss_era 0.35 add_multiplied_base
execute if score ERA atr.world matches 4.. run attribute @s minecraft:max_health modifier add attrition:boss_era 0.80 add_multiplied_base
data merge entity @s {Health:400.0f}
execute at @s run tellraw @a[distance=..200] [{text:"  \u2588 ",color:"dark_purple"},{text:"THE DRAGON HAS BEEN WAITING",color:"light_purple"}]
