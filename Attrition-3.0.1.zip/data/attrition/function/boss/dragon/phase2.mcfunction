scoreboard players set @s atr.phase 2
effect give @s minecraft:speed infinite 0 true
execute at @s run tellraw @a[distance=..200] {text:"  The air starts pulling toward it.",color:"dark_gray",italic:true}
execute at @s run playsound minecraft:entity.ender_dragon.growl master @a[distance=..200] ~ ~ ~ 1 0.7
