scoreboard players add @s atr.tmp 1
execute store result score #hp atr.tmp run data get entity @s Health 1
execute if score #hp atr.tmp matches ..260 if score @s atr.phase matches 1 run function attrition:boss/dragon/phase2
execute if score #hp atr.tmp matches ..120 if score @s atr.phase matches 2 run function attrition:boss/dragon/phase3

# endermen escort
execute if score @s atr.tmp matches 10.. run function attrition:boss/dragon/escort
# phase 2: void pull
execute if score @s atr.phase matches 2.. if predicate attrition:chance_10 run function attrition:boss/dragon/pull
# phase 3: crystal rebirth denial + rain of fire
execute if score @s atr.phase matches 3 run function attrition:boss/dragon/storm
