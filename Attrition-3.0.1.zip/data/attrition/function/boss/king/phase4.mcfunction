scoreboard players set KPHASE atr.world 4
effect give @s minecraft:speed 999999 1 true
effect give @s minecraft:strength 999999 1 true
execute as @a[distance=..40] run effect give @s minecraft:weakness 300 0 false
execute as @a[distance=..40] run scoreboard players add @s atr.gloom 20
tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"It knows it is dying. That makes it worse.",color:"dark_red"}]
playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 1 0.4
