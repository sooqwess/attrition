scoreboard players set KPHASE atr.world 2
attribute @s minecraft:movement_speed modifier add attrition:kingspd 0.15 add_multiplied_base
effect give @s minecraft:strength 999999 0 true
tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The King stops holding back.",color:"dark_red"}]
playsound minecraft:entity.wither.hurt master @a ~ ~ ~ 1 0.5
