# the last altar: gold block under, four soul lanterns on the diagonals
execute unless block ~ ~-1 ~ minecraft:gold_block run return 0
execute unless block ~2 ~-1 ~2 minecraft:soul_lantern run return 0
execute unless block ~-2 ~-1 ~2 minecraft:soul_lantern run return 0
execute unless block ~2 ~-1 ~-2 minecraft:soul_lantern run return 0
execute unless block ~-2 ~-1 ~-2 minecraft:soul_lantern run return 0
execute unless predicate attrition:hold/pact_token run return 0
execute if entity @e[tag=atr.king] run return 0
scoreboard players set @s atr.reckon 600
clear @s minecraft:gold_ingot[minecraft:custom_data~{attrition:{item:"pact_token"}}] 1
function attrition:boss/king/summon
