tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE HOLLOW KING",color:"red"}]
tellraw @a {text:"  Everything the world took from you had to go somewhere.",color:"dark_gray",italic:true}
tellraw @a ""
summon minecraft:wither_skeleton ~ ~1 ~ {Tags:["atr.king","atr.done","atr.boss"],PersistenceRequired:1b,CustomName:{translate:"attrition.entity.the_hollow_king",fallback:"The Hollow King",color:"dark_red"},CustomNameVisible:1b,Health:400f,attributes:[{id:"minecraft:max_health",base:400d},{id:"minecraft:attack_damage",base:16d},{id:"minecraft:armor",base:14d},{id:"minecraft:knockback_resistance",base:1d},{id:"minecraft:movement_speed",base:0.32d},{id:"minecraft:follow_range",base:64d}],HandItems:[{id:"minecraft:netherite_sword",count:1},{id:"minecraft:shield",count:1}],ArmorItems:[{id:"minecraft:netherite_boots",count:1},{id:"minecraft:netherite_leggings",count:1},{id:"minecraft:netherite_chestplate",count:1},{id:"minecraft:wither_skeleton_skull",count:1}],HandDropChances:[0.0f,0.0f],ArmorDropChances:[0.0f,0.0f,0.0f,0.0f]}
bossbar remove attrition:king
bossbar add attrition:king {"text":"The Hollow King","color":"red"}
bossbar set attrition:king color red
bossbar set attrition:king style notched_6
bossbar set attrition:king max 400
bossbar set attrition:king players @a
scoreboard players set KING atr.world 1
scoreboard players set KPHASE atr.world 1
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 1 0.4
weather thunder 12000
