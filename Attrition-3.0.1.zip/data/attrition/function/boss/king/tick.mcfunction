execute unless score KING atr.world matches 1 run return 0
execute unless entity @e[tag=atr.king] run function attrition:boss/king/slain
execute as @e[tag=atr.king,limit=1] at @s run function attrition:boss/king/act
