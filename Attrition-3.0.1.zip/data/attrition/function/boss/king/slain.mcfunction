scoreboard players set KING atr.world 0
scoreboard players set KPHASE atr.world 0
bossbar remove attrition:king
kill @e[tag=atr.kingadd]
tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"gold"},{text:"THE HOLLOW KING HAS FALLEN",color:"gold"}]
tellraw @a {text:"  The account is settled. The world will start a new one.",color:"dark_gray",italic:true}
tellraw @a ""
execute as @a[distance=..64,gamemode=!creative,gamemode=!spectator] run function attrition:boss/king/reward
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
execute as @a[distance=..64] run function attrition:boss/seen_8
