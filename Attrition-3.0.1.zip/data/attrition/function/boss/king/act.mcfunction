execute store result score KHP atr.world run data get entity @s Health
execute store result bossbar attrition:king value run data get entity @s Health
execute if score KHP atr.world matches ..280 if score KPHASE atr.world matches 1 run function attrition:boss/king/phase2
execute if score KHP atr.world matches ..150 if score KPHASE atr.world matches 2 run function attrition:boss/king/phase3
execute if score KHP atr.world matches ..60 if score KPHASE atr.world matches 3 run function attrition:boss/king/phase4
particle minecraft:soul ~ ~1 ~ 0.5 1 0.5 0.02 6 normal
execute if predicate attrition:chance_10 run function attrition:boss/king/strike
execute if score KPHASE atr.world matches 2.. if predicate attrition:chance_10 run function attrition:boss/king/summon_add
execute if score KPHASE atr.world matches 3.. if predicate attrition:chance_10 run function attrition:boss/king/drain
execute if score KPHASE atr.world matches 4 if predicate attrition:chance_15 run function attrition:boss/king/blink
