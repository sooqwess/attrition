execute as @a[distance=..20,gamemode=!creative,gamemode=!spectator] run scoreboard players remove @s atr.stam 20
execute as @a[distance=..20,gamemode=!creative,gamemode=!spectator] run scoreboard players remove @s atr.thirst 6
execute as @a[distance=..20,gamemode=!creative,gamemode=!spectator] run scoreboard players remove @s atr.sanity 4
execute as @a[distance=..20,gamemode=!creative,gamemode=!spectator] at @s run particle minecraft:soul_fire_flame ~ ~1 ~ 0.4 0.8 0.4 0.02 12 normal
playsound minecraft:block.soul_sand.break hostile @a[distance=..40] ~ ~ ~ 1 0.5
