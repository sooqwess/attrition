scoreboard players set KPHASE atr.world 3
effect give @s minecraft:resistance 999999 0 true
effect give @s minecraft:regeneration 999999 0 true
execute as @a[distance=..40] run effect give @s minecraft:darkness 200 0 false
tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"It is taking the light with it.",color:"dark_red"}]
