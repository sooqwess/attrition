execute at @r[distance=..40,gamemode=!creative,gamemode=!spectator] run tp @s ~ ~ ~
playsound minecraft:entity.enderman.teleport hostile @a[distance=..40] ~ ~ ~ 1 0.6
