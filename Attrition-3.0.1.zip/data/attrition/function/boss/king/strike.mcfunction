execute as @a[distance=..24,gamemode=!creative,gamemode=!spectator] at @s run summon minecraft:wither_skull ~ ~3 ~ {Motion:[0d,-0.4d,0d],acceleration_power:0.06d}
execute as @a[distance=..12,gamemode=!creative,gamemode=!spectator] run damage @s 4 attrition:collapse
playsound minecraft:entity.wither.shoot hostile @a[distance=..40] ~ ~ ~ 1 0.7
