summon minecraft:wither_skeleton ~2 ~ ~ {Tags:["atr.kingadd","atr.done"],PersistenceRequired:1b}
summon minecraft:vex ~-2 ~1 ~ {Tags:["atr.kingadd","atr.done"]}
execute as @e[tag=atr.kingadd,distance=..8] run effect give @s minecraft:speed 999999 0 true
