advancement grant @s only attrition:king_slain
scoreboard players set @s atr.scar 0
attribute @s minecraft:max_health modifier remove attrition:scars
scoreboard players set @s atr.gloom 0
scoreboard players set @s atr.floor 0
scoreboard players set @s atr.curse 0
scoreboard players set @s atr.grudge 0
function attrition:curse/lift
give @s minecraft:nether_star[minecraft:item_model="attrition:hollow_crown",minecraft:item_name={translate:"attrition.item.the_hollow_crown",fallback:"The Hollow Crown",color:"gold",italic:false},minecraft:lore=[{translate:"attrition.lore.everything_it_took_returned",fallback:"Everything it took, returned.",color:"dark_gray",italic:true}],minecraft:custom_data={attrition:{item:"hollow_crown"}},minecraft:enchantment_glint_override=true] 1
scoreboard players add @s atr.score 100
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"You are, briefly, whole.",color:"gold"}]
