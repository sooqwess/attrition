scoreboard players add @s atr.tmp 1
execute if score @s atr.tmp matches 6.. run function attrition:boss/ravager/charge
