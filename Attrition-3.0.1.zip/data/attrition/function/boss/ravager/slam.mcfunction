playsound minecraft:entity.ravager_roar master @a[distance=..30] ~ ~ ~ 1 0.8
particle minecraft:explosion ~ ~ ~ 1 0 1 0 6 normal
effect give @a[distance=..5,gamemode=!creative,gamemode=!spectator] minecraft:slowness 4 2 true
execute as @a[distance=..5,gamemode=!creative,gamemode=!spectator] run damage @s 4 minecraft:mob_attack by @n[type=minecraft:ravager]
