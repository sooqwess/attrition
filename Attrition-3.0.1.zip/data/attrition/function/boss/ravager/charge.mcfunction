scoreboard players set @s atr.tmp 0
execute at @s if entity @a[distance=6..20,gamemode=!creative,gamemode=!spectator] run effect give @s minecraft:speed 3 2 true
execute at @s if entity @a[distance=..4,gamemode=!creative,gamemode=!spectator] run function attrition:boss/ravager/slam
