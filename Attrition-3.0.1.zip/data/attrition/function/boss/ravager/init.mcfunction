tag @s add atr.boss
tag @s add atr.b_ravager
attribute @s minecraft:max_health modifier add attrition:boss_hp 0.60 add_multiplied_base
attribute @s minecraft:knockback_resistance modifier add attrition:boss_kb 0.6 add_value
attribute @s minecraft:movement_speed modifier add attrition:boss_spd 0.15 add_multiplied_base
scoreboard players set @s atr.tmp 0
