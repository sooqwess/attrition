scoreboard players set #seen_w atr.tmp 0
scoreboard players set #boss atr.tmp 1
execute as @a[gamemode=!spectator,distance=..80] at @s run function attrition:item/boss_drop
execute as @a[gamemode=!spectator,distance=..80] run function attrition:player/mark_gain
execute as @a[gamemode=!spectator,distance=..80] run advancement grant @s only attrition:boss_wither
scoreboard players set #boss atr.tmp 0
tellraw @a [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The Wither has fallen. The world adjusts.",color:"gray"}]
execute as @a[distance=..64] run function attrition:boss/seen_1
