scoreboard players set #bit atr.tmp 1
function attrition:boss/seen
