# minions die with their master
execute unless entity @e[tag=atr.b_wither,limit=1] run kill @e[tag=atr.bminion,type=minecraft:wither_skeleton]
execute unless entity @e[tag=atr.b_dragon,limit=1] run kill @e[tag=atr.bminion,type=minecraft:endermite]
kill @e[type=minecraft:area_effect_cloud,tag=atr.bmark]
