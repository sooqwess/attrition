scoreboard players set #bit atr.tmp 4
function attrition:boss/seen
