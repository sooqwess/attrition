scoreboard players set #bit atr.tmp 2
function attrition:boss/seen
