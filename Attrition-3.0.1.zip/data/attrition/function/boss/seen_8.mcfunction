scoreboard players set #bit atr.tmp 8
function attrition:boss/seen
