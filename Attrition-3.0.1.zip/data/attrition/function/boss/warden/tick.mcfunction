scoreboard players add @s atr.tmp 1
# permanent darkness aura, wider than vanilla
execute at @s run effect give @a[distance=..40,gamemode=!creative,gamemode=!spectator] minecraft:darkness 4 0 true
# it does not lose you: periodic sniff-teleport toward the nearest player
execute if score @s atr.tmp matches 20.. run function attrition:boss/warden/hunt
# the deeper you are, the angrier it is
execute if score @s atr.phase matches 1 if entity @a[distance=..16,gamemode=!creative,gamemode=!spectator] run function attrition:boss/warden/enrage
execute at @s if predicate attrition:chance_10 run playsound minecraft:entity.warden_heartbeat master @a[distance=..40] ~ ~ ~ 1 0.8
