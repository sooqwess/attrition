scoreboard players set @s atr.phase 2
effect give @s minecraft:speed infinite 1 true
effect give @s minecraft:strength infinite 0 true
execute at @s run playsound minecraft:entity.warden_roar master @a[distance=..48] ~ ~ ~ 1 0.6
execute at @s run effect give @a[distance=..24,gamemode=!creative,gamemode=!spectator] minecraft:slowness 4 1 true
execute at @s run effect give @a[distance=..24,gamemode=!creative,gamemode=!spectator] minecraft:mining_fatigue 6 2 true
