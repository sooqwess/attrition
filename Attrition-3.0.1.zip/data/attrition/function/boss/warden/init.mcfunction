tag @s add atr.boss
tag @s add atr.b_warden
scoreboard players set @s atr.phase 1
scoreboard players set @s atr.tmp 0
attribute @s minecraft:movement_speed modifier add attrition:boss_spd 0.35 add_multiplied_base
attribute @s minecraft:follow_range modifier add attrition:boss_range 1.00 add_multiplied_base
attribute @s minecraft:max_health modifier add attrition:boss_hp 0.50 add_multiplied_base
execute if score ERA atr.world matches 3.. run attribute @s minecraft:attack_damage modifier add attrition:boss_dmg 0.30 add_multiplied_base
execute at @s run tellraw @a[distance=..48] [{text:"  \u2588 ",color:"dark_aqua"},{text:"IT HEARD YOU",color:"aqua"}]
execute at @s run playsound minecraft:entity.warden_emerge master @a[distance=..64] ~ ~ ~ 1 0.7
