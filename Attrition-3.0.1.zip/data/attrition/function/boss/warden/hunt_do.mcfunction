execute at @p[distance=24..64,gamemode=!creative,gamemode=!spectator] run tp @s ~ ~ ~
playsound minecraft:entity.warden_dig master @a[distance=..40] ~ ~ ~ 1 0.5
particle minecraft:sculk_soul ~ ~1 ~ 1 1 1 0.05 30 normal
