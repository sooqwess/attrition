scoreboard players set @s atr.tmp 0
execute at @s if entity @a[distance=24..64,gamemode=!creative,gamemode=!spectator] run function attrition:boss/warden/hunt_do
