# a cairn is the only thing in this pack that helps for free
execute unless entity @e[type=minecraft:marker,tag=atr.cairn,distance=..12,limit=1] run return 0
scoreboard players remove @s atr.noise 3
execute if score @s atr.sanity matches ..99 run scoreboard players add @s atr.sanity 2
execute if score @s atr.gloom matches 1.. if predicate attrition:chance_25 run scoreboard players remove @s atr.gloom 1
execute if predicate attrition:chance_10 run particle minecraft:end_rod ~ ~1 ~ 0.6 0.8 0.6 0.005 4 normal
scoreboard players add @s atr.cairnt 1
execute if score @s atr.cairnt matches 60.. run advancement grant @s only attrition:cairn_home
