# pull whatever is nearby straight to you
execute as @e[type=#attrition:targets,distance=8..48,limit=4,sort=random] at @s run tp @s ~ ~ ~ facing entity @p
execute as @e[type=#attrition:targets,distance=8..48,limit=4,sort=random] run effect give @s minecraft:speed 8 0 true
playsound minecraft:entity.warden.listening hostile @s ~ ~ ~ 0.4 1.4
