# era 4 does not end the game. It opens the last door.
execute unless score RECKON_ON atr.cfg matches 1 run return 0
execute unless score ERA atr.world matches 4 run return 0
execute if score RECKON atr.world matches 1.. run return 0
scoreboard players set RECKON atr.world 1
function attrition:world/reckon_open
