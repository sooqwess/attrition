execute unless dimension minecraft:the_end run return 0
scoreboard players add @s atr.endp 1
execute if score GLOOM_ON atr.cfg matches 1 if predicate attrition:chance_25 run scoreboard players add @s atr.gloom 1
execute if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_35 run scoreboard players remove @s atr.sanity 1
execute if predicate attrition:chance_05 run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.6 0.5
execute if score @s atr.endp matches 360.. if predicate attrition:chance_10 run effect give @s minecraft:levitation 2 0 false
execute if score @s atr.endp matches 720.. run advancement grant @s only attrition:end_long
