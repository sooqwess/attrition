scoreboard players set #bit atr.tmp 1
execute if dimension minecraft:the_nether run scoreboard players set #bit atr.tmp 2
execute if dimension minecraft:the_end run scoreboard players set #bit atr.tmp 4
scoreboard players operation #cur atr.tmp = @s atr.sseen
function attrition:player/bit_set
scoreboard players operation @s atr.sseen = #cur atr.tmp
scoreboard players add @s atr.shockn 1
execute if score @s atr.sseen matches 7 run advancement grant @s only attrition:shock_all
