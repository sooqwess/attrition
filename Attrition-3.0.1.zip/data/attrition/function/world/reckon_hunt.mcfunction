summon minecraft:wither_skeleton ~3 ~ ~3 {Tags:["atr.reckon","atr.done"],PersistenceRequired:1b,CustomName:{translate:"attrition.entity.collector",fallback:"Collector",color:"dark_red"}}
summon minecraft:wither_skeleton ~-3 ~ ~-3 {Tags:["atr.reckon","atr.done"],PersistenceRequired:1b,CustomName:{translate:"attrition.entity.collector",fallback:"Collector",color:"dark_red"}}
execute as @e[tag=atr.reckon,distance=..8] run effect give @s minecraft:speed 999999 0 true
execute as @e[tag=atr.reckon,distance=..8] run effect give @s minecraft:fire_resistance 999999 0 true
playsound minecraft:entity.wither_skeleton.ambient hostile @s ~ ~ ~ 1 0.6
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"They came for the account.",color:"dark_red"}]
