execute as @e[type=#attrition:targets,distance=..6] at @s run effect give @s minecraft:weakness 4 0 true
execute as @e[type=#attrition:targets,distance=..6] at @s if predicate attrition:chance_25 run effect give @s minecraft:glowing 4 0 true
