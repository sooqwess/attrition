execute if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_35 run scoreboard players remove @s atr.sanity 1
execute if score GLOOM_ON atr.cfg matches 1 if predicate attrition:chance_25 run scoreboard players add @s atr.gloom 1
execute if predicate attrition:chance_25 run effect give @s minecraft:darkness 5 0 true
execute if predicate attrition:chance_15 run particle minecraft:squid_ink ~ ~1 ~ 0.8 1 0.8 0.01 12 normal
execute if predicate attrition:chance_10 run playsound minecraft:ambient.soul_sand_valley.mood master @s ~ ~ ~ 0.5 0.6
execute if predicate attrition:chance_05 if score ERA atr.world matches 2.. run function attrition:world/blight_spawn
