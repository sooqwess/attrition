# every night survived raises the pressure of the next one
execute unless score IS_NIGHT atr.world matches 1 run return 0
scoreboard players add WATCH atr.world 1
execute if score WATCH atr.world matches 6.. run scoreboard players set WATCH atr.world 6
execute as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/night_press
