# era-scaled starvation pressure
execute unless score HUNGER_ON atr.cfg matches 1 run return 0
execute if score ERA atr.world matches 2.. if predicate attrition:chance_05 run effect give @s minecraft:hunger 4 0 true
execute if score ERA atr.world matches 3.. if score @s atr.load matches 128.. if predicate attrition:chance_15 run effect give @s minecraft:hunger 6 0 true
execute if score ERA atr.world matches 4 if predicate attrition:chance_10 run effect give @s minecraft:hunger 8 1 true
