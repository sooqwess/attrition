execute if dimension minecraft:the_nether run summon minecraft:piglin_brute ~ ~1 ~ {Tags:["atr.grudge","atr.done"],PersistenceRequired:1b}
execute unless dimension minecraft:the_nether if predicate attrition:chance_50 run summon minecraft:vindicator ~ ~1 ~ {Tags:["atr.grudge","atr.done"],PersistenceRequired:1b}
execute unless dimension minecraft:the_nether unless predicate attrition:chance_50 run summon minecraft:pillager ~ ~1 ~ {Tags:["atr.grudge","atr.done"],PersistenceRequired:1b}
playsound minecraft:event.raid.horn master @s ~ ~ ~ 0.4 1.4
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Someone was sent for you.",color:"gray"}]
