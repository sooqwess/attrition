# deep dark pressure
execute if dimension minecraft:overworld if predicate attrition:in_darkness positioned ~ ~ ~ if entity @s[y=-64,dy=64] run effect give @s minecraft:darkness 6 0 true
# the Nether hates you specifically
execute if dimension minecraft:the_nether if predicate attrition:chance_10 run effect give @s minecraft:hunger 8 0 true
execute if dimension minecraft:the_nether if score TEMP_ON atr.cfg matches 1 run scoreboard players add @s atr.temp 2
# the End drains
execute if dimension minecraft:the_end if predicate attrition:chance_25 run effect give @s minecraft:mining_fatigue 10 0 true
# storms are dangerous under open sky
execute if predicate attrition:is_thundering if predicate attrition:sees_sky if predicate attrition:chance_10 run function attrition:world/strike
