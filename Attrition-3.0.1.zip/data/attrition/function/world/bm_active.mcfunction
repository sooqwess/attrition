tag @a add atr.bmseen
scoreboard players add BMCLK atr.world 1
execute if score BMCLK atr.world matches 3.. run scoreboard players set BMCLK atr.world 0
execute if score BMCLK atr.world matches 0 as @a[gamemode=!spectator] at @s run function attrition:world/bm_spawn
