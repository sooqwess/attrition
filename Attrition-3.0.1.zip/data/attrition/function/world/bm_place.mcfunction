$execute rotated $(a) 0 positioned ^ ^ ^26 run function attrition:world/bm_try
