# the world will pay you to thin it out
execute unless score CONTRACT_ON atr.cfg matches 1 run return 0
execute if score @s atr.contract matches 1.. run return 0
scoreboard players set #r atr.tmp 0
execute store result score #r atr.tmp run random value 1..4
scoreboard players operation @s atr.contract = #r atr.tmp
scoreboard players set @s atr.cprog 0
function attrition:world/contract_msg
