# Global world tick, once per second. as <server>, no context entity.
execute store result score DAY atr.world run time query day
execute store result score TOD atr.world run time query daytime

# night flag (used by body systems)
scoreboard players set IS_NIGHT atr.world 0
execute if score TOD atr.world matches 13000..23000 run scoreboard players set IS_NIGHT atr.world 1

execute if score ERA_ON atr.cfg matches 1 run function attrition:world/era_check
execute if score BM_ON atr.cfg matches 1 run function attrition:world/bloodmoon
execute if score EVENT_ON atr.cfg matches 1 run function attrition:world/event_tick
function attrition:world/night_watch
function attrition:world/storm
function attrition:mob/nemesis_tick
function attrition:mob/echo_tick
execute if score EVENT_ON atr.cfg matches 1 run function attrition:world/event_active
function attrition:world/reckon_check
execute if score KING atr.world matches 1 run function attrition:boss/king/tick
