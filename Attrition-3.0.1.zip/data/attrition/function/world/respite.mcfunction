# a lit fire with a roof is the only mercy this pack offers
execute unless score RESPITE_ON atr.cfg matches 1 run return 0
scoreboard players set #ok atr.tmp 0
execute if block ~ ~-1 ~ #minecraft:campfires[lit=true] run scoreboard players set #ok atr.tmp 1
execute if block ~ ~ ~ #minecraft:campfires[lit=true] run scoreboard players set #ok atr.tmp 1
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:campfires[lit=true] run scoreboard players set #ok atr.tmp 1
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:campfires[lit=true] run scoreboard players set #ok atr.tmp 1
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:campfires[lit=true] run scoreboard players set #ok atr.tmp 1
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:campfires[lit=true] run scoreboard players set #ok atr.tmp 1
execute if score #ok atr.tmp matches 0 run scoreboard players set @s atr.respite 0
execute if score #ok atr.tmp matches 0 run return 0
execute if score #ok atr.tmp matches 1 run function attrition:world/respite_do
