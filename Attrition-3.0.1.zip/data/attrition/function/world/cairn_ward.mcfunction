# mobs do not like standing next to a cairn
execute as @e[type=minecraft:marker,tag=atr.cairn] at @s run function attrition:world/cairn_push
