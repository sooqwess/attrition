execute unless predicate attrition:sees_sky run return 0
execute if score TEMP_ON atr.cfg matches 1 run scoreboard players remove @s atr.temp 2
scoreboard players add @s atr.wet 2
execute if predicate attrition:chance_25 run effect give @s minecraft:slowness 4 0 true
execute if predicate attrition:chance_15 if score SANITY_ON atr.cfg matches 1 run scoreboard players remove @s atr.sanity 1
execute if predicate attrition:chance_05 if score ERA atr.world matches 2.. run function attrition:world/strike
execute if predicate attrition:chance_10 run title @s actionbar {text:"The rain gets into everything",color:"gray",italic:true}
