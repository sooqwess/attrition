# the deep does not give up diamonds for free
execute unless score BACKLASH_ON atr.cfg matches 1 run return 0
scoreboard players operation #dd atr.tmp = @s atr.dia
scoreboard players operation #dd atr.tmp -= @s atr.diap
scoreboard players operation @s atr.diap = @s atr.dia
execute if score #dd atr.tmp matches 1.. run function attrition:world/backlash_hit

scoreboard players operation #db atr.tmp = @s atr.dbris
scoreboard players operation #db atr.tmp -= @s atr.dbrisp
scoreboard players operation @s atr.dbrisp = @s atr.dbris
execute if score #db atr.tmp matches 1.. run function attrition:world/backlash_deep
