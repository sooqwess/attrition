execute positioned ^ ^ ^8 run summon minecraft:lightning_bolt ~ ~ ~
playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 1 1
title @s actionbar {text:"The storm is aiming",color:"yellow",italic:true}
