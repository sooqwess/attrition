scoreboard players operation ERA atr.world = #e atr.tmp
# mobs must be recalculated for the new era
tag @e[tag=atr.done] remove atr.done
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 0.7 0.4
title @a times 10 60 20
title @a title {translate:"attrition.era.title",fallback:"THE WORLD HAS CHANGED",color:"dark_red"}
execute if score ERA atr.world matches 1 run title @a subtitle {translate:"attrition.era.1",fallback:"Era I - It has noticed you",color:"gray"}
execute if score ERA atr.world matches 2 run title @a subtitle {translate:"attrition.era.2",fallback:"Era II - It no longer sleeps",color:"gray"}
execute if score ERA atr.world matches 3 run title @a subtitle {translate:"attrition.era.3",fallback:"Era III - It is coming for you",color:"gray"}
execute if score ERA atr.world matches 4 run title @a subtitle {translate:"attrition.era.4",fallback:"Era IV - It is already here",color:"dark_red"}
execute as @a run function attrition:player/ach_era
