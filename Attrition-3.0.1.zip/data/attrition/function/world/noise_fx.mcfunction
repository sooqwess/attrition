execute if score @s atr.noise matches 25.. if predicate attrition:chance_25 run title @s actionbar {text:"Something heard that",color:"dark_gray",italic:true}
execute if score @s atr.noise matches 30.. run effect give @s minecraft:glowing 8 0 true
execute if score @s atr.noise matches 35.. if predicate attrition:chance_35 run function attrition:world/noise_draw
execute if score @s atr.noise matches 50.. if predicate attrition:chance_50 run function attrition:world/noise_draw
