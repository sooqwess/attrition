# below sea level of sanity
execute if score @s atr.depth matches ..0 if score SANITY_ON atr.cfg matches 1 if predicate attrition:chance_25 run scoreboard players remove @s atr.sanity 1
execute if score @s atr.depth matches ..-20 if predicate attrition:chance_15 run effect give @s minecraft:mining_fatigue 5 0 true
execute if score @s atr.depth matches ..-40 if predicate attrition:chance_10 run effect give @s minecraft:weakness 5 0 true
execute if score @s atr.depth matches ..-40 if score TEMP_ON atr.cfg matches 1 run scoreboard players remove @s atr.temp 1
execute if score @s atr.depth matches ..-55 if predicate attrition:chance_10 run effect give @s minecraft:darkness 4 0 true
execute if score @s atr.depth matches ..-55 if predicate attrition:chance_05 run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.7 0.5
