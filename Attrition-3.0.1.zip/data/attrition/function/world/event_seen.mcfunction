# one bit per event type, checked for every online player
scoreboard players set #bit atr.tmp 1
execute if score EVTYPE atr.world matches 2 run scoreboard players set #bit atr.tmp 2
execute if score EVTYPE atr.world matches 3 run scoreboard players set #bit atr.tmp 4
execute if score EVTYPE atr.world matches 4 run scoreboard players set #bit atr.tmp 8
execute if score EVTYPE atr.world matches 5 run scoreboard players set #bit atr.tmp 16
execute if score EVTYPE atr.world matches 6 run scoreboard players set #bit atr.tmp 32
execute if score EVTYPE atr.world matches 7 run scoreboard players set #bit atr.tmp 64
execute if score EVTYPE atr.world matches 8 run scoreboard players set #bit atr.tmp 128
execute if score EVTYPE atr.world matches 9 run scoreboard players set #bit atr.tmp 256
execute if score EVTYPE atr.world matches 10 run scoreboard players set #bit atr.tmp 512
execute as @a run function attrition:world/event_seen_p
