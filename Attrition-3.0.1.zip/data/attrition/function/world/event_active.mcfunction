# per-second pressure while a world event is running
execute unless score EVENT atr.world matches 1.. run return 0
execute if score EVTYPE atr.world matches 7 as @a[gamemode=!creative,gamemode=!spectator] at @s if predicate attrition:sees_sky run function attrition:world/ev_heat
execute if score EVTYPE atr.world matches 8 as @a[gamemode=!creative,gamemode=!spectator] at @s if predicate attrition:chance_25 run effect give @s minecraft:blindness 10 0 false
execute if score EVTYPE atr.world matches 9 as @a[gamemode=!creative,gamemode=!spectator] at @s if predicate attrition:sees_sky if predicate attrition:chance_05 run function attrition:world/ev_meteor
execute if score EVTYPE atr.world matches 10 as @a[gamemode=!creative,gamemode=!spectator] at @s if predicate attrition:chance_10 run function attrition:world/ev_quake
