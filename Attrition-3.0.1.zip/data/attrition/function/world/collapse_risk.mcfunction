# deep tunnels are not stable in era 3+
execute unless score CAVEIN_ON atr.cfg matches 1 run return 0
execute unless score ERA atr.world matches 3.. run return 0
execute unless entity @s[y=-64,dy=64] run return 0
execute unless predicate attrition:chance_02 run return 0
function attrition:world/collapse_do
