# thin air above the clouds
execute unless score ALTITUDE_ON atr.cfg matches 1 run return 0
execute unless dimension minecraft:overworld run return 0
execute unless entity @s[y=200,dy=1000] run return 0
scoreboard players add @s atr.altitude 1
scoreboard players remove @s atr.temp 2
execute if score @s atr.stam matches 1.. run scoreboard players remove @s atr.stam 4
execute if predicate attrition:chance_35 run effect give @s minecraft:slowness 6 0 true
execute if predicate attrition:chance_15 run title @s actionbar {text:"The air is too thin up here",color:"aqua",italic:true}
execute if score @s atr.altitude matches 120.. run advancement grant @s only attrition:high_air
