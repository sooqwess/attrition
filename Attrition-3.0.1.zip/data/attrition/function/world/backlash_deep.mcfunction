scoreboard players add @s atr.gloom 8
scoreboard players remove @s atr.sanity 6
effect give @s minecraft:blindness 60 0 false
execute if predicate attrition:chance_50 run summon minecraft:zombified_piglin ~ ~1 ~ {Tags:["atr.backlash"]}
execute if predicate attrition:chance_25 run summon minecraft:magma_cube ~ ~1 ~ {Tags:["atr.backlash"]}
playsound minecraft:entity.wither.spawn hostile @s ~ ~ ~ 0.4 1.8
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Something under the Nether noticed that.",color:"gray"}]
