execute unless score RECKON atr.world matches 1 run return 0
execute if score @s atr.reckon matches 1.. run scoreboard players remove @s atr.reckon 5
scoreboard players add @s atr.gloom 1
execute if predicate attrition:chance_05 if predicate attrition:sees_sky if score IS_NIGHT atr.world matches 1 run function attrition:world/reckon_hunt
execute if score @s atr.reckon matches ..0 if predicate attrition:is_sneaking run function attrition:boss/king/scan
