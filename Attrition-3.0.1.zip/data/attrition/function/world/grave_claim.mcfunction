scoreboard players set @s atr.grave 0
attribute @s minecraft:max_health modifier remove attrition:grave
kill @e[type=minecraft:marker,tag=atr.grave,distance=..8]
effect give @s minecraft:regeneration 10 0 true
scoreboard players add @s atr.sanity 10
playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.2
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"You took it back. The weight lifts.",color:"gray"}]
advancement grant @s only attrition:grave_claim
