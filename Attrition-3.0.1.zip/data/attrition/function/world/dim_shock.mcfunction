scoreboard players remove @s atr.dshock 5
effect give @s minecraft:weakness 6 0 true
effect give @s minecraft:mining_fatigue 6 0 true
execute if predicate attrition:chance_25 run effect give @s minecraft:nausea 60 0 false
execute if score @s atr.dshock matches ..0 run scoreboard players set @s atr.dshock 0
execute if score @s atr.dshock matches ..0 run title @s actionbar {text:"You have acclimatised",color:"gray",italic:true}
