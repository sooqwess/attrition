execute if predicate attrition:in_lava run scoreboard players set @s atr.temp 100
execute if predicate attrition:in_lava run scoreboard players remove @s atr.sanity 4
execute if predicate attrition:on_fire run scoreboard players add @s atr.temp 6
execute if predicate attrition:on_fire run scoreboard players remove @s atr.thirst 1
execute if predicate attrition:on_fire run scoreboard players add @s atr.burn 1
execute if score @s atr.burn matches 100.. run advancement grant @s only attrition:burned_much
