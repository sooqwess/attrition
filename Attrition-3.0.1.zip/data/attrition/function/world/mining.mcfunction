# deep mining wakes things up
execute if entity @s[y=-64,dy=20] if predicate attrition:chance_05 run function attrition:world/cave_in
execute if entity @s[y=-64,dy=20] if score SANITY_ON atr.cfg matches 1 run scoreboard players remove @s atr.sanity 1
execute if entity @s[y=-64,dy=20] if predicate attrition:chance_05 run playsound minecraft:block.sculk_shrieker.shriek ambient @s ~ ~ ~ 0.5 0.6
