# as <player> at <player>. Reinforcements: overworld only, at night, density capped.
execute unless dimension minecraft:overworld run return 0
execute store result score #cnt atr.tmp if entity @e[type=#attrition:targets,distance=..40]
execute if score #cnt atr.tmp >= BM_CAP atr.cfg run return 0
execute store result score #ang atr.tmp run random value 0..359
execute store result storage attrition:calc bm.a double 1 run scoreboard players get #ang atr.tmp
function attrition:world/bm_place with storage attrition:calc bm
