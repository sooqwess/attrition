execute as @e[tag=atr.trader] at @s run particle minecraft:soul ~ ~1 ~ 0.3 0.6 0.3 0.01 3 normal
execute as @e[tag=atr.trader] at @s if predicate attrition:chance_05 run playsound minecraft:entity.wandering_trader.ambient master @a[distance=..24] ~ ~ ~ 0.5 0.8
