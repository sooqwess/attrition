summon minecraft:fireball ~ ~40 ~ {Motion:[0d,-1.4d,0d],acceleration_power:0.02d,ExplosionPower:2b,Item:{count:1,id:"minecraft:fire_charge"}}
playsound minecraft:entity.ghast.shoot hostile @s ~ ~ ~ 1 0.7
