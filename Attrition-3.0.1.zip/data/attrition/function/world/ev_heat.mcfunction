scoreboard players add @s atr.temp 2
execute if score THIRST_ON atr.cfg matches 1 if predicate attrition:chance_50 run scoreboard players remove @s atr.thirst 1
execute if predicate attrition:chance_10 run particle minecraft:flame ~ ~1 ~ 0.6 0.6 0.6 0 6 normal @s
