scoreboard players remove EVENT atr.world 1
execute if score EVTYPE atr.world matches 1 as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/event/ashfall_fx
execute if score EVTYPE atr.world matches 2 as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/event/silence_fx
execute if score EVTYPE atr.world matches 3 as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/event/swarm_fx
execute if score EVTYPE atr.world matches 4 as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/event/coldsnap_fx
execute if score EVTYPE atr.world matches 5 as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/event/hollow_fx
execute if score EVTYPE atr.world matches 6 as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/event/harvest_fx
execute if score EVENT atr.world matches 0 run function attrition:world/event_end
