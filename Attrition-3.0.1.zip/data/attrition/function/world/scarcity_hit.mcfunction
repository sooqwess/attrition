effect give @s minecraft:mining_fatigue 8 0 true
execute if predicate attrition:chance_25 run playsound minecraft:block.deepslate.break master @s ~ ~ ~ 0.6 0.6
execute if predicate attrition:chance_10 run title @s actionbar {text:"The stone fights back",color:"dark_gray",italic:true}
