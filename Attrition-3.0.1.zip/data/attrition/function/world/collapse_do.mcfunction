particle minecraft:block{block_state:"minecraft:deepslate"} ~ ~2 ~ 1 1 1 0.1 60 normal
playsound minecraft:block.deepslate.break master @s ~ ~ ~ 1 0.4
damage @s 5 attrition:collapse
effect give @s minecraft:slowness 60 1 true
execute if score BODY_ON atr.cfg matches 1 run function attrition:body/frac_add
scoreboard players remove @s atr.sanity 6
scoreboard players add @s atr.suffoc 1
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The ceiling comes down on you.",color:"dark_gray"}]
execute if score @s atr.suffoc matches 3.. run advancement grant @s only attrition:buried
