scoreboard players set @s atr.dshock 240
scoreboard players remove @s atr.sanity 8
scoreboard players remove @s atr.stam 25
playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.5 0.6
title @s actionbar {text:"Your body has not agreed to this place yet",color:"dark_purple",italic:true}
function attrition:world/shock_seen
