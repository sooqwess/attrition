execute unless score @s atr.grave matches 1 run return 0
execute if entity @e[type=minecraft:marker,tag=atr.grave,distance=..6] run function attrition:world/grave_claim
execute unless entity @e[type=minecraft:marker,tag=atr.grave] run function attrition:world/grave_claim
execute if predicate attrition:chance_15 run title @s actionbar {text:"Unfinished business",color:"dark_gray",italic:true}
