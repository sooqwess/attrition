tellraw @a {text:"  The air settles.",color:"dark_gray",italic:true}
scoreboard players set EVTYPE atr.world 0
playsound minecraft:block.beacon.deactivate master @a ~ ~ ~ 0.4 1.2
