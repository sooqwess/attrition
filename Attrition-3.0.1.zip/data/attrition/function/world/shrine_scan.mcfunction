# a shrine is four soul lanterns around gold on stone - build it yourself
execute unless score SHRINE_ON atr.cfg matches 1 run return 0
execute unless score @s atr.shrine matches ..0 run return 0
execute unless block ~ ~-1 ~ minecraft:gold_block run return 0
execute unless block ~2 ~-1 ~ minecraft:soul_lantern run return 0
execute unless block ~-2 ~-1 ~ minecraft:soul_lantern run return 0
execute unless block ~ ~-1 ~2 minecraft:soul_lantern run return 0
execute unless block ~ ~-1 ~-2 minecraft:soul_lantern run return 0
execute unless predicate attrition:is_sneaking run return 0
scoreboard players set @s atr.shrine 12000
function attrition:boon/grant
scoreboard players add @s atr.sanity 20
execute if score @s atr.sanity matches 100.. run scoreboard players set @s atr.sanity 100
advancement grant @s only attrition:shrine_built
