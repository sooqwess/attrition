execute unless dimension minecraft:the_nether run return 0
execute unless score TEMP_ON atr.cfg matches 1 run return 0
scoreboard players add @s atr.nethert 1
scoreboard players add @s atr.temp 3
execute if predicate attrition:chance_25 run scoreboard players remove @s atr.thirst 1
execute if score @s atr.temp matches 90.. if predicate attrition:chance_35 run damage @s 1 attrition:exposure
execute if score @s atr.nethert matches 1440.. run advancement grant @s only attrition:thirst_nether
