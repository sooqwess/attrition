scoreboard players add @s atr.gloom 4
execute if predicate attrition:chance_35 run playsound minecraft:block.sculk_shrieker.shriek ambient @s ~ ~ ~ 0.7 0.5
execute if predicate attrition:chance_25 run effect give @s minecraft:darkness 80 0 false
execute if predicate attrition:chance_15 run summon minecraft:silverfish ~ ~ ~ {Tags:["atr.backlash"]}
execute if score ERA atr.world matches 3.. if predicate attrition:chance_15 run summon minecraft:cave_spider ~ ~ ~ {Tags:["atr.backlash"]}
title @s actionbar {text:"The stone resents you",color:"dark_aqua",italic:true}
