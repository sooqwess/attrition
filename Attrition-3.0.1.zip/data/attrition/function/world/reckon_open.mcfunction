tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE RECKONING",color:"red"}]
tellraw @a {text:"  The world has finished growing. Now it collects.",color:"dark_gray",italic:true}
tellraw @a {text:"  Build the last altar: gold block, four soul lanterns, a pact token, and crouch.",color:"gray"}
tellraw @a ""
execute as @a run advancement grant @s only attrition:reckoning
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 1 0.5
