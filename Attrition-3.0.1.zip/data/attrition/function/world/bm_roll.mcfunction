scoreboard players operation BMDAY atr.world = DAY atr.world
execute store result score #rng atr.tmp run random value 1..100
execute if score #rng atr.tmp > BM_PCT atr.cfg run return 0
scoreboard players set BM atr.world 1
scoreboard players set BMCLK atr.world 0
playsound minecraft:entity.elder_guardian.curse master @a ~ ~ ~ 1 0.5
title @a times 10 70 20
title @a title {translate:"attrition.bm.title",fallback:"BLOOD MOON",color:"dark_red"}
title @a subtitle {translate:"attrition.bm.sub",fallback:"Until dawn, the world forgives nothing",color:"red"}
tag @a add atr.bmseen
