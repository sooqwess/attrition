# The era advances with in-game days OR the best player's progress. It never drops.
scoreboard players set #best atr.tmp 0
execute as @a run function attrition:world/era_best

scoreboard players set #e atr.tmp 0
execute if score DAY atr.world >= ERA1_DAY atr.cfg run scoreboard players set #e atr.tmp 1
execute if score DAY atr.world >= ERA2_DAY atr.cfg run scoreboard players set #e atr.tmp 2
execute if score DAY atr.world >= ERA3_DAY atr.cfg run scoreboard players set #e atr.tmp 3
execute if score #best atr.tmp matches 2..3 if score #e atr.tmp matches ..0 run scoreboard players set #e atr.tmp 1
execute if score #best atr.tmp matches 4..5 if score #e atr.tmp matches ..1 run scoreboard players set #e atr.tmp 2
execute if score #best atr.tmp matches 6..7 if score #e atr.tmp matches ..2 run scoreboard players set #e atr.tmp 3
execute if score #best atr.tmp matches 8.. run scoreboard players set #e atr.tmp 4

execute if score #e atr.tmp > ERA atr.world run function attrition:world/era_up
