scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 7
scoreboard players add EVCOUNT atr.world 1
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE HEAT",color:"red"}]
tellraw @a {text:"  The air is thick. Water will not last the day.",color:"dark_gray",italic:true}
execute as @a[gamemode=!creative,gamemode=!spectator] run scoreboard players add @s atr.temp 25
execute as @a[gamemode=!creative,gamemode=!spectator] run scoreboard players remove @s atr.thirst 20
playsound minecraft:block.fire.ambient master @a ~ ~ ~ 1 0.6
