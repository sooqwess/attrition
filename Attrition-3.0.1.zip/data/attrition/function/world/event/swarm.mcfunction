scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 3
tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE SWARM",color:"red"}]
tellraw @a {text:"  Everything with legs is moving in one direction.",color:"dark_gray",italic:true}
tellraw @a ""
playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5
