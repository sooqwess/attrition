execute if score GLOOM_ON atr.cfg matches 1 run scoreboard players add @s atr.gloom 1
execute if predicate attrition:chance_05 run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.5 0.5
execute if predicate attrition:chance_10 run particle minecraft:soul ~ ~1 ~ 2 1 2 0.02 8 force @s
