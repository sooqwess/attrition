scoreboard players set EVENT atr.world 200
scoreboard players set EVTYPE atr.world 9
scoreboard players add EVCOUNT atr.world 1
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"FALLING SKY",color:"red"}]
tellraw @a {text:"  Something is coming down and it is not rain.",color:"dark_gray",italic:true}
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 1 0.5
