execute if predicate attrition:sees_sky run particle minecraft:ash ~ ~6 ~ 12 6 12 0 40 force @s
execute if predicate attrition:sees_sky run effect give @s minecraft:hunger 3 0 true
execute if predicate attrition:sees_sky if predicate attrition:chance_10 run effect give @s minecraft:blindness 3 0 true
execute if predicate attrition:sees_sky if score TEMP_ON atr.cfg matches 1 run scoreboard players add @s atr.temp 1
