execute if predicate attrition:chance_10 run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.3
execute if score SANITY_ON atr.cfg matches 1 run scoreboard players remove @s atr.sanity 1
execute if predicate attrition:chance_05 run effect give @s minecraft:darkness 4 0 true
