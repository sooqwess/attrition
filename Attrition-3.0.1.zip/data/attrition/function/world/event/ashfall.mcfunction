scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 1
tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"ASHFALL",color:"red"}]
tellraw @a {text:"  The sky is shedding something that is not snow.",color:"dark_gray",italic:true}
tellraw @a ""
playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5
