execute if predicate attrition:chance_10 if predicate attrition:in_darkness run function attrition:world/event/swarm_spawn
