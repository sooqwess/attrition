scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 4
tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"COLD SNAP",color:"red"}]
tellraw @a {text:"  The warmth is leaving the world.",color:"dark_gray",italic:true}
tellraw @a ""
playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5
