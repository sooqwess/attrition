execute positioned ^ ^ ^14 unless block ~ ~ ~ #minecraft:leaves if block ~ ~ ~ #minecraft:air if block ~ ~-1 ~ #minecraft:air run summon minecraft:spider ~ ~ ~ {Tags:["atr.swarm"],PersistenceRequired:0b}
execute positioned ^ ^ ^-14 if block ~ ~ ~ #minecraft:air if block ~ ~-1 ~ #minecraft:air run summon minecraft:cave_spider ~ ~ ~ {Tags:["atr.swarm"],PersistenceRequired:0b}
