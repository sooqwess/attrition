effect give @s minecraft:mining_fatigue 3 0 true
execute if score LOAD_ON atr.cfg matches 1 run scoreboard players add @s atr.load 0
execute if predicate attrition:chance_05 run playsound minecraft:block.sculk_shrieker.shriek master @s ~ ~ ~ 0.6 0.7
