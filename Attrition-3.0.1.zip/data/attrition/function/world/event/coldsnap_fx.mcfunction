execute if score TEMP_ON atr.cfg matches 1 run scoreboard players remove @s atr.temp 3
execute if predicate attrition:sees_sky run effect give @s minecraft:slowness 3 0 true
execute if predicate attrition:chance_10 run particle minecraft:snowflake ~ ~2 ~ 6 4 6 0 20 force @s
