scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 8
scoreboard players add EVCOUNT atr.world 1
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE FOG",color:"red"}]
tellraw @a {text:"  You cannot see the tree you are standing next to.",color:"dark_gray",italic:true}
execute as @a[gamemode=!creative,gamemode=!spectator] run effect give @s minecraft:blindness 12 0 false
weather rain 6000
playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.4
