scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 6
tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE RECKONING",color:"red"}]
tellraw @a {text:"  The Gloom collects what it is owed.",color:"dark_gray",italic:true}
tellraw @a ""
playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5
