scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 2
tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE SILENCE",color:"red"}]
tellraw @a {text:"  Nothing spawns. Nothing sounds. Something is listening.",color:"dark_gray",italic:true}
tellraw @a ""
playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5
