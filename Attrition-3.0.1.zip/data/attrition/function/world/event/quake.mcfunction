scoreboard players set EVENT atr.world 200
scoreboard players set EVTYPE atr.world 10
scoreboard players add EVCOUNT atr.world 1
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE SHAKING",color:"red"}]
tellraw @a {text:"  The ground is not solid today.",color:"dark_gray",italic:true}
execute as @a[gamemode=!creative,gamemode=!spectator] run effect give @s minecraft:nausea 200 0 false
execute as @a[gamemode=!creative,gamemode=!spectator] run scoreboard players add @s atr.gloom 8
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1 0.4
