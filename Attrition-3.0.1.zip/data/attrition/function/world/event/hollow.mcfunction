scoreboard players set EVENT atr.world 240
scoreboard players set EVTYPE atr.world 5
tellraw @a ""
tellraw @a [{text:"  \u2588 ",color:"dark_red"},{text:"THE HOLLOW HOUR",color:"red"}]
tellraw @a {text:"  Your tools feel heavier than they are.",color:"dark_gray",italic:true}
tellraw @a ""
playsound minecraft:ambient.cave master @a ~ ~ ~ 1 0.5
