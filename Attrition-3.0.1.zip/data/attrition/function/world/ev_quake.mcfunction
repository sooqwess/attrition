execute if predicate attrition:chance_50 run particle minecraft:block{block_state:"minecraft:stone"} ~ ~ ~ 2 0.2 2 0.1 40 normal @s
execute if score @s atr.depth matches ..0 if predicate attrition:chance_25 run function attrition:world/cave_in
execute if predicate attrition:chance_15 run damage @s 2 attrition:collapse
playsound minecraft:block.stone.break master @s ~ ~ ~ 0.8 0.4
