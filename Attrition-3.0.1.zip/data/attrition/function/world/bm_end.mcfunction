scoreboard players set BM atr.world 0
tag @e[tag=atr.bm] remove atr.bm
tag @e[tag=atr.done] remove atr.done
playsound minecraft:block.beacon.deactivate master @a ~ ~ ~ 0.6 1.4
tellraw @a {translate:"attrition.bm.over",fallback:"The moon has paled. You lived.",color:"gray",italic:true}
execute as @a[tag=atr.bmseen] run function attrition:player/ach_bloodmoon
tag @a remove atr.bmseen
