# your death leaves something behind that is shaped like you
execute unless score ECHO_ON atr.cfg matches 1 run return 0
execute unless score ERA atr.world matches 2.. run return 0
execute unless predicate attrition:chance_35 run return 0
summon minecraft:zombie ~ ~ ~ {Tags:["atr.echo"],PersistenceRequired:1b,IsBaby:0b,Silent:1b,CustomNameVisible:1b,CustomName:{translate:"attrition.entity.your_echo",fallback:"Your Echo",color:"dark_purple",italic:true},ArmorItems:[{},{},{},{id:"minecraft:player_head",count:1}]}
