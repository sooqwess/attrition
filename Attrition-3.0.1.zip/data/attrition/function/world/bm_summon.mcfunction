execute store result score #m atr.tmp run random value 1..5
execute if score #m atr.tmp matches 1 run summon minecraft:zombie ~ ~ ~ {Tags:["atr.bm"]}
execute if score #m atr.tmp matches 2 run summon minecraft:skeleton ~ ~ ~ {Tags:["atr.bm"]}
execute if score #m atr.tmp matches 3 run summon minecraft:spider ~ ~ ~ {Tags:["atr.bm"]}
execute if score #m atr.tmp matches 4 run summon minecraft:creeper ~ ~ ~ {Tags:["atr.bm"]}
execute if score #m atr.tmp matches 5 run summon minecraft:husk ~ ~ ~ {Tags:["atr.bm"]}
