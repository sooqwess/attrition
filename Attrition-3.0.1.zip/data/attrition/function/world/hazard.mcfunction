# rare ambient pressure: nothing lethal alone, everything lethal together
execute as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/hazard_do
