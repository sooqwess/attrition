# weather is no longer decoration
execute unless score STORM_ON atr.cfg matches 1 run return 0
execute unless predicate attrition:is_thundering run return 0
scoreboard players add STORM atr.world 1
execute as @a[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/storm_on
