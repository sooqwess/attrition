execute if score @s atr.contract matches 1 run tellraw @s [{text:"[",color:"dark_gray"},{text:"CONTRACT",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Kill 20 hostiles.",color:"gray"}]
execute if score @s atr.contract matches 2 run tellraw @s [{text:"[",color:"dark_gray"},{text:"CONTRACT",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Kill 8 elites.",color:"gray"}]
execute if score @s atr.contract matches 3 run tellraw @s [{text:"[",color:"dark_gray"},{text:"CONTRACT",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Survive 3 nights without dying.",color:"gray"}]
execute if score @s atr.contract matches 4 run tellraw @s [{text:"[",color:"dark_gray"},{text:"CONTRACT",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Mine 500 blocks below y=0.",color:"gray"}]
tellraw @s {text:"  Reward: a boon, and the Gloom eases.",color:"dark_gray",italic:true}
