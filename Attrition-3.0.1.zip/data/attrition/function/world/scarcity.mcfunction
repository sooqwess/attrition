# the deep does not give ore away for free any more
execute unless score SCARCITY_ON atr.cfg matches 1 run return 0
execute unless score ERA atr.world matches 2.. run return 0
execute if score @s atr.depth matches ..0 if predicate attrition:chance_05 run function attrition:world/scarcity_hit
