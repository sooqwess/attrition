execute if score EVENT_ON atr.cfg matches 0 run return 0
execute if score EVENT atr.world matches 1.. run function attrition:world/event_run
execute if score EVENT atr.world matches 0 run scoreboard players add EVCLK atr.world 1
# roll a new event roughly every 10 minutes of play
execute if score EVCLK atr.world matches 600.. run function attrition:world/event_roll
