scoreboard players operation #cur atr.tmp = @s atr.eseen
function attrition:player/bit_set
scoreboard players operation @s atr.eseen = #cur atr.tmp
scoreboard players add @s atr.evn 1
execute if score @s atr.eseen matches 1023 run advancement grant @s only attrition:event_all
