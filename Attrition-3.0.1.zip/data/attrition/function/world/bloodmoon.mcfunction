# Rolled once per night: window 13000..13400, once per day
execute if score ERA atr.world matches 2.. if score TOD atr.world matches 13000..13400 unless score BMDAY atr.world = DAY atr.world run function attrition:world/bm_roll
# Ends at dawn
execute if score BM atr.world matches 1 if score TOD atr.world matches 0..12000 run function attrition:world/bm_end
# Atmosphere and reinforcements
execute if score BM atr.world matches 1 run function attrition:world/bm_active
