scoreboard players set @s atr.contract 0
scoreboard players set @s atr.cprog 0
scoreboard players remove @s atr.gloom 20
execute if score @s atr.gloom matches ..0 run scoreboard players set @s atr.gloom 0
function attrition:boon/grant
scoreboard players add @s atr.crafts 0
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"Contract fulfilled. The world settles, briefly.",color:"gold"}]
advancement grant @s only attrition:contractor
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
