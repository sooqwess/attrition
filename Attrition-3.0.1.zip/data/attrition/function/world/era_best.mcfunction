execute if score @s atr.prog > #best atr.tmp run scoreboard players operation #best atr.tmp = @s atr.prog
