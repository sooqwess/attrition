scoreboard players add @s atr.grudge 6
