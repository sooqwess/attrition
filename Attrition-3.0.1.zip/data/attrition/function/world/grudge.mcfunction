# the living remember what you did to the living
execute unless score GRUDGE_ON atr.cfg matches 1 run return 0
scoreboard players operation #g atr.tmp = @s atr.grudge
execute if score @s atr.grudge matches 1.. run scoreboard players remove @s atr.grudge 1
execute if score @s atr.grudge matches 20.. if predicate attrition:chance_25 run function attrition:world/grudge_hunt
execute if score @s atr.grudge matches 40.. run effect give @s minecraft:unluck 10 0 true
execute if score @s atr.grudge matches 40.. if predicate attrition:chance_15 run function attrition:world/grudge_hunt
execute if score @s atr.grudge matches 60.. run scoreboard players set @s atr.grudge 60
