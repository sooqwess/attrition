# the world hears you: sprinting, mining and fighting all make noise
execute unless score NOISE_ON atr.cfg matches 1 run return 0
scoreboard players operation #d atr.tmp = @s atr.sprint
scoreboard players operation #d atr.tmp -= @s atr.spawnp
scoreboard players operation @s atr.spawnp = @s atr.sprint
execute if score #d atr.tmp matches 100.. run scoreboard players add @s atr.noise 2

scoreboard players operation #m atr.tmp = @s atr.mined
scoreboard players operation #m atr.tmp -= @s atr.minedp
scoreboard players operation @s atr.minedp = @s atr.mined
execute if score #m atr.tmp matches 20.. run scoreboard players add @s atr.noise 3
execute if score #m atr.tmp matches 5..19 run scoreboard players add @s atr.noise 1
execute if score @s atr.combat matches 1.. run scoreboard players add @s atr.noise 2
execute if predicate attrition:is_sneaking run scoreboard players remove @s atr.noise 3

scoreboard players remove @s atr.noise 1
execute if score @s atr.noise matches ..0 run scoreboard players set @s atr.noise 0
execute if score @s atr.noise matches 60.. run scoreboard players set @s atr.noise 60
function attrition:world/noise_fx
