execute unless score GRAVE_ON atr.cfg matches 1 run return 0
execute if entity @e[type=minecraft:marker,tag=atr.grave] run kill @e[type=minecraft:marker,tag=atr.grave,sort=nearest,limit=1]
summon minecraft:marker ~ ~ ~ {Tags:["atr.grave"]}
scoreboard players set @s atr.grave 1
attribute @s minecraft:max_health modifier add attrition:grave -0.10 add_multiplied_base
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"You left something behind. Go and take it back.",color:"gray"}]
