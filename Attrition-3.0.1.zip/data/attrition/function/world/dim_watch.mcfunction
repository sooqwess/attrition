execute unless score DSHOCK_ON atr.cfg matches 1 run return 0
scoreboard players set #d atr.tmp 0
execute if dimension minecraft:the_nether run scoreboard players set #d atr.tmp 1
execute if dimension minecraft:the_end run scoreboard players set #d atr.tmp 2
execute unless score @s atr.dim = #d atr.tmp run function attrition:world/dim_change
scoreboard players operation @s atr.dim = #d atr.tmp
execute if score @s atr.dshock matches 1.. run function attrition:world/dim_shock
