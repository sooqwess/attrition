# every death leaves a stain on the ground itself
execute unless score BLIGHT_ON atr.cfg matches 1 run return 0
execute if entity @e[type=minecraft:marker,tag=atr.blight,distance=..24,limit=1] run return 0
summon minecraft:marker ~ ~ ~ {Tags:["atr.blight"]}
