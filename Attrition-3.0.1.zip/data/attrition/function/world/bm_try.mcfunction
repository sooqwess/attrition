execute unless block ~ ~ ~ minecraft:air run return 0
execute unless block ~ ~1 ~ minecraft:air run return 0
execute if block ~ ~-1 ~ minecraft:air run return 0
execute if block ~ ~-1 ~ minecraft:water run return 0
execute if block ~ ~-1 ~ minecraft:lava run return 0
function attrition:world/bm_summon
