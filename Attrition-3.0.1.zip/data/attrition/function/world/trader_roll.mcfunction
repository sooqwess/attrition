# rarely, something that still trades walks out of the dark
execute unless score TRADER_ON atr.cfg matches 1 run return 0
execute if entity @e[tag=atr.trader] run return 0
execute unless score ERA atr.world matches 1.. run return 0
execute unless predicate attrition:chance_05 run return 0
execute as @r[gamemode=!creative,gamemode=!spectator] at @s run function attrition:world/trader_spawn
