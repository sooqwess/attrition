scoreboard players add @s atr.respite 1
execute if score @s atr.temp matches ..49 run scoreboard players add @s atr.temp 4
execute if score @s atr.stam matches ..99 run scoreboard players add @s atr.stam 6
execute if score SANITY_ON atr.cfg matches 1 run scoreboard players add @s atr.sanity 2
scoreboard players remove @s atr.noise 2
execute if score @s atr.respite matches 6.. if score @s atr.bleed matches 1.. run scoreboard players remove @s atr.bleed 10
execute if score @s atr.respite matches 12.. run effect give @s minecraft:regeneration 6 0 true
execute if score @s atr.respite matches 12.. run advancement grant @s only attrition:respite
execute if score @s atr.respite matches 24.. run scoreboard players set @s atr.respite 24
execute if score @s atr.respite matches 2 run title @s actionbar {text:"The fire holds the world back a little",color:"gold",italic:true}
