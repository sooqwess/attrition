scoreboard players set EVCLK atr.world 0
execute unless predicate attrition:chance_35 run return 0
execute unless score ERA atr.world matches 1.. run return 0
scoreboard players set #r atr.tmp 0
execute store result score #r atr.tmp run random value 1..10
execute if score #r atr.tmp matches 1 run function attrition:world/event/ashfall
execute if score #r atr.tmp matches 2 run function attrition:world/event/silence
execute if score #r atr.tmp matches 3 run function attrition:world/event/swarm
execute if score #r atr.tmp matches 4 run function attrition:world/event/coldsnap
execute if score #r atr.tmp matches 5 run function attrition:world/event/hollow
execute if score #r atr.tmp matches 6 run function attrition:world/event/harvest
execute if score #r atr.tmp matches 7 run function attrition:world/event/heatwave
execute if score #r atr.tmp matches 8 run function attrition:world/event/fog
execute if score #r atr.tmp matches 9 if score ERA atr.world matches 2.. run function attrition:world/event/meteors
execute if score #r atr.tmp matches 9 unless score ERA atr.world matches 2.. run function attrition:world/event/ashfall
execute if score #r atr.tmp matches 10 run function attrition:world/event/quake
scoreboard players add @s atr.events 0
function attrition:world/event_seen
