# standing in a blight is standing in your own history
execute unless score BLIGHT_ON atr.cfg matches 1 run return 0
execute if entity @e[type=minecraft:marker,tag=atr.blight,distance=..10,limit=1] run function attrition:world/blight_in
