# depth pressure: y<0 is not survival, it is a loan
execute unless score BODY_ON atr.cfg matches 1 run return 0
scoreboard players set @s atr.depth 0
execute store result score @s atr.depth run data get entity @s Pos[1]
execute if score @s atr.depth matches ..0 run function attrition:world/depth_do
