execute unless score @s atr.contract matches 1.. run return 0
execute if score @s atr.contract matches 1 if score @s atr.cprog matches 20.. run function attrition:world/contract_done
execute if score @s atr.contract matches 2 if score @s atr.cprog matches 8.. run function attrition:world/contract_done
execute if score @s atr.contract matches 3 if score @s atr.cprog matches 3.. run function attrition:world/contract_done
execute if score @s atr.contract matches 4 if score @s atr.cprog matches 500.. run function attrition:world/contract_done
