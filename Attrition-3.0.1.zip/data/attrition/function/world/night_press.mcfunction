execute if score WATCH atr.world matches 2.. if score SANITY_ON atr.cfg matches 1 if predicate attrition:sees_sky if predicate attrition:chance_25 run scoreboard players remove @s atr.sanity 1
execute if score WATCH atr.world matches 4.. if predicate attrition:in_darkness if predicate attrition:chance_15 run effect give @s minecraft:blindness 3 0 true
execute if score WATCH atr.world matches 5.. if predicate attrition:chance_05 run function attrition:gloom/hunt
