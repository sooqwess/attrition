# keep the entity count honest: blights fade after long enough
execute as @e[type=minecraft:marker,tag=atr.blight] run scoreboard players add @s atr.blight 1
kill @e[type=minecraft:marker,tag=atr.blight,scores={atr.blight=2400..}]
