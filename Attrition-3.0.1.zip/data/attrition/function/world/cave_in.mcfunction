title @s actionbar {text:"The ceiling shifts",color:"gray",italic:true}
playsound minecraft:block.gravel.break ambient @s ~ ~ ~ 1 0.6
execute positioned ~ ~3 ~ if block ~ ~ ~ #minecraft:base_stone_overworld run summon minecraft:falling_block ~ ~ ~ {BlockState:{Name:"minecraft:gravel"},Tags:["atr.cavein"]}
execute if predicate attrition:chance_25 run effect give @s minecraft:blindness 4 0 true
