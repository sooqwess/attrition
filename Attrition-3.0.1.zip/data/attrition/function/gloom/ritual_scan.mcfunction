# as <player> at <player>. Rite: crouch on a gold block holding glowstone dust.
execute if score RITUAL_ON atr.cfg matches 0 run return 0
execute if score @s atr.ritual matches 1.. run return 0
execute if predicate attrition:is_sneaking if items entity @s weapon.mainhand minecraft:glowstone_dust at @s if block ~ ~-1 ~ minecraft:gold_block run function attrition:gloom/ritual_do
