# The Gloom thickens - it sends something after you
playsound minecraft:entity.warden_heartbeat master @s ~ ~ ~ 1 0.6
execute if dimension minecraft:overworld positioned ~ ~ ~ if predicate attrition:sees_sky run summon minecraft:phantom ^ ^4 ^-8 {Tags:["atr.hunter"],PersistenceRequired:1b,CustomName:{translate:"attrition.entity.hunter_of_the_gloom",fallback:"Hunter of the Gloom",color:"dark_purple",italic:false}}
execute unless predicate attrition:sees_sky run effect give @s minecraft:wither 3 0 true
tag @s add atr.hunted
scoreboard players set @s atr.hunt 60
tellraw @s {translate:"attrition.gloom.hunt",fallback:"The Gloom has noticed you.",color:"dark_purple",italic:true}
