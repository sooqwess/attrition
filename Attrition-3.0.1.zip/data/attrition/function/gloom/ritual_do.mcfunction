scoreboard players set @s atr.ritual 1200
clear @s minecraft:glowstone_dust 1
scoreboard players set @s atr.gloom 0
scoreboard players set @s atr.floor 0
effect give @s minecraft:regeneration 8 0 true
effect clear @s minecraft:darkness
particle minecraft:end_rod ~ ~1 ~ 0.4 0.8 0.4 0.02 60
playsound minecraft:block.beacon.power_select master @a[distance=..24] ~ ~ ~ 1 1.6
tellraw @s {translate:"attrition.ritual.ok",fallback:"The light is accepted. The Gloom recedes - briefly.",color:"gold",italic:true}
function attrition:player/ach_ritual
