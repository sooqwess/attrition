# as <player> at <player>
execute if predicate attrition:in_darkness run scoreboard players operation @s atr.gloom += GLOOM_RATE atr.cfg
execute if predicate attrition:in_light run scoreboard players operation @s atr.gloom -= GLOOM_DECAY atr.cfg
execute if dimension minecraft:the_nether run scoreboard players add @s atr.gloom 1
execute if dimension minecraft:the_end run scoreboard players add @s atr.gloom 1
execute if score BM atr.world matches 1 run scoreboard players add @s atr.gloom 1

execute if score @s atr.gloom matches ..-1 run scoreboard players set @s atr.gloom 0
execute if score @s atr.gloom > GLOOM_MAX atr.cfg run scoreboard players operation @s atr.gloom = GLOOM_MAX atr.cfg

# threshold: once you have been to the bottom, there is no easy way back
execute if score FLOOR_ON atr.cfg matches 1 if score @s atr.gloom >= GLOOM_MAX atr.cfg run scoreboard players operation @s atr.floor = FLOOR_VAL atr.cfg
execute if score @s atr.gloom < @s atr.floor run scoreboard players operation @s atr.gloom = @s atr.floor

function attrition:gloom/effects
