execute if score @s atr.gloom matches 25..49 run effect give @s minecraft:nausea 3 0 true
execute if score @s atr.gloom matches 50..74 run effect give @s minecraft:nausea 3 0 true
execute if score @s atr.gloom matches 50..74 run effect give @s minecraft:weakness 3 0 true
execute if score @s atr.gloom matches 75..89 run effect give @s minecraft:darkness 3 0 true
execute if score @s atr.gloom matches 75..89 run effect give @s minecraft:weakness 3 1 true
execute if score @s atr.gloom matches 75..89 run effect give @s minecraft:mining_fatigue 3 0 true
execute if score @s atr.gloom matches 90.. run effect give @s minecraft:darkness 3 0 true
execute if score @s atr.gloom matches 90.. run effect give @s minecraft:weakness 3 2 true
execute if score @s atr.gloom matches 90.. run effect give @s minecraft:mining_fatigue 3 1 true
execute if score @s atr.gloom matches 90.. run effect give @s minecraft:slowness 3 0 true
execute if score @s atr.gloom matches 100 if predicate attrition:chance_15 run function attrition:gloom/hunt
