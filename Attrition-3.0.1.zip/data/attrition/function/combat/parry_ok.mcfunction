scoreboard players add @s atr.parry 1
scoreboard players set @s atr.riposte 3
effect give @s minecraft:strength 3 0 true
playsound minecraft:item.shield.block master @s ~ ~ ~ 0.8 1.6
particle minecraft:crit ~ ~1 ~ 0.3 0.3 0.3 0.1 8 normal
title @s actionbar {text:"Parry \u2014 strike now",color:"gold",italic:true}
execute if score @s atr.parry matches 25.. run advancement grant @s only attrition:parry_master
