# a shield is not a wall. Time it and it pays; hide behind it and it rots.
execute unless score PARRY_ON atr.cfg matches 1 run return 0
scoreboard players operation #b atr.tmp = @s atr.block
scoreboard players operation #b atr.tmp -= @s atr.blockp
scoreboard players operation @s atr.blockp = @s atr.block
execute unless score #b atr.tmp matches 1.. run return 0
execute if score @s atr.combat matches 1.. run function attrition:combat/parry_ok
execute unless score @s atr.combat matches 1.. run function attrition:combat/parry_late
