execute if score @s atr.riposte matches 1.. run scoreboard players remove @s atr.riposte 1
