# damage dealt builds Rage; Rage makes you strong and stupid
execute unless score RAGE_ON atr.cfg matches 1 run return 0
scoreboard players operation #d atr.tmp = @s atr.dmgdealt
scoreboard players operation #d atr.tmp -= @s atr.dmgp
scoreboard players operation @s atr.dmgp = @s atr.dmgdealt
execute if score #d atr.tmp matches 1.. run scoreboard players add @s atr.rage 6
execute unless score #d atr.tmp matches 1.. run scoreboard players remove @s atr.rage 3
execute if score @s atr.rage matches ..0 run scoreboard players set @s atr.rage 0
execute if score @s atr.rage matches 100.. run scoreboard players set @s atr.rage 100
function attrition:combat/rage_fx
