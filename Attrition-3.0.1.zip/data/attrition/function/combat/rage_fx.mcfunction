attribute @s minecraft:attack_damage modifier remove attrition:rage
attribute @s minecraft:armor modifier remove attrition:rage
execute if score @s atr.rage matches 40..69 run attribute @s minecraft:attack_damage modifier add attrition:rage 0.08 add_multiplied_base
execute if score @s atr.rage matches 70..99 run attribute @s minecraft:attack_damage modifier add attrition:rage 0.16 add_multiplied_base
execute if score @s atr.rage matches 70..99 run attribute @s minecraft:armor modifier add attrition:rage -0.15 add_multiplied_total
execute if score @s atr.rage matches 100 run attribute @s minecraft:attack_damage modifier add attrition:rage 0.3 add_multiplied_base
execute if score @s atr.rage matches 100 run attribute @s minecraft:armor modifier add attrition:rage -0.3 add_multiplied_total
execute if score @s atr.rage matches 100 run effect give @s minecraft:speed 6 0 true
execute if score @s atr.rage matches 100 if predicate attrition:chance_25 run title @s actionbar {text:"You are not fighting well. You are just fighting.",color:"dark_red",italic:true}
execute if score @s atr.rage matches 100.. run advancement grant @s only attrition:full_rage
