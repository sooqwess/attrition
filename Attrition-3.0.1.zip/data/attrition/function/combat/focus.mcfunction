# crouch-walking without taking a hit builds Focus: quiet, accurate, fragile
scoreboard players operation #c atr.tmp = @s atr.crouch
scoreboard players operation #c atr.tmp -= @s atr.crouchp
scoreboard players operation @s atr.crouchp = @s atr.crouch
execute if score #c atr.tmp matches 1.. if score @s atr.combat matches ..0 run scoreboard players add @s atr.focus 4
execute if score @s atr.combat matches 1.. run scoreboard players set @s atr.focus 0
execute if score @s atr.focus matches 60.. run scoreboard players set @s atr.focus 60
execute if score @s atr.focus matches 30.. run scoreboard players remove @s atr.noise 3
execute if score @s atr.focus matches 60 run effect give @s minecraft:night_vision 6 0 true
