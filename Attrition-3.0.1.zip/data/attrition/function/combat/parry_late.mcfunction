scoreboard players remove @s atr.stam 10
execute if predicate attrition:chance_25 run item modify entity @s weapon.offhand attrition:wear
execute if predicate attrition:chance_15 run title @s actionbar {text:"The shield takes the whole blow",color:"dark_gray",italic:true}
