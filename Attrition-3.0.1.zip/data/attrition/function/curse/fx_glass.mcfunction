attribute @s minecraft:armor modifier remove attrition:curse
attribute @s minecraft:armor modifier add attrition:curse -0.35 add_multiplied_total
