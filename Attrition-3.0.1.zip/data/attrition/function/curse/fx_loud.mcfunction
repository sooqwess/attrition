execute as @e[type=#attrition:targets,distance=..28] run effect give @s minecraft:speed 6 0 true
execute if predicate attrition:chance_10 run playsound minecraft:block.note_block.bass master @a[distance=..24] ~ ~ ~ 0.4 0.5
