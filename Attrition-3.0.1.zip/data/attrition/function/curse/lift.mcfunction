scoreboard players set @s atr.curse 0
scoreboard players set @s atr.ctime 0
attribute @s minecraft:movement_speed modifier remove attrition:curse
attribute @s minecraft:armor modifier remove attrition:curse
tellraw @s [{text:"[",color:"dark_gray"},{text:"ATTRITION",color:"dark_red"},{text:"] ",color:"dark_gray"},{text:"The curse loosens its grip.",color:"gray"}]
playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.7 1.4
function attrition:curse/rode_out
