execute unless score @s atr.curse matches 1.. run return 0
scoreboard players remove @s atr.ctime 5
execute if score @s atr.ctime matches ..0 run function attrition:curse/lift
execute if score @s atr.curse matches 2 run function attrition:curse/fx_leaden
execute if score @s atr.curse matches 3 if score @s atr.bleed matches 1.. run scoreboard players add @s atr.bleed 6
execute if score @s atr.curse matches 4 if predicate attrition:in_darkness if predicate attrition:chance_35 run damage @s 1 attrition:exposure
execute if score @s atr.curse matches 5 if predicate attrition:chance_35 run effect give @s minecraft:hunger 6 1 true
execute if score @s atr.curse matches 6 run function attrition:curse/fx_glass
execute if score @s atr.curse matches 7 if predicate attrition:chance_25 run effect give @s minecraft:blindness 3 0 true
execute if score @s atr.curse matches 8 run function attrition:curse/fx_loud
