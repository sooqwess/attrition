attribute @s minecraft:movement_speed modifier remove attrition:curse
attribute @s minecraft:movement_speed modifier add attrition:curse -0.12 add_multiplied_base
