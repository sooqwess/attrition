scoreboard players add @s atr.dryrun 1
advancement grant @s only attrition:curse_ride
