execute unless score CURSE_ON atr.cfg matches 1 run return 0
execute if score @s atr.curse matches 1.. run return 0
scoreboard players set #r atr.tmp 0
execute store result score #r atr.tmp run random value 1..8
scoreboard players operation @s atr.curse = #r atr.tmp
scoreboard players set @s atr.ctime 12000
function attrition:curse/announce
playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.8 0.8
function attrition:curse/seen
