# remember which of the eight curses this player has worn
scoreboard players set #bit atr.tmp 1
execute if score @s atr.curse matches 2 run scoreboard players set #bit atr.tmp 2
execute if score @s atr.curse matches 3 run scoreboard players set #bit atr.tmp 4
execute if score @s atr.curse matches 4 run scoreboard players set #bit atr.tmp 8
execute if score @s atr.curse matches 5 run scoreboard players set #bit atr.tmp 16
execute if score @s atr.curse matches 6 run scoreboard players set #bit atr.tmp 32
execute if score @s atr.curse matches 7 run scoreboard players set #bit atr.tmp 64
execute if score @s atr.curse matches 8 run scoreboard players set #bit atr.tmp 128
scoreboard players operation #cur atr.tmp = @s atr.cseen
function attrition:player/bit_set
scoreboard players operation @s atr.cseen = #cur atr.tmp
scoreboard players add @s atr.cursen 1
execute if score @s atr.cseen matches 255 run advancement grant @s only attrition:cursed_all
