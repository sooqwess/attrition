# ATTRITION v3.0.1
### by Sooqwess · Minecraft Java 1.21.11

> The world was not made for you. It tolerates you, for now.

A maximum-difficulty datapack. Not "mobs hit harder" — a world that **answers your
progress**. The further you travel, the deeper you dig and the longer you survive,
the more hostile everything around you becomes.

**560 mechanics across 71 systems.** The full inventory is in `MECHANICS.md`.

| | |
|---|---|
| Mechanics | 560 across 71 systems |
| Advancements | 207 |
| Custom items | 20, each with its own texture |
| Recipes | 34 |
| Functions | 411 |
| Config keys | 78 |
| Languages | 69 (Russian and English complete) |

---

## Install

1. `Attrition-3.0.1.zip` → `saves/<world>/datapacks/`
2. `Attrition-RP-3.0.1.zip` → `resourcepacks/`, enable it in options
   *(the pack works without it — you just lose the custom item textures and
   see English text everywhere)*
   Translated into **69 languages**, picked up automatically from your game
   language. Full list in `LANGUAGES.md`.
3. Enter the world. The pack arms itself on the **ATTRITION** preset.
4. Menu: `/trigger atr.menu`

> Custom damage types do not reload correctly with `/reload` (MC-260660).
> After the first install, leave the world and re-enter once.

---

## What is new in 3.0

Version 2.0 built the body. Version 3.0 builds everything the body has to survive.

- **Survival chemistry.** Thirst, stamina, noise, wetness and insomnia run
  alongside the 2.0 body layer. Every one of them can kill you on its own.
- **Curses and boons.** Eight curses and six boons, rolled by the world, tracked
  in a collection you can complete.
- **Diseases.** Rot Fever, Ashen Lung and Hollow Sickness, each with its own cure.
- **Combat depth.** Parry and riposte reward reading a swing. Rage builds damage
  and strips your armour. Focus rewards standing still and staying quiet.
- **Mobs that learn.** Kill enough of a species and the survivors adapt, then
  send an elder. Die, and a Nemesis rises wearing your death.
- **The Hollow King.** A 400 HP three-phase endgame boss who gives back what the
  world took, if you can take it from him.
- **20 custom items**, all craftable, all with hand-drawn 16×16 textures.
- **Economy of consequence.** Grudges, contracts, the tally, titles, the Price,
  the Waste Trader, graves, blights and the Reckoning.
- **Cairns.** The only safe ground in the game, and you have to build it.
- **Rebuilt tick loop.** The five-second pass is split into three rotating phases,
  so 560 mechanics cost less server time than 288 did in 2.0.
- **Full Russian localisation** of all 376 strings; 69 languages ship in the pack.

---

## Presets

| | Tempered | Harsh | Attrition |
|---|---|---|---|
| Threat step | 2200 blocks | 1300 | 750 |
| Tier cap | 8 | 12 | 18 |
| HP per tier | +12% | +17% | +26% |
| Damage per tier | +8% | +12% | +19% |
| Body systems | off | most on | all on |
| Bosses | on, 35% | on, 65% | on, 100% |
| Events | off | 20% | 35% |
| Blood moon | off | 18% | 30% |
| Night terrors / the Price | off | on | on |
| Cave-ins / altitude / adaptation | off | partial | on |

Switch any time from the menu. Every mob in the world is recalculated instantly.

---

## The menu

`/trigger atr.menu` opens everything. No operator rights needed — every button
runs through a trigger, so it works on any server for any player.

```
1-3   presets           9    mechanics, part one
4     HUD on/off        14   body status
5     reset             15   mechanics, part two
6     status            16   survival tips
7     help              17   credits
8     pacts             10-13 pact actions
```

---

## Tuning

Everything is a scoreboard value. 78 keys, all listed by `[ Config keys ]` in the menu:

```
/scoreboard players set SCALE_PER atr.cfg 1500
/scoreboard players set BOSS_ON atr.cfg 0
/scoreboard players set THIRST_ON atr.cfg 0
```

Turn off any single system you do not want. Nothing else breaks when you do.

---

## Compatibility

Works with Terralith, Incendium, Stellarity, Dungeons and Taverns and
Harder Difficulty. **Load Attrition last** — on conflict the last pack wins.

Server side: required. Client side: optional (resource pack only).

---

## Credits

Built by **Sooqwess**. Mechanics drawn from the Ascent and Wolfsbane concepts,
merged and rebuilt into one pack.

---

## License

**All Rights Reserved** — see the `LICENSE` file in this pack.

Short version:

- **Videos and streams** — allowed, monetised or not, no permission needed.
- **Add-ons** — allowed and encouraged: ship your own pack alongside Attrition
  and link back. Do not bundle Attrition's files into your download.
- **Servers** — any, public or private, donations included.
- **Not allowed** — reuploading Attrition elsewhere, or publishing modified
  copies of the pack itself.

Anything else: just ask. The answer is usually yes.
